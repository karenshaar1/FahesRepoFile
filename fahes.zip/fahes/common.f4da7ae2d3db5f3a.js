"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[592],{

/***/ 92498:
/*!*********************************************************!*\
  !*** ./src/app/core/services/visual-defects.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VisualDefectService": () => (/* binding */ VisualDefectService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class VisualDefectService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Inspection/v1';
  }
  getMainVisualDefects(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetMainVisualDefects`, body);
  }
  getSubVisualDefects(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSubVisualDefects`, body);
  }
  getSubVisualDefectsComments(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSubVisualDefectComments`, body);
  }
  getVehicleDefects(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetVehicleDefects`, {
      requestId: requestId
    });
  }
  createInspectionResult(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionResult`, body);
  }
  static #_ = this.ɵfac = function VisualDefectService_Factory(t) {
    return new (t || VisualDefectService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: VisualDefectService,
    factory: VisualDefectService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 53104:
/*!**************************************************************!*\
  !*** ./src/app/core/utilities/enums/defect-comments-type.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectCommentType": () => (/* binding */ DefectCommentType)
/* harmony export */ });
var DefectCommentType;
(function (DefectCommentType) {
  DefectCommentType[DefectCommentType["InspectorDecides"] = 1] = "InspectorDecides";
  DefectCommentType[DefectCommentType["OKComment"] = 2] = "OKComment";
  DefectCommentType[DefectCommentType["Major"] = 3] = "Major";
  DefectCommentType[DefectCommentType["Minor"] = 4] = "Minor";
})(DefectCommentType || (DefectCommentType = {}));

/***/ }),

/***/ 48672:
/*!***************************************************************!*\
  !*** ./src/app/modules/backoffice/classes/payment-details.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentDetails": () => (/* binding */ PaymentDetails),
/* harmony export */   "SummaryDetails": () => (/* binding */ SummaryDetails)
/* harmony export */ });
class PaymentDetails {
  constructor() {
    this.paymentTypeId = 2;
  }
}
class SummaryDetails {}

/***/ })

}]);
//# sourceMappingURL=common.f4da7ae2d3db5f3a.js.map