"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[596],{

/***/ 93739:
/*!***************************************************************!*\
  !*** ./src/app/core/resolver/get-mobile-workflow.resolver.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetMobileWorkflowResolver": () => (/* binding */ GetMobileWorkflowResolver)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _services_notification_center_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/notification-center.service */ 77668);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);




class GetMobileWorkflowResolver {
  constructor(_service, _router) {
    this._service = _service;
    this._router = _router;
  }
  resolve(route, state) {
    const requestId = route.queryParams['requestId'];
    const transId = route.queryParams['transId'];
    if (!requestId || !transId) return rxjs__WEBPACK_IMPORTED_MODULE_1__.EMPTY;
    return this._service.getMobileWorkflowNotificationDetails(requestId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(x => {
      if (!x) this._router.navigate(['/mobile-workflow'], {});
      return x;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(_ => {
      // this._router.navigate(['/error'], {});
      return rxjs__WEBPACK_IMPORTED_MODULE_1__.EMPTY;
    }));
  }
  static #_ = this.ɵfac = function GetMobileWorkflowResolver_Factory(t) {
    return new (t || GetMobileWorkflowResolver)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_services_notification_center_service__WEBPACK_IMPORTED_MODULE_0__.NotificationCenterService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
    token: GetMobileWorkflowResolver,
    factory: GetMobileWorkflowResolver.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 72202:
/*!************************************************************************************************!*\
  !*** ./src/app/modules/mobile-workflow/mobile-workflow-base/mobile-workflow-base.component.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileWorkflowBaseComponent": () => (/* binding */ MobileWorkflowBaseComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 60124);


class MobileWorkflowBaseComponent {
  static #_ = this.ɵfac = function MobileWorkflowBaseComponent_Factory(t) {
    return new (t || MobileWorkflowBaseComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: MobileWorkflowBaseComponent,
    selectors: [["app-mobile-workflow-base"]],
    decls: 1,
    vars: 0,
    template: function MobileWorkflowBaseComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 522:
/*!****************************************************************************************************************!*\
  !*** ./src/app/modules/mobile-workflow/mobile-workflow-notification/mobile-workflow-notification.component.ts ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileWorkflowNotificationComponent": () => (/* binding */ MobileWorkflowNotificationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 26078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_notification_center_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/notification-center.service */ 77668);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! angular2-notifications */ 55609);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_confirmation_dialog_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/confirmation-dialog.service */ 88407);












const _c0 = ["notificationComponent"];
function MobileWorkflowNotificationComponent_form_1_ng_container_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 5)(2, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Inspection Date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "input", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 5)(7, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Traveling Time (hours)");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 5)(11, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "Location");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "textarea", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 5)(15, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16, "Team Members");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](17, "textarea", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](5, 1, ctx_r2.inspectionDate, "yyyy-MM-dd"));
  }
}
function MobileWorkflowNotificationComponent_form_1_div_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "label", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate1"]("id", "Instructions-", item_r4.instructionDescription, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("checked", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate1"]("for", "Instructions-", item_r4.instructionDescription, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r4.instructionDescription, " ");
  }
}
function MobileWorkflowNotificationComponent_form_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 3)(1, "div", 4)(2, "div", 5)(3, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Address");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "input", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 5)(7, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Contact Person Phone");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "input", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 5)(11, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "Downpayment Amount");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "input", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 5)(15, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16, "Fahes Receipt No");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](17, "input", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "div", 5)(19, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20, "No. Of Vehicle");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](21, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "div", 5)(23, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, "Owner Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](25, "input", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "div", 5)(27, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "PID No");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](29, "input", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "div", 5)(31, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](32, "Remaining Balance");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](33, "input", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "div", 5)(35, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](36, "Secondry Phone No");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](37, "input", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](38, "div", 5)(39, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](40, "Step Remarks");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](41, "textarea", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](42, MobileWorkflowNotificationComponent_form_1_ng_container_42_Template, 18, 4, "ng-container", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](43, "div", 5)(44, "label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](45, "Gate Pass Flag");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](46, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](47, "input", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](48, "label", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](49, " Required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](50, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](51, "input", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](52, "label", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](53, " Not Required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](54, "div", 22)(55, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](56, "Instructions :");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](57, MobileWorkflowNotificationComponent_form_1_div_57_Template, 4, 4, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r0.formView);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.stepId !== 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("id", "gatepassFlag")("value", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("id", "gatepassFlag")("value", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.instructions);
  }
}
function MobileWorkflowNotificationComponent_form_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 5)(2, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, " Inspection Date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "input", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 5)(9, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, " Traveling Time (hours)");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 5)(15, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16, " Location ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](19, "textarea", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "div", 5)(21, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, " Team Members ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](25, "textarea", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](7, 1, ctx_r5.inspectionDate, "yyyy-MM-dd"));
  }
}
function MobileWorkflowNotificationComponent_form_2_button_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MobileWorkflowNotificationComponent_form_2_button_10_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r9);
      const a_r7 = restoredCtx.$implicit;
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.submit(a_r7.lkCodeValue));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const a_r7 = ctx.$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", ctx_r6.form.invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](a_r7.lkValueEname);
  }
}
function MobileWorkflowNotificationComponent_form_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 31)(1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, MobileWorkflowNotificationComponent_form_2_ng_container_2_Template, 26, 4, "ng-container", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 32)(4, "label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, " Remarks ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "textarea", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, MobileWorkflowNotificationComponent_form_2_button_10_Template, 2, 2, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r1.form);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.stepId == 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r1.actions);
  }
}
class MobileWorkflowNotificationComponent {
  constructor(_route, location, _fb, _service, notificationService, _lookups, _dialog) {
    this._route = _route;
    this.location = location;
    this._fb = _fb;
    this._service = _service;
    this.notificationService = notificationService;
    this._lookups = _lookups;
    this._dialog = _dialog;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subscription();
    this.stepId = 1;
    this.instructions = [];
  }
  ngOnInit() {
    this.initFormView();
    this.getResolved();
  }
  getResolved() {
    const sub = this._route.data.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(el => el['data'])).subscribe(res => {
      if (res) {
        this.items = res;
        this.stepId = res.stepId;
        this.initForm();
        this.getActions();
        this.getMobileWorkflowInstructions();
        // this.itemsToShow = [
        //   { label: 'Address', value: res.address },
        //   { label: 'Contact Person Phone', value: res.contactPersonPhone },
        //   { label: 'Downpayment Amount', value: res.downpaymentAmount },
        //   { label: 'Fahes Receipt No', value: res.fahesReceiptNo },
        //   // {
        //   //   label: 'Inspection Date',
        //   //   value: res.inspectionDate,
        //   //   isDate: true,
        //   // },
        //   // {
        //   //   label: 'Inspection Start Date',
        //   //   value: res.inspectionStartDate,
        //   //   isDate: true,
        //   // },
        //   // {
        //   //   label: 'Inspection End Date',
        //   //   value: res.inspectionEndDate,
        //   //   isDate: true,
        //   // },
        //   { label: 'Gate Pass Flag', value: res.gatepassFlag, isBool: true },
        //   // { label: 'Inspection Duration', value: res.inspectionDuration },
        //   { label: 'No. Of Vehicle', value: res.noOfVehicle },
        //   { label: 'Owner Name', value: res.ownerName },
        //   { label: 'PID No', value: res.pidNo },
        //   { label: 'Remaining Balance', value: res.remainingBalance },
        //   // { label: 'Remarks', value: res.remarks },
        //   // { label: 'Step Remarks', value: res.stepRemarks },
        //   { label: 'Secondry Phone No', value: res.secondryPhoneNo },
        //   // { label: 'Traveling Time', value: res.travelingTime },
        // ];
        this.formView.patchValue(res);
        if (this.stepId === 1) {
          // console.log(new Date(this.items.inspectionDate));
          this.form.patchValue({
            inspectionDate: (0,_angular_common__WEBPACK_IMPORTED_MODULE_7__.formatDate)(this.items.inspectionDate, 'yyyy-MM-dd', 'en'),
            travelingTime: this.items.travelingTime
          });
          this.inspectionDate = new Date(this.items.inspectionDate);
        } else {
          // this.itemsToShow.push(
          //   { label: 'Traveling Time', value: res.travelingTime },
          //   {
          //     label: 'Inspection Date',
          //     value: res.inspectionDate,
          //     isDate: true,
          //   }
          // );
          this.formView.addControl('travelingTime', new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl({
            value: res.travelingTime,
            disabled: true
          }));
          this.formView.addControl('inspectionDate', new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl({
            value: (0,_angular_common__WEBPACK_IMPORTED_MODULE_7__.formatDate)(res.inspectionDate, 'yyyy-MM-dd', 'en'),
            disabled: true
          }));
        }
        this.form.controls['requestId'].patchValue(res.requestId);
      }
    });
    this.subscription.add(sub);
    const paramsSub = this._route.queryParamMap.subscribe(x => this.form.controls['transId'].patchValue(+x.get('transId')));
    this.subscription.add(paramsSub);
  }
  getActions() {
    this._lookups.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_0__.SystemLookupCodes.MobileWorkflowActions).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(x => x.items)).subscribe(res => {
      this.actions = res;
      if (this.stepId == 1) {
        this.actions = this.actions.filter(x => x.lkCodeValue != 2);
      }
    });
  }
  getMobileWorkflowInstructions() {
    this._service.getMobileWorkflowInstructions(this.stepId).subscribe(res => this.instructions = res);
  }
  initForm() {
    switch (this.stepId) {
      case 1:
        this.firstStepFormInit();
        break;
      case 2:
        this.otherFormsInit();
        break;
      case 3:
        this.otherFormsInit();
        break;
    }
  }
  initFormView() {
    this.formView = this._fb.group({
      secondryPhoneNo: [{
        value: null,
        disabled: true
      }],
      remainingBalance: [{
        value: null,
        disabled: true
      }],
      pidNo: [{
        value: null,
        disabled: true
      }],
      ownerName: [{
        value: null,
        disabled: true
      }],
      noOfVehicle: [{
        value: null,
        disabled: true
      }],
      gatepassFlag: [{
        value: null,
        disabled: true
      }],
      fahesReceiptNo: [{
        value: null,
        disabled: true
      }],
      downpaymentAmount: [{
        value: null,
        disabled: true
      }],
      contactPersonPhone: [{
        value: null,
        disabled: true
      }],
      address: [{
        value: null,
        disabled: true
      }],
      location: [{
        value: null,
        disabled: true
      }],
      teamMembers: [{
        value: null,
        disabled: true
      }],
      stepRemarks: [{
        value: null,
        disabled: true
      }],
      Instructions: [{
        value: [],
        disabled: true
      }]
    });
  }
  firstStepFormInit() {
    this.form = this._fb.group({
      transId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      requestId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      actionType: [null],
      userRemarks: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      location: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      inspectionDate: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      travelingTime: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      teamMembers: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required]
    });
  }
  otherFormsInit() {
    this.form = this._fb.group({
      transId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      requestId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      actionType: [null],
      userRemarks: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required]
    });
  }
  submit(action) {
    this.form.controls['actionType'].patchValue(action);
    if (this.form.invalid) return;
    if (this.stepId == 1) {
      this.submitFirstStep();
    } else {
      this.moveWorkflow(this.form.getRawValue());
    }
  }
  submitFirstStep() {
    this._service.UpdateMobileBooking(this.form.getRawValue()).subscribe(res => {
      if (res) {
        this.moveWorkflow(this.form.getRawValue());
      }
    });
  }
  moveWorkflow(body) {
    this._service.submitMobileWorkflowNotification(body).subscribe({
      next: res => {
        if (res) {
          // this.notificationService.success(
          //   'Success',
          //   'completed successfully',
          //   {
          //     timeOut: 3000,
          //     position: ['top', 'center'],
          //   }
          // );
          this._dialog.showSuccess("completed successfully");
          this._service.sendClickEvent();
          this.location.back();
        }
      }
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function MobileWorkflowNotificationComponent_Factory(t) {
    return new (t || MobileWorkflowNotificationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_7__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_notification_center_service__WEBPACK_IMPORTED_MODULE_1__.NotificationCenterService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](angular2_notifications__WEBPACK_IMPORTED_MODULE_10__.NotificationsService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_2__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_confirmation_dialog_service__WEBPACK_IMPORTED_MODULE_3__.ConfirmationDialogService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: MobileWorkflowNotificationComponent,
    selectors: [["app-mobile-workflow-notification"]],
    viewQuery: function MobileWorkflowNotificationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.notificationComponent = _t.first);
      }
    },
    decls: 3,
    vars: 2,
    consts: [[1, "row", "bg-white", "p-3", "m-auto"], [3, "formGroup", 4, "ngIf"], ["class", "bg-white p-3", 3, "formGroup", 4, "ngIf"], [3, "formGroup"], [1, "row"], [1, "col-md-6", "col-lg-6"], [1, "st-label"], ["formControlName", "address", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "contactPersonPhone", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "downpaymentAmount", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "fahesReceiptNo", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "noOfVehicle", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "ownerName", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "pidNo", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "remainingBalance", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "secondryPhoneNo", "type", "text", 1, "txtarea", "w-100"], ["formControlName", "stepRemarks", "placeholder", "Write here...", 1, "txtarea", "w-100"], [4, "ngIf"], [1, "w-100", "st-label"], [1, "form-check", "d-inline-block"], ["type", "radio", "name", "gatepassFlag", "formControlName", "gatepassFlag", 3, "id", "value"], ["for", "gatepassFlag", 1, "form-check-label"], [1, "col-lg-6", "col-md-6"], ["class", "form-check", 4, "ngFor", "ngForOf"], ["formControlName", "inspectionDate", "type", "date", 1, "txtarea", "w-100", 3, "value"], ["formControlName", "travelingTime", "type", "number", 1, "txtarea", "w-100"], ["formControlName", "location", "placeholder", "Write here...", 1, "txtarea", "w-100"], ["formControlName", "teamMembers", 1, "txtarea", "w-100"], [1, "form-check"], ["type", "checkbox", "formControlName", "Instructions", 1, "form-check-input", 3, "checked", "id"], [1, "form-check-label", 3, "for"], [1, "bg-white", "p-3", 3, "formGroup"], [1, "col-12"], ["formControlName", "userRemarks", "placeholder", "Write here...", 1, "txtarea", "w-100"], [1, "w-100", "end-btns"], ["type", "button", "class", "btn btn-outline-gray", 3, "disabled", "click", 4, "ngFor", "ngForOf"], ["formControlName", "teamMembers", "placeholder", "Write here...", 1, "txtarea", "w-100"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "disabled", "click"]],
    template: function MobileWorkflowNotificationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, MobileWorkflowNotificationComponent_form_1_Template, 58, 7, "form", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, MobileWorkflowNotificationComponent_form_2_Template, 11, 3, "form", 2);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.formView);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.form);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControlName, _angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 47596:
/*!*******************************************************************!*\
  !*** ./src/app/modules/mobile-workflow/mobile-workflow.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileWorkflowModule": () => (/* binding */ MobileWorkflowModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _mobile_workflow_base_mobile_workflow_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mobile-workflow-base/mobile-workflow-base.component */ 72202);
/* harmony import */ var _mobile_workflow_notification_mobile_workflow_notification_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mobile-workflow-notification/mobile-workflow-notification.component */ 522);
/* harmony import */ var src_app_core_resolver_get_mobile_workflow_resolver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/resolver/get-mobile-workflow.resolver */ 93739);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);









const routes = [{
  path: '',
  component: _mobile_workflow_base_mobile_workflow_base_component__WEBPACK_IMPORTED_MODULE_0__.MobileWorkflowBaseComponent,
  children: [{
    path: '',
    component: _mobile_workflow_notification_mobile_workflow_notification_component__WEBPACK_IMPORTED_MODULE_1__.MobileWorkflowNotificationComponent,
    runGuardsAndResolvers: "pathParamsOrQueryParamsChange",
    resolve: {
      data: src_app_core_resolver_get_mobile_workflow_resolver__WEBPACK_IMPORTED_MODULE_2__.GetMobileWorkflowResolver
    }
  }]
}];
class MobileWorkflowModule {
  static #_ = this.ɵfac = function MobileWorkflowModule_Factory(t) {
    return new (t || MobileWorkflowModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
    type: MobileWorkflowModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](MobileWorkflowModule, {
    declarations: [_mobile_workflow_base_mobile_workflow_base_component__WEBPACK_IMPORTED_MODULE_0__.MobileWorkflowBaseComponent, _mobile_workflow_notification_mobile_workflow_notification_component__WEBPACK_IMPORTED_MODULE_1__.MobileWorkflowNotificationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=596.f500e0acb68a0bfe.js.map