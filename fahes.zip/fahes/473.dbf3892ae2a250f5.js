"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[473],{

/***/ 39553:
/*!**************************************************!*\
  !*** ./src/app/core/models/device-input-code.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceInputCode": () => (/* binding */ DeviceInputCode)
/* harmony export */ });
class DeviceInputCode {
  constructor(codeOperation, codeValues) {
    this.codeOperation = codeOperation;
    this.codeValues = codeValues;
  }
}

/***/ }),

/***/ 17238:
/*!***************************************************!*\
  !*** ./src/app/core/models/device-results-dto.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceInspectionProcessDto": () => (/* binding */ DeviceInspectionProcessDto),
/* harmony export */   "DeviceResultsDto": () => (/* binding */ DeviceResultsDto),
/* harmony export */   "DeviceSectionInspectionDto": () => (/* binding */ DeviceSectionInspectionDto)
/* harmony export */ });
class DeviceResultsDto {}
class DeviceInspectionProcessDto {}
class DeviceSectionInspectionDto {}

/***/ }),

/***/ 36591:
/*!***************************************************!*\
  !*** ./src/app/core/models/inspection-request.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionRequest": () => (/* binding */ InspectionRequest)
/* harmony export */ });
class InspectionRequest {
  constructor(details) {
    Object.assign(this, details);
  }
}

/***/ }),

/***/ 23776:
/*!************************************************************!*\
  !*** ./src/app/core/models/save-sub-defects-new-device.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveSubDefectCommentsNewDevice": () => (/* binding */ SaveSubDefectCommentsNewDevice)
/* harmony export */ });
class SaveSubDefectCommentsNewDevice {}

/***/ }),

/***/ 46587:
/*!****************************************************************!*\
  !*** ./src/app/core/models/visual-defects/save-sub-defects.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveSubDefectComments": () => (/* binding */ SaveSubDefectComments)
/* harmony export */ });
class SaveSubDefectComments {
  constructor(details) {
    Object.assign(this, details);
  }
}

/***/ }),

/***/ 11428:
/*!*************************************************************!*\
  !*** ./src/app/core/services/inspection-service.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionServiceService": () => (/* binding */ InspectionServiceService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class InspectionServiceService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Inspection/v1';
  }
  searchInpsectionRequestDetails(searchType, searchText, serviceType, sectionId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/SearchInpsectionRequestDetails`, {
      searchType,
      searchText,
      serviceType,
      sectionId
    });
  }
  getInspectionDetailsByPlateNoAndPlateType(plateNo, plateType) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByPlateNoAndPlateType`, {
      plateNo,
      plateType
    });
  }
  getInspectionDetailsByVinNo(vinNo) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByVinNoDTO`, {
      vinNo
    });
  }
  getInspectionDetailsByRequestId(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByRequestId`, {
      requestId
    });
  }
  getInspectionDetailsByReceiptNo(receiptNo) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionDetailsByReceiptNo`, {
      receiptNo
    });
  }
  createInspectionRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionRequest`, body);
  }
  getInspectionInstructionsByRequestId(inspectionId, sectionId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionInstructionsByRequestId`, {
      inspectionId,
      sectionId
    });
  }
  getInspectionDefects(inspectionRequest) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionDefects`, {
      inspectionReqId: inspectionRequest
    });
  }
  deleteInspectionDefect(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/deleteInspectionDefect`, body);
  }
  getExternalInspectionRequests(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getExternalInspectionRequests`, body);
  }
  getHistoryExternalInspectionRequests(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getHistoryExternalInspectionRequests`, body);
  }
  createInspectionStep(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionStep`, body);
  }
  submitTankerCertificateRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitTankerCertificateRequest`, body);
  }
  getQatarVinNumbersDetails(categoryId, requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getQatarVinNumbersDetails`, {
      categoryId,
      requestId
    });
  }
  submitVinStampingRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitVinStampingRequest`, body);
  }
  submitInspectionRequest(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitInspectionRequest`, {
      requestId
    });
  }
  getInspectedVehicleReportDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectedVehicleReportDetails`, body);
  }
  getSubServices(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSubServices`, body);
  }
  insertInspectionResultsReportLog(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/insertInspectionResultsReportLog`, body);
  }
  fillInspectionTankValues(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/fillInspectionTankValues`, body);
  }
  finishInspectionStep(inspectionStepId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/finishInspectionStep`, {
      inspectionStepId
    });
  }
  getFinalInspectionDeviceResult(deviceInspectionProcessDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getFinalInspectionDeviceResult`, deviceInspectionProcessDto);
  }
  getDeviceInspectionReads(deviceSectionInspectionDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getDeviceInspectionReads`, deviceSectionInspectionDto);
  }
  getInspectionResultDetails(baseInspectionRequestDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionResultDetails`, baseInspectionRequestDto);
  }
  getVINSequences(body) {
    return this.fahesApiService.post(`${this.baseUrl}/MOI/v1/getVINSequences`, body);
  }
  calculateTankerCertificateVolume(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/calculateTankerCertificateVolume`, body);
  }
  startExternalInspectionRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/startExternalInspectionRequest`, body);
  }
  getInspectionRegisterVehicle(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionRegisterVehicle`, body);
  }
  getSubDefectNameById(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSubDefectNameById`, body);
  }
  getPreviousDeviceDefects(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getPreviousDeviceDefects`, body);
  }
  static #_ = this.ɵfac = function InspectionServiceService_Factory(t) {
    return new (t || InspectionServiceService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: InspectionServiceService,
    factory: InspectionServiceService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 84187:
/*!*******************************************************************!*\
  !*** ./src/app/core/utilities/enums/defect-comments-sort-type.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectCommentSortType": () => (/* binding */ DefectCommentSortType)
/* harmony export */ });
var DefectCommentSortType;
(function (DefectCommentSortType) {
  DefectCommentSortType["Ascending"] = "ASC";
  DefectCommentSortType["Descending"] = "DESC";
})(DefectCommentSortType || (DefectCommentSortType = {}));

/***/ }),

/***/ 81295:
/*!**********************************************************!*\
  !*** ./src/app/core/utilities/enums/defect-selection.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectSelectionMode": () => (/* binding */ DefectSelectionMode)
/* harmony export */ });
var DefectSelectionMode;
(function (DefectSelectionMode) {
  DefectSelectionMode[DefectSelectionMode["Main"] = 1] = "Main";
  DefectSelectionMode[DefectSelectionMode["Sub"] = 2] = "Sub";
  DefectSelectionMode[DefectSelectionMode["Comments"] = 3] = "Comments";
})(DefectSelectionMode || (DefectSelectionMode = {}));

/***/ }),

/***/ 74676:
/*!***********************************************************************!*\
  !*** ./src/app/core/utilities/enums/device-inspection-status.enum.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceInspectionStatus": () => (/* binding */ DeviceInspectionStatus)
/* harmony export */ });
var DeviceInspectionStatus;
(function (DeviceInspectionStatus) {
  DeviceInspectionStatus[DeviceInspectionStatus["InProgress"] = 1] = "InProgress";
  DeviceInspectionStatus[DeviceInspectionStatus["Complete"] = 2] = "Complete";
})(DeviceInspectionStatus || (DeviceInspectionStatus = {}));

/***/ }),

/***/ 33219:
/*!********************************************************************!*\
  !*** ./src/app/core/utilities/enums/external-inspection-status.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExternalInpsectionStatus": () => (/* binding */ ExternalInpsectionStatus)
/* harmony export */ });
var ExternalInpsectionStatus;
(function (ExternalInpsectionStatus) {
  ExternalInpsectionStatus[ExternalInpsectionStatus["InProgress"] = 1] = "InProgress";
  ExternalInpsectionStatus[ExternalInpsectionStatus["Hold"] = 2] = "Hold";
})(ExternalInpsectionStatus || (ExternalInpsectionStatus = {}));

/***/ }),

/***/ 40681:
/*!***************************************************************************!*\
  !*** ./src/app/core/utilities/enums/inspection-save-action-types.enum.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionSaveActionTypes": () => (/* binding */ InspectionSaveActionTypes)
/* harmony export */ });
var InspectionSaveActionTypes;
(function (InspectionSaveActionTypes) {
  InspectionSaveActionTypes[InspectionSaveActionTypes["Save"] = 1] = "Save";
  InspectionSaveActionTypes[InspectionSaveActionTypes["SaveAndUpdate"] = 2] = "SaveAndUpdate";
})(InspectionSaveActionTypes || (InspectionSaveActionTypes = {}));

/***/ }),

/***/ 54733:
/*!******************************************************!*\
  !*** ./src/app/core/utilities/enums/main-defects.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainDefectEnum": () => (/* binding */ MainDefectEnum)
/* harmony export */ });
var MainDefectEnum;
(function (MainDefectEnum) {
  MainDefectEnum[MainDefectEnum["BrakeSystem"] = 2100] = "BrakeSystem";
  MainDefectEnum[MainDefectEnum["SteeringSystem"] = 2200] = "SteeringSystem";
  MainDefectEnum[MainDefectEnum["Visibility"] = 2300] = "Visibility";
  MainDefectEnum[MainDefectEnum["LightingSystem"] = 2400] = "LightingSystem";
  MainDefectEnum[MainDefectEnum["AxlesSuspensionWheelsTires"] = 2500] = "AxlesSuspensionWheelsTires";
  MainDefectEnum[MainDefectEnum["ChassisAndBody"] = 2600] = "ChassisAndBody";
  MainDefectEnum[MainDefectEnum["EngineAndGearbox"] = 2700] = "EngineAndGearbox";
  MainDefectEnum[MainDefectEnum["OtherEquipments"] = 2800] = "OtherEquipments";
  MainDefectEnum[MainDefectEnum["Environment"] = 2900] = "Environment";
  MainDefectEnum[MainDefectEnum["PublicTransport"] = 3000] = "PublicTransport";
  MainDefectEnum[MainDefectEnum["LegalRequirements"] = 3100] = "LegalRequirements";
  MainDefectEnum[MainDefectEnum["WaterTanker"] = 4100] = "WaterTanker";
})(MainDefectEnum || (MainDefectEnum = {}));

/***/ }),

/***/ 53805:
/*!*******************************************************************!*\
  !*** ./src/app/core/utilities/enums/system-lookup-value-codes.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemLookupValueCodes": () => (/* binding */ SystemLookupValueCodes)
/* harmony export */ });
var SystemLookupValueCodes;
(function (SystemLookupValueCodes) {
  //Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["Inspection"] = 1] = "Inspection";
  SystemLookupValueCodes[SystemLookupValueCodes["VINStamping"] = 2] = "VINStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["TankerCertificate"] = 3] = "TankerCertificate";
  SystemLookupValueCodes[SystemLookupValueCodes["Exempted"] = 4] = "Exempted";
  SystemLookupValueCodes[SystemLookupValueCodes["MobileInspection"] = 4] = "MobileInspection";
  //Registration Resource :
  SystemLookupValueCodes[SystemLookupValueCodes["MoblieApplication"] = 1] = "MoblieApplication";
  SystemLookupValueCodes[SystemLookupValueCodes["Booth"] = 2] = "Booth";
  SystemLookupValueCodes[SystemLookupValueCodes["BackOffice"] = 3] = "BackOffice";
  SystemLookupValueCodes[SystemLookupValueCodes["SupportDocuments"] = 1] = "SupportDocuments";
  SystemLookupValueCodes[SystemLookupValueCodes["InspectionImages"] = 2] = "InspectionImages";
  // Vin Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["NewStamping"] = 1] = "NewStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["ReStamping"] = 2] = "ReStamping";
})(SystemLookupValueCodes || (SystemLookupValueCodes = {}));

/***/ }),

/***/ 12452:
/*!********************************************************!*\
  !*** ./src/app/core/utilities/object-value-checker.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ObjectValueChecker": () => (/* binding */ ObjectValueChecker)
/* harmony export */ });
class ObjectValueChecker {
  static isNullOrEmpty(value) {
    if (value != null && value != '') return true;else return false;
  }
}

/***/ }),

/***/ 82412:
/*!******************************************************************************************!*\
  !*** ./src/app/modules/inspection/components/delete-confirm/delete-confirm.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteConfirmComponent": () => (/* binding */ DeleteConfirmComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class DeleteConfirmComponent {
  ngOnInit() {}
  confirmDelete() {}
  static #_ = this.ɵfac = function DeleteConfirmComponent_Factory(t) {
    return new (t || DeleteConfirmComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DeleteConfirmComponent,
    selectors: [["app-delete-confirm"]],
    decls: 16,
    vars: 0,
    consts: [[1, "modal-content"], [1, "modal-header"], [1, "modal-body"], [1, "row"], [1, "col-12"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"]],
    template: function DeleteConfirmComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2)(3, "div", 3)(4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, " Are you sure you want to delete the defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "br")(11, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "img", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DeleteConfirmComponent_Template_button_click_14_listener() {
          return ctx.confirmDelete();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "img", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 16564:
/*!**************************************************************************************!*\
  !*** ./src/app/modules/inspection/components/landing-page/landing-page.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingPageComponent": () => (/* binding */ LandingPageComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);











const _c0 = ["barCodeId"];
const _c1 = ["barCodeId2"];
function LandingPageComponent_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Please, click Enter to proceed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_55_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 35)(1, "label", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Istimara Bar Code * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "input", 37, 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("keyup.enter", function LandingPageComponent_div_55_Template_input_keyup_enter_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r11.onIstimaraInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, LandingPageComponent_div_55_div_5_Template, 2, 0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r3.landingForm.get("istimaraCode").hasError("pattern"));
  }
}
function LandingPageComponent_div_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 25)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Vin No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_57_option_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Inspection Service ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_57_option_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " VIN Stamping ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_57_option_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Tanker Certificate ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 25)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Service Type * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "select", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, LandingPageComponent_div_57_option_4_Template, 2, 0, "option", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, LandingPageComponent_div_57_option_5_Template, 2, 0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, LandingPageComponent_div_57_option_6_Template, 2, 0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.activeIns);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.activeVin);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.activeTank);
  }
}
function LandingPageComponent_div_58_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 25)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Receipt Number * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "input", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, LandingPageComponent_div_58_div_4_Template, 2, 0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.landingForm.get("inputReqNo").invalid && ctx_r6.landingForm.get("inputReqNo").touched);
  }
}
function LandingPageComponent_div_60_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 48)(1, "button", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_div_60_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r17.manualEntry());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Inspect ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", ctx_r7.activeButton == 1 && (!ctx_r7.landingForm.get("istimaraCode").value || !ctx_r7.landingForm.get("selectServiceType").value) || ctx_r7.activeButton == 2 && (!ctx_r7.landingForm.get("inputVinNo").value || !ctx_r7.landingForm.get("selectServiceType").value) || ctx_r7.activeButton == 3 && !ctx_r7.landingForm.get("inputReqNo").value);
  }
}
function LandingPageComponent_div_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Enter all fields ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
const _c2 = function (a0) {
  return {
    "active": a0
  };
};
class LandingPageComponent {
  constructor(formBuilder, router, sharedDataService, lookupServ, sideNav, sharedLookup, el, renderer, vehicleService, insService) {
    this.formBuilder = formBuilder;
    this.router = router;
    this.sharedDataService = sharedDataService;
    this.lookupServ = lookupServ;
    this.sideNav = sideNav;
    this.sharedLookup = sharedLookup;
    this.el = el;
    this.renderer = renderer;
    this.vehicleService = vehicleService;
    this.insService = insService;
    this.submitted = false;
    this.fillFields = false;
    this.isBarCodeScanned = false;
    this.isModalOpen = false;
    this.registeredVehicles = [];
    this.offers = [];
    this.landingForm = formBuilder.group({
      // inputPlateType: [null, Validators.required],
      // inputPlateNo: [null, Validators.required],
      inputVinNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      inputReqNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      selectServiceType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      plateTypes: [[]],
      isPlate: [false],
      isVin: [false],
      isReq: [false],
      // displayBarCode: ['', [Validators.required, Validators.pattern(/^.{3,8}$/)]],
      displayBarCode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
      istimaraCode: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.pattern(/^.{3,8}$/)]]
    });
  }
  ngOnInit() {
    this.sideNav.setHeaderValue(true, false);
    this.sideNav.setActiveEnt(3, 36);
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.landingForm.get('plateTypes').setValue(data);
    });
    //   const carImagePopModal = this.el.nativeElement.querySelector('#receiptNo');
    //  this.renderer.addClass(carImagePopModal, 'show');
    // this.renderer.setStyle(carImagePopModal, 'display', 'block');
    this.insService.getInspectionRegisterVehicle({
      stationId: this.stationId,
      pageSize: 1000,
      pageNumber: 1
    }).subscribe(response => {
      response.items.map(item => {
        const plateType = ('0' + item.plateType).slice(-2);
        const plateNo = ('000000' + item.plateNo).slice(-6);
        this.registeredVehicles.push(plateType + plateNo);
      });
    });
    this.landingForm.get('istimaraCode').valueChanges.subscribe(value => {
      let serviceCalled = false;
      if (this.landingForm.get('istimaraCode').value && this.landingForm.get('istimaraCode').value.length > 3) {
        for (let rg of this.registeredVehicles) {
          if (rg == this.landingForm.get('istimaraCode').value && !serviceCalled) {
            this.checkServices();
            serviceCalled = true;
          }
        }
      }
    });
    const receiptModal = this.el.nativeElement.querySelector('#receiptNo');
    this.renderer.addClass(receiptModal, 'show');
    this.renderer.setStyle(receiptModal, 'display', 'block');
    this.scanIstimara();
  }
  closeReceipt() {
    const modalElement = document.getElementById('receiptNo');
    if (modalElement) {
      modalElement.classList.remove('show');
      modalElement.style.display = 'none';
      document.body.classList.remove('modal-open');
      const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
      if (modalBackdrop) {
        modalBackdrop.remove();
      }
      document.body.style.overflow = 'auto';
    }
  }
  scanIstimara() {
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#barCodeId');
      if (myInput) {
        myInput.focus();
      }
    }, 300);
  }
  get formControls() {
    return this.landingForm.controls;
  }
  onBarcodeInput(event) {
    console.log("test");
    const barcodeValue = event.target.value;
    this.landingForm.get('displayBarCode').setValue(barcodeValue);
    this.isBarCodeScanned = true;
    this.readBarCode();
  }
  onIstimaraInput(event) {
    this.manualEntry();
  }
  checkServices() {
    console.log(this.landingForm.get('istimaraCode').value);
    const plateType = parseInt(this.landingForm.get('istimaraCode').value.substring(0, 2));
    const plateNo = parseInt(this.landingForm.get('istimaraCode').value.substring(2));
    const vehDetails = {
      plateNo: plateNo,
      plateType: plateType,
      stationId: this.stationId
    };
    this.vehicleService.getVehicleDetails(vehDetails).subscribe(response => {
      const servDets = {
        categoryId: response.items.categoryId,
        plateNo: plateNo,
        plateType: plateType,
        stationId: this.stationId
      };
      this.vehicleService.getVehicleServices(servDets).subscribe(response => {
        for (const ins of response.items.inspectionServices) {
          if (ins.isActive && ins.isPaid) {
            this.activeIns = true;
            this.landingForm.get('selectServiceType').setValue(1);
          }
        }
        for (const vins of response.items.vinStampingServices) {
          if (vins.isActive && vins.isPaid) {
            this.activeVin = true;
            if (!this.activeIns) {
              this.landingForm.get('selectServiceType').setValue(2);
            }
          }
        }
        for (const tanks of response.items.tankerCertServices) {
          if (tanks.isActive && tanks.isPaid) {
            this.activeTank = true;
            if (!this.activeIns && !this.activeVin) {
              this.landingForm.get('selectServiceType').setValue(3);
            }
          }
        }
      });
    });
  }
  readBarCode() {
    const displayBarCodeControl = this.landingForm.get('displayBarCode');
    if (displayBarCodeControl.valid) {
      //this.sharedDataService.setBarCodeIns(this.landingForm.get('displayBarCode').value);
      this.sharedDataService.setRecNo(this.landingForm.get('displayBarCode').value);
      this.router.navigate(['inspection/vehicle-inspection']);
      const modalElement = document.getElementById('receiptNo');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    }
  }
  showPlate() {
    this.landingForm.get("isPlate").setValue(true);
    this.landingForm.get("isVin").setValue(false);
    this.landingForm.get("isReq").setValue(false);
    this.activeIns = false;
    this.activeVin = false;
    this.activeTank = false;
    this.landingForm.get('selectServiceType').setValue(null);
    this.checkServices();
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#barCodeId2');
      if (myInput) {
        myInput.focus();
      }
    }, 300);
    this.activeButton = 1;
  }
  showVin() {
    this.landingForm.get("isVin").setValue(true);
    this.landingForm.get("isPlate").setValue(false);
    this.landingForm.get("isReq").setValue(false);
    this.activeIns = true;
    this.activeVin = true;
    this.activeTank = true;
    this.landingForm.get('selectServiceType').setValue(1);
    this.activeButton = 2;
  }
  showRequestNo() {
    this.landingForm.get("isReq").setValue(true);
    this.landingForm.get("isVin").setValue(false);
    this.landingForm.get("isPlate").setValue(false);
    this.activeButton = 3;
  }
  manualEntry() {
    if (this.landingForm.get("isPlate").value) {
      if (this.landingForm.get('istimaraCode').value) {
        this.sharedDataService.setBarCodeIns(this.landingForm.get('istimaraCode').value);
        this.sharedDataService.setServiceType(parseInt(this.landingForm.get('selectServiceType').value));
        console.log(parseInt(this.landingForm.get('selectServiceType').value));
        this.fillFields = false;
        this.sharedDataService.setVinNo('');
        this.router.navigate(['inspection/vehicle-inspection']);
      }
      // if (this.landingForm.get('inputPlateNo').value) {
      //   this.sharedDataService.setPlateNo(this.landingForm.get('inputPlateNo').value);
      //   this.sharedDataService.setPlateType(this.landingForm.get('inputPlateType').value);
      //   console.log(this.landingForm.get('selectServiceType').value);
      //   this.sharedDataService.setServiceType(this.landingForm.get('selectServiceType').value);
      //   this.fillFields = false;
      //   this.sharedDataService.setVinNo('');
      //   this.router.navigate(['inspection/vehicle-inspection']);
      // }
      // else {
      //   this.fillFields = true;
      // }
    }

    if (this.landingForm.get("isVin").value) {
      if (this.landingForm.get('inputVinNo').value) {
        this.sharedDataService.setVinNo(this.landingForm.get('inputVinNo').value);
        this.sharedDataService.setServiceType(parseInt(this.landingForm.get('selectServiceType').value));
        this.fillFields = false;
        this.router.navigate(['inspection/vehicle-inspection']);
      } else {
        this.fillFields = true;
      }
    }
    if (this.landingForm.get("isReq").value) {
      if (this.landingForm.get("inputReqNo").value) {
        this.sharedDataService.setRecNo(this.landingForm.get('inputReqNo').value);
        this.fillFields = false;
        this.router.navigate(['inspection/vehicle-inspection']);
      } else {
        this.fillFields = true;
      }
    }
  }
  closeManual() {
    this.landingForm.reset();
  }
  static #_ = this.ɵfac = function LandingPageComponent_Factory(t) {
    return new (t || LandingPageComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_1__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_2__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_3__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_4__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_5__.InspectionServiceService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: LandingPageComponent,
    selectors: [["app-landing-page"]],
    viewQuery: function LandingPageComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.barCodeId = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.barCodeId2 = _t.first);
      }
    },
    decls: 62,
    vars: 18,
    consts: [[3, "formGroup"], [1, "main-container-wrap"], [1, "rvd"], [1, "rvd-links"], ["data-bs-toggle", "modal", "data-bs-target", "#receiptNo", 3, "click"], ["src", "./assets/img/scan.svg"], ["src", "./assets/img/camera.svg"], ["data-bs-toggle", "modal", "data-bs-target", "#manualEntry", 1, "btn", "btn-link"], ["src", "./assets/img/keyboard.svg"], ["id", "receiptNo", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["src", "./assets/img/scan.svg", "width", "50px"], ["type", "button", 1, "btn-close", 3, "click"], [1, "modal-body"], ["id", "barCodeId", "type", "text", "formControlName", "displayBarCode", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["barCodeId", ""], ["class", "error-message", 4, "ngIf"], ["class", "info-msg", 4, "ngIf"], ["id", "manualEntry", "tabindex", "-1", "aria-labelledby", "manualEntryLabel", "aria-hidden", "true", "data-bs-backdrop", "static", 1, "modal", "fade", "locPop"], ["src", "./assets/img/keyboard.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn-close", 3, "click"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "button", 1, "btn", "btn-orange", "spacious-btn", 3, "ngClass", "click"], ["id", "vinId", 1, "col-md-6", "col-lg-3"], ["class", "col-12 col-lg-3", 4, "ngIf"], ["class", "col-md-6 col-lg-3", 4, "ngIf"], [1, "col-lg-12", "sr-vc"], ["class", "check-inspection", 4, "ngIf"], ["class", "row form-fields", "class", "error-message", 4, "ngIf"], [1, "error-message"], [1, "info-msg"], [1, "col-12", "col-lg-3"], ["for", "myInput"], ["type", "text", "id", "barCode2", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "istimaraCode", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["barCode2", ""], ["type", "text", "formControlName", "inputVinNo", 1, "form-control"], ["formControlName", "selectServiceType", 1, "form-control"], ["value", "1", 4, "ngIf"], ["value", "2", 4, "ngIf"], ["value", "3", 4, "ngIf"], ["value", "1"], ["value", "2"], ["value", "3"], ["type", "text", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "inputReqNo", 1, "form-control"], [1, "check-inspection"], ["type", "submit", "data-bs-dismiss", "modal", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function LandingPageComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "form", 0)(1, "div", 1)(2, "div", 2)(3, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4, " Read Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, " Choose the preferred option ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "div", 3)(8, "a", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_a_click_8_listener() {
          return ctx.scanIstimara();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](9, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](11, "Scan Receipt");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](12, "a");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](13, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, "Capture Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](17, "img", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](19, "Manual Entry");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](20, "div", 9)(21, "div", 10)(22, "div", 11)(23, "div", 12)(24, "h1", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](25, "img", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](26, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_27_listener() {
          return ctx.closeReceipt();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "div", 16)(29, "input", 17, 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("keyup.enter", function LandingPageComponent_Template_input_keyup_enter_29_listener($event) {
          return ctx.onBarcodeInput($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](31, LandingPageComponent_div_31_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](32, LandingPageComponent_div_32_Template, 2, 0, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](33, "div", 21)(34, "div", 10)(35, "div", 11)(36, "div", 12)(37, "h1", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](38, "img", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](39, " Manual Entry ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_40_listener() {
          return ctx.closeManual();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](41, "div", 16)(42, "div", 24)(43, "div", 25)(44, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_44_listener() {
          return ctx.showPlate();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45, " Plate No - Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "div", 27)(47, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_47_listener() {
          return ctx.showVin();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](48, " VIN No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "div", 25)(50, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_50_listener() {
          return ctx.showRequestNo();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](51, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](52, "br")(53, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](54, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](55, LandingPageComponent_div_55_Template, 6, 1, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](56, LandingPageComponent_div_56_Template, 4, 0, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](57, LandingPageComponent_div_57_Template, 7, 3, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](58, LandingPageComponent_div_58_Template, 5, 1, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](60, LandingPageComponent_div_60_Template, 3, 1, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](61, LandingPageComponent_div_61_Template, 2, 0, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.landingForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("displayBarCode").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](12, _c2, ctx.activeButton === 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](14, _c2, ctx.activeButton === 2));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](16, _c2, ctx.activeButton === 3));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isPlate").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isVin").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isVin").value || ctx.landingForm.get("isPlate").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isReq").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isVin").value || ctx.landingForm.get("isPlate").value || ctx.landingForm.get("isReq").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.fillFields);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName],
    styles: ["input[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\n  appearance: none;\n  margin: 0;\n}\n\n.spacious-btn[_ngcontent-%COMP%] {\n  padding: 15px;\n  font-size: 16px;\n  white-space: nowrap;\n}\n\n#vinId[_ngcontent-%COMP%] {\n  margin-left: 17px;\n}\n\n.error-message[_ngcontent-%COMP%] {\n  color: red;\n  font-style: italic;\n}\n\n.info-msg[_ngcontent-%COMP%] {\n  color: grey;\n  font-style: italic !important;\n}\n\n.btn-orange.active[_ngcontent-%COMP%] {\n  color: #fff;\n  background: #00539B;\n  border-color: #00539B;\n}\n\n.btn-orange[_ngcontent-%COMP%]:disabled {\n  background-color: #ef9c3d;\n  color: #ffff;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL2NvbXBvbmVudHMvbGFuZGluZy1wYWdlL2xhbmRpbmctcGFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUdFLGdCQUFnQjtFQUNoQixTQUFTO0FBQ1g7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFVBQVU7RUFDVixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsNkJBQTZCO0FBQy9COztBQUVBO0VBQ0UsV0FBVztFQUNYLG1CQUFtQjtFQUNuQixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsWUFBWTtBQUNkIiwic291cmNlc0NvbnRlbnQiOlsiaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcbmlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b24ge1xuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gIGFwcGVhcmFuY2U6IG5vbmU7XG4gIG1hcmdpbjogMDtcbn1cblxuLnNwYWNpb3VzLWJ0biB7XG4gIHBhZGRpbmc6IDE1cHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbn1cblxuI3ZpbklkIHtcbiAgbWFyZ2luLWxlZnQ6IDE3cHg7XG59XG5cbi5lcnJvci1tZXNzYWdlIHtcbiAgY29sb3I6IHJlZDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xufVxuXG4uaW5mby1tc2cge1xuICBjb2xvcjogZ3JleTtcbiAgZm9udC1zdHlsZTogaXRhbGljICFpbXBvcnRhbnQ7XG59XG5cbi5idG4tb3JhbmdlLmFjdGl2ZSB7XG4gIGNvbG9yOiAjZmZmO1xuICBiYWNrZ3JvdW5kOiAjMDA1MzlCO1xuICBib3JkZXItY29sb3I6ICMwMDUzOUI7XG59XG5cbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcbiAgY29sb3I6ICNmZmZmO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 59560:
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/inspection/components/vehicle-inspection/vehicle-inspection.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleInspectionComponent": () => (/* binding */ VehicleInspectionComponent)
/* harmony export */ });
/* harmony import */ var _Users_os_Desktop_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _microsoft_signalr__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @microsoft/signalr */ 77930);
/* harmony import */ var _microsoft_signalr__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @microsoft/signalr */ 14449);
/* harmony import */ var src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/device-input-code */ 39553);
/* harmony import */ var src_app_core_models_device_results_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/device-results-dto */ 17238);
/* harmony import */ var src_app_core_models_inspection_request__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/inspection-request */ 36591);
/* harmony import */ var src_app_core_models_save_sub_defects_new_device__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/models/save-sub-defects-new-device */ 23776);
/* harmony import */ var src_app_core_utilities_enums_device_inspection_status_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utilities/enums/device-inspection-status.enum */ 74676);
/* harmony import */ var src_app_core_utilities_enums_inspection_save_action_types_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utilities/enums/inspection-save-action-types.enum */ 40681);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/utilities/object-value-checker */ 12452);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_authentication_service_ts_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/services/authentication-service.ts.service */ 21022);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var primeng_progressbar__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/progressbar */ 88395);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/dialog */ 1837);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! primeng/tooltip */ 24329);
/* harmony import */ var _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../pages/visualDefect/visual-defect-list/visual-defect-list.component */ 12207);

































function VehicleInspectionComponent_li_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "li", 4)(1, "button", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_li_10_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r47);
      const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r46.setActiveTab("vin"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2, "VIN Stamping");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleProp"]("pointer-events", !ctx_r0.insForm.get("isVinCh").value || !ctx_r0.insForm.get("isPlateCh").value || !ctx_r0.insForm.get("isManfCh").value ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx_r0.activeTab === "vin");
  }
}
function VehicleInspectionComponent_li_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "li", 4)(1, "button", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_li_11_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r49);
      const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r48.setActiveTab("tanker"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2, "Tanker Certificate ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleProp"]("pointer-events", ctx_r1.isConfirmedDefects || !ctx_r1.insForm.get("isVinCh").value || !ctx_r1.insForm.get("isPlateCh").value || !ctx_r1.insForm.get("isManfCh").value ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx_r1.activeTab === "tanker");
  }
}
function VehicleInspectionComponent_span_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " External ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 127)(1, "div", 128);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate3"](" ", ctx_r3.format(ctx_r3.mm), ":", ctx_r3.format(ctx_r3.ss), ":", ctx_r3.format(ctx_r3.ms), "");
  }
}
const _c0 = function () {
  return {
    position: "sticky",
    height: "8px",
    width: "100%",
    top: "0",
    right: "0"
  };
};
function VehicleInspectionComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 129)(1, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](3, "p-progressBar", 130);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](ctx_r4.deviceStatusDescription);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpureFunction0"](3, _c0));
  }
}
function VehicleInspectionComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 131)(1, "div", 132)(2, "div", 133)(3, "div", 134)(4, "div", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](5, "input", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](6, "label", 137);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](7, " VIN No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](8, "div", 134)(9, "div", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](10, "input", 138);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](11, "label", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](12, " License Plate No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](13, "div", 134)(14, "div", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](15, "input", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](16, "label", 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](17, " Manufacturer ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()();
  }
}
function VehicleInspectionComponent_div_126_Template(rf, ctx) {
  if (rf & 1) {
    const _r51 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 17)(1, "div", 18)(2, "div", 59)(3, "div", 25)(4, "div", 142)(5, "div", 27)(6, "h2", 143)(7, "button", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](8, " External Vehicle Milage ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](9, "div", 145)(10, "div", 31)(11, "div", 33)(12, "div", 92)(13, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](14, "Mileage(km) * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](15, "input", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](16, "div", 33)(17, "div", 92)(18, "button", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_div_126_Template_button_click_18_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r51);
      const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r50.saveConfiguration());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](19, "Confirm");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx_r6.configDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("disabled", !ctx_r6.insForm.valid || ctx_r6.savedConfig);
  }
}
function VehicleInspectionComponent_button_131_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_131_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r53);
      const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r52.nextVI());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Next ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("disabled", !(ctx_r7.insForm.get("inspectiondetails").value != undefined && ctx_r7.insForm.get("inspectiondetails").value.inspectionStepId != null) && (!ctx_r7.insForm.get("isVinCh").value || !ctx_r7.insForm.get("isPlateCh").value || !ctx_r7.insForm.get("isManfCh").value));
  }
}
function VehicleInspectionComponent_div_137_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 17)(1, "div", 148)(2, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " Qatar VIN No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](4, "input", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](5, "div", 150)(6, "button", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](7, " Send Qatar VIN No to Device");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
}
function VehicleInspectionComponent_div_138_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 17)(1, "div", 148)(2, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " Fahes Serial No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](4, "input", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](5, "div", 150)(6, "button", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](7, " Send Fahes Serial No to Device");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
}
function VehicleInspectionComponent_div_139_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 17)(1, "div", 153)(2, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " Original VIN No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4, "x ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](5, "input", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](6, "div", 150)(7, "button", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](8, " Send Original VIN No to Device");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
}
function VehicleInspectionComponent_option_161_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 155);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r54 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", item_r54.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", item_r54.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_div_162_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_167_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_172_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_177_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_183_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_200_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_201_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Note : Tanker Measurement Differs From Last Year ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_h3_213_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](1, "i", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const instruction_r55 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", instruction_r55.instructionNameEn, " ");
  }
}
function VehicleInspectionComponent_div_227_Template(rf, ctx) {
  if (rf & 1) {
    const _r57 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 159)(1, "label", 160)(2, "input", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("ngModelChange", function VehicleInspectionComponent_div_227_Template_input_ngModelChange_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r57);
      const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r56.startInspectionDevice());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](3, "div", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleProp"]("pointer-events", !ctx_r20.deviceEnableFlag ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("checked", ctx_r20.insForm.get("inspectiondetails").value.isDeviceStarted);
  }
}
function VehicleInspectionComponent_div_229_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 163)(1, "div", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](2, "input", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](3, "label", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ft_r59 = ctx.$implicit;
    const ctx_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("id", "f" + ft_r59.lkCodeValue)("value", ft_r59.lkCodeValue)("checked", ctx_r58.configDisabled && ctx_r58.insForm.get("selectedFuelType").value == ft_r59.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵattribute"]("disabled", ctx_r58.configDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("for", "f" + ft_r59.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ft_r59.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_div_229_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 89)(1, "div", 17)(2, "div", 18)(3, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4, "Fuel Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](5, VehicleInspectionComponent_div_229_div_5_Template, 5, 6, "div", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r21.insForm.get("fuelTypes").value);
  }
}
function VehicleInspectionComponent_div_235_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 163)(1, "div", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](2, "input", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](3, "label", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const dm_r61 = ctx.$implicit;
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("id", "d" + dm_r61.lkCodeValue)("value", dm_r61.lkCodeValue)("checked", ctx_r22.configDisabled && ctx_r22.insForm.get("selectedDriveMode").value == dm_r61.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵattribute"]("disabled", ctx_r22.configDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("for", "d" + dm_r61.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", dm_r61.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_div_241_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 168)(1, "div", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](2, "input", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](3, "label", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const pb_r62 = ctx.$implicit;
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("id", "p" + pb_r62.lkCodeValue)("value", pb_r62.lkCodeValue)("checked", ctx_r23.configDisabled && ctx_r23.insForm.get("selectedParkingBrake").value == pb_r62.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵattribute"]("disabled", ctx_r23.configDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("for", "p" + pb_r62.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", pb_r62.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_span_252_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_254_Template(rf, ctx) {
  if (rf & 1) {
    const _r64 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 17)(1, "div", 55)(2, "button", 170);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_div_254_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r64);
      const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r63.cancelConfig());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](4, "button", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_div_254_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r64);
      const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r65.saveConfiguration());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](5, "Confirm");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("disabled", !ctx_r25.insForm.valid || ctx_r25.savedConfig);
  }
}
function VehicleInspectionComponent_div_255_Template(rf, ctx) {
  if (rf & 1) {
    const _r67 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 17)(1, "div", 55)(2, "button", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_div_255_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r67);
      const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r66.nextConfig());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " Next ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
}
const _c1 = function (a0) {
  return {
    "color": a0
  };
};
function VehicleInspectionComponent_b_265_Template(rf, ctx) {
  if (rf & 1) {
    const _r69 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "b", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_b_265_Template_b_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r69);
      const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r68.showBrakeReads());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Brake ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpureFunction1"](1, _c1, ctx_r27.deviceResultsDto.isBrakePassed ? "green" : "red"));
  }
}
function VehicleInspectionComponent_b_267_Template(rf, ctx) {
  if (rf & 1) {
    const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "b", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_b_267_Template_b_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r71);
      const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r70.showExhaustReads());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Exhaust Emiss ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpureFunction1"](1, _c1, ctx_r28.deviceResultsDto.isExhaustEmissPassed ? "green" : "red"));
  }
}
function VehicleInspectionComponent_ng_container_269_Template(rf, ctx) {
  if (rf & 1) {
    const _r73 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](1, "b", 172);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_ng_container_269_Template_b_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r73);
      const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r72.showPreviousDefects());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2, "Previous Device Defects");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementContainerEnd"]();
  }
}
function VehicleInspectionComponent_th_277_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "th", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Defect Location");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_tr_287_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r74.defectMainCategory);
  }
}
function VehicleInspectionComponent_tr_287_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r74.defCommentCode + " | " + d_r74.defectMainCategory + " | " + d_r74.defectSubCategory + " | " + d_r74.defect);
  }
}
function VehicleInspectionComponent_tr_287_td_5_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r74.defectLocation);
  }
}
function VehicleInspectionComponent_tr_287_td_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, VehicleInspectionComponent_tr_287_td_5_span_1_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r78.editDefect);
  }
}
function VehicleInspectionComponent_tr_287_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r74.remarks);
  }
}
function VehicleInspectionComponent_tr_287_span_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r74.evalution);
  }
}
function VehicleInspectionComponent_tr_287_span_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r74.defectClassification);
  }
}
function VehicleInspectionComponent_tr_287_ng_container_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](1, "a", 174);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_tr_287_ng_container_13_Template_a_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r92);
      const i_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]().index;
      const ctx_r90 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r90.checkDeleteDef(i_r75));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](2, "i", 175);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementContainerEnd"]();
  }
}
function VehicleInspectionComponent_tr_287_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "tr")(1, "td", 173);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](2, VehicleInspectionComponent_tr_287_span_2_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](4, VehicleInspectionComponent_tr_287_span_4_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](5, VehicleInspectionComponent_tr_287_td_5_Template, 2, 1, "td", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](7, VehicleInspectionComponent_tr_287_span_7_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](8, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](9, VehicleInspectionComponent_tr_287_span_9_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](10, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](11, VehicleInspectionComponent_tr_287_span_11_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](12, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](13, VehicleInspectionComponent_tr_287_ng_container_13_Template, 3, 0, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const d_r74 = ctx.$implicit;
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r31.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r31.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r31.isLocationEmpty);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r31.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r31.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r31.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", d_r74.defectSource == 1);
  }
}
function VehicleInspectionComponent_div_288_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span", 179);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Technical Evaluation: Passed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_288_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span", 179);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Legal Evaluation: Passed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_288_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span", 180);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Technical Evaluation: Failed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_288_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span", 180);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Legal Evaluation: Failed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_288_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 176);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, VehicleInspectionComponent_div_288_span_1_Template, 2, 0, "span", 177);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](2, VehicleInspectionComponent_div_288_span_2_Template, 2, 0, "span", 177);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](3, VehicleInspectionComponent_div_288_span_3_Template, 2, 0, "span", 178);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](4, VehicleInspectionComponent_div_288_span_4_Template, 2, 0, "span", 178);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r32.classificationsResult.isTechnichalPassed || ctx_r32.classificationsResult.isTechnichalPassed == null);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r32.classificationsResult.isLegalPassed || ctx_r32.classificationsResult.isLegalPassed == null);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r32.classificationsResult.isTechnichalPassed != null && !ctx_r32.classificationsResult.isTechnichalPassed);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r32.classificationsResult.isLegalPassed != null && !ctx_r32.classificationsResult.isLegalPassed);
  }
}
function VehicleInspectionComponent_button_295_Template(rf, ctx) {
  if (rf & 1) {
    const _r98 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_295_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r98);
      const ctx_r97 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      ctx_r97.isDefectConfirm = true;
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r97.actionType = 2);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " & Update");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
}
function VehicleInspectionComponent_div_308_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Are you you want to submit this VIN Service ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_309_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Are you sure you want to cancel ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_310_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Is the car inspection defects ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " list accurate and complete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_311_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " You have unsaved changes ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " are you sure you want to cancel? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_312_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" Are you sure you want to delete this ", ctx_r38.confirmEval, " defect ? ");
  }
}
function VehicleInspectionComponent_button_317_Template(rf, ctx) {
  if (rf & 1) {
    const _r100 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_317_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r100);
      const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r99.confirmAction());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](1, "img", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_button_318_Template(rf, ctx) {
  if (rf & 1) {
    const _r102 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_318_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r102);
      const ctx_r101 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r101.deleteDefectItemList(ctx_r101.defectDelIndex));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](1, "img", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_button_319_Template(rf, ctx) {
  if (rf & 1) {
    const _r104 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_319_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r104);
      const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r103.cancelDefectList());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](1, "img", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_button_320_Template(rf, ctx) {
  if (rf & 1) {
    const _r106 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_320_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r106);
      const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r105.submitVinRequest());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](1, "img", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_tr_354_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "tr")(1, "td", 173)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](4, "td")(5, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](7, "td")(8, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](10, "td")(11, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](13, "td")(14, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const d_r107 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r107.defectMainCategory);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r107.defCommentCode + " | " + d_r107.defectMainCategory + " | " + d_r107.defectSubCategory + " | " + d_r107.defect);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r107.remarks);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r107.evalution);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](d_r107.defectClassification);
  }
}
function VehicleInspectionComponent_tr_380_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](12, " >= ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](17, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](18, " >= ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](19, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reads_r109 = ctx.$implicit;
    let tmp_0_0;
    let tmp_1_0;
    let tmp_2_0;
    let tmp_3_0;
    let tmp_5_0;
    let tmp_6_0;
    let tmp_7_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", (tmp_0_0 = reads_r109.descriptionEn) !== null && tmp_0_0 !== undefined ? tmp_0_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", (tmp_1_0 = reads_r109.leftValue) !== null && tmp_1_0 !== undefined ? tmp_1_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", (tmp_2_0 = reads_r109.rightValue) !== null && tmp_2_0 !== undefined ? tmp_2_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", (tmp_3_0 = reads_r109.weight) !== null && tmp_3_0 !== undefined ? tmp_3_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", reads_r109.actualDifferences, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", (tmp_5_0 = reads_r109.maxDifference) !== null && tmp_5_0 !== undefined ? tmp_5_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", (tmp_6_0 = reads_r109.actualDeceleration) !== null && tmp_6_0 !== undefined ? tmp_6_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", (tmp_7_0 = reads_r109.minDeceleration) !== null && tmp_7_0 !== undefined ? tmp_7_0 : "", " ");
  }
}
function VehicleInspectionComponent_tr_394_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reads_r110 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", reads_r110.descriptionEn, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", reads_r110.readingValue, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", reads_r110.operation, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", reads_r110.limitValue, " ");
  }
}
const _c2 = function () {
  return {
    width: "50vw"
  };
};
const _c3 = function () {
  return {
    width: "80vw"
  };
};
class VehicleInspectionComponent {
  constructor(sharedService, inspectionService, fb, location, lookupServ, vehicleService, router, elementRef, sharedLookup, sideNav, visualDefectService, globalServ, authService, zone,
  //private confirmationService: ConfirmationService,
  thousandServ) {
    this.sharedService = sharedService;
    this.inspectionService = inspectionService;
    this.fb = fb;
    this.location = location;
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.router = router;
    this.elementRef = elementRef;
    this.sharedLookup = sharedLookup;
    this.sideNav = sideNav;
    this.visualDefectService = visualDefectService;
    this.globalServ = globalServ;
    this.authService = authService;
    this.zone = zone;
    this.thousandServ = thousandServ;
    this.changeCategory = new _angular_core__WEBPACK_IMPORTED_MODULE_22__.EventEmitter();
    this.brakeReads = [];
    this.exhaustEmissReads = [];
    this.deviceEnableFlag = false;
    this.inpectionDeviceStatus = 0;
    this.isDeviceStatusShown = false;
    this.deviceStatusDescription = '';
    this.isTimerVisiable = false;
    this.isConfigActive = false;
    this.defectList = null;
    this.editDefect = false;
    this.visualDefectActive = false;
    this.savedConfig = false;
    this.isExternal = false;
    this.isVinService = false;
    this.isReStamp = false;
    this.isNewStamp = false;
    this.isTankerService = false;
    this.isTank = false;
    this.saveSubDefectComments = [];
    this.formDataArray = [];
    this.techEv = false;
    this.legalEv = true;
    this.enableVinSubmit = true;
    this.isDeviceSkipConfirmed = false;
    this.previousDeviceDefects = [];
    // timer :
    this.mm = 0;
    this.ss = 0;
    this.ms = 0;
    this.isRunning = false;
    this.timerId = 0;
    this.insForm = fb.group({
      inspectiondetails: fb.group({
        inspectionReqId: [''],
        requestId: [''],
        inspectionServiceType: [],
        fahesReceiptNo: [''],
        isSectionSeqRequired: [],
        inspectionServiceId: [],
        plateNo: [''],
        plateType: [''],
        vinNo: [''],
        contactType: [''],
        serviceId: [''],
        serviceName: [''],
        serviceType: [''],
        colorId: [''],
        subColorId: [''],
        categoryId: [''],
        vehicleModelId: [''],
        modelEname: [''],
        manufacturerId: [''],
        manufacturersEname: [''],
        manufacturerYear: [''],
        cylinders: [''],
        weight: [''],
        payloadWeight: [''],
        shapeCode: [''],
        noOfSeat: [''],
        tankCode: [''],
        licenseExpiryDate: [''],
        ownerType: [''],
        contactPersonPID: [''],
        contactPersonEmail: [''],
        contactPersonPhone: [''],
        ownerId: [''],
        ownerPID: [''],
        ownerName: [''],
        isFinalStep: [''],
        isVehicleConfigRequired: [''],
        isDeviceStarted: [''],
        inspectionStepId: [''],
        vehicleType: [''],
        stationId: [''],
        stationNameAr: [''],
        stationNameEn: [''],
        plateTypeName: [''],
        finalResult: [null],
        finalResultValue: [null],
        vehicleConfiguration: [''],
        selectedDefects: ['']
      }),
      fuelTypes: [[]],
      driveModes: [[]],
      parkingBrakes: [[]],
      selectedFuelType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      isDeviceSkiped: [false],
      selectedDriveMode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      selectedParkingBrake: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      nbAxles: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      milage: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      colorList: [[]],
      ownerTypes: [[]],
      vehicleCategories: [[]],
      plateTypes: [[]],
      colorValue: [''],
      subclr: [' '],
      pidValue: [],
      vcategory: [],
      plateTypeName: [''],
      formatExpDate: [],
      qatarVinNo: [''],
      fahesSerialNo: [''],
      isVinCh: [null],
      isPlateCh: [null],
      isManfCh: [null],
      deviceStartFlag: [false]
    });
    this.deviceInspectionProcessDto = new src_app_core_models_device_results_dto__WEBPACK_IMPORTED_MODULE_2__.DeviceInspectionProcessDto();
    this.deviceResultsDto = new src_app_core_models_device_results_dto__WEBPACK_IMPORTED_MODULE_2__.DeviceResultsDto();
    this.deviceStartRequestDto = new src_app_core_models_save_sub_defects_new_device__WEBPACK_IMPORTED_MODULE_4__.SaveSubDefectCommentsNewDevice();
  }
  showExhaustReads() {
    this.getDeviceInspectionReads(false, true);
  }
  showBrakeReads() {
    this.getDeviceInspectionReads(true, false);
  }
  showPreviousDefects() {
    this.previousInspectionDefectsVisiblityPopup = true;
  }
  getPreviousDeviceDefects() {
    let vehicleEstemaraDetails = {
      plateNo: this.insForm.get('inspectiondetails').value.plateNo,
      plateType: this.insForm.get('inspectiondetails').value.plateType,
      vinNo: this.insForm.get('inspectiondetails').value.vinNo
    };
    this.inspectionService.getPreviousDeviceDefects(vehicleEstemaraDetails).subscribe(res => {
      if (res.items) {
        this.previousDeviceDefects = res.items;
      }
    });
  }
  backToVisualDefectsPage() {
    console.log(this.barCodeTxt);
    this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.searchLicense, this.barCodeTxt, this.selectServiceType, this.sectionId).subscribe(response => {
      if (response.items != null) {
        console.log(response.items);
        this.insForm.get('inspectiondetails').setValue(response.items);
        if (this.insForm.get('inspectiondetails').value != undefined && this.insForm.get('inspectiondetails').value.inspectionStepId != null) {
          this.insForm.get('isVinCh').setValue(true);
          this.insForm.get('isPlateCh').setValue(true);
          this.insForm.get('isManfCh').setValue(true);
        }
        this.requestId = this.insForm.get('inspectiondetails').value.requestId;
        this.sharedService.setSelectedDefectsPrevList(this.insForm.get('inspectiondetails').value.selectedDefects);
        this.sharedService.setConfirmDef(false);
      }
    });
    this.setActiveTab('visual-defect');
    this.sharedService.setBackMainDefects();
    this.visualDefectActive = true;
    this.isConfirmedDefects = false;
  }
  getDeviceInspectionReads(isBrake, isExhaust) {
    let deviceSectionInspectionDto = {
      requestId: this.requestId,
      sectionId: this.sectionId
    };
    this.inspectionService.getDeviceInspectionReads(deviceSectionInspectionDto).subscribe(res => {
      this.brakeReads = res.items.brakeReads;
      this.exhaustEmissReads = res.items.exhaustEmissReads;
      if (isBrake) this.brakeVisiblility = true;
      if (isExhaust) this.exhaustVisiblility = true;
    });
  }
  ngOnInit() {
    console.log('test');
    /* this.sharedService.userId$.subscribe((userId) => {
       this.userId = userId;
     });
     */
    this.userId = parseInt(localStorage.getItem('userId'));
    this.sideNav.setHeaderValue(true, false);
    this.sideNav.setActiveEnt(3, 36);
    this.setActiveTab('details');
    // get the data used in inspection from shared services
    this.sharedService.vinNo$.subscribe(vinNo => {
      this.vinNo = vinNo;
    });
    this.sharedService.plateNo$.subscribe(plateNo => {
      this.plateNo = plateNo;
    });
    this.sharedService.plateType$.subscribe(plateType => {
      this.plateType = plateType;
    });
    this.sharedService.reqNo$.subscribe(reqNo => {
      this.reqNo = reqNo;
    });
    this.sharedService.recNo$.subscribe(recNo => {
      this.recNo = recNo;
    });
    this.sharedService.externalPlateType$.subscribe(externalPlateType => {
      this.externalPlateType = externalPlateType;
    });
    this.sharedService.externalPlateNo$.subscribe(externalPlateNo => {
      this.externalPlateNo = externalPlateNo;
    });
    this.sharedService.insSelectedService$.subscribe(insServiceId => {
      this.selectServiceType = insServiceId;
    });
    this.sharedService.isExternalIns$.subscribe(isExternal => {
      this.isExternal = isExternal;
    });
    this.sharedLookup.colorList$.subscribe(data => {
      this.insForm.get('colorList').setValue(data);
    });
    this.sharedLookup.ownerTypes$.subscribe(data => {
      this.insForm.get('ownerTypes').setValue(data);
    });
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.insForm.get('vehicleCategories').setValue(data);
    });
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.insForm.get('plateTypes').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.fuelType).subscribe(data => {
      this.insForm.get('fuelTypes').setValue(data.items);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.driveMode).subscribe(data => {
      this.insForm.get('driveModes').setValue(data.items);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.parkingBrake).subscribe(data => {
      this.insForm.get('parkingBrakes').setValue(data.items);
    });
    //  this.sharedService.insSectionId$.subscribe((sectionId) => {
    //   this.sectionId = sectionId;
    // });
    this.getTankerCetificateFactorValue();
    this.sectionId = parseInt(localStorage.getItem('sectionId'));
    if (this.sectionId == 2) {
      this.visualDefectActive = true;
    }
    // this.sharedService.laneId$.subscribe((laneId) => {
    //  this.laneId = laneId;
    // });
    this.laneId = parseInt(localStorage.getItem('laneId'));
    this.sharedService.barCodeIns$.subscribe(text => {
      if (text) {
        const plateType = text.substring(0, 2);
        const plateNo = text.substring(2);
        this.plateNo = plateNo;
        this.plateType = plateType;
        this.barCodeTxt = text;
      }
    });
    // init tanker form
    this.createTankereRequestForm();
    if (!(this.vinNo || this.plateNo || this.externalPlateNo || this.externalPlateType || this.recNo)) {
      this.router.navigate(['/inspection/landing-inspection']);
    }
    if (this.plateNo) {
      this.isExternal = false;
      let licenseCode;
      // if (this.plateType.length === 1) {
      //   // Add '0' before plateNo if plateType is 1 digit
      //   licenseCode = '0' + this.plateType + this.plateNo;
      // } else {
      //   // Concatenate plateType and plateNo as usual if plateType is not 1 digit
      //   licenseCode = this.plateType + this.plateNo;
      // }
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.searchLicense, this.barCodeTxt, this.selectServiceType, this.sectionId).subscribe(response => {
        if (response.items != null) {
          console.log(response.items);
          this.insForm.get('inspectiondetails').setValue(response.items);
          if (this.insForm.get('inspectiondetails').value != undefined && this.insForm.get('inspectiondetails').value.inspectionStepId != null) {
            this.insForm.get('isVinCh').setValue(true);
            this.insForm.get('isPlateCh').setValue(true);
            this.insForm.get('isManfCh').setValue(true);
          }
          this.requestId = this.insForm.get('inspectiondetails').value.requestId;
          this.setVehicleDetailValues();
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
          });
          this.getPreviousDeviceDefects();
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    if (this.vinNo) {
      this.isExternal = false;
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.searchVin, this.vinNo.toString(), this.selectServiceType, this.sectionId).subscribe(response => {
        if (response.items != null) {
          this.insForm.get('inspectiondetails').setValue(response.items);
          if (this.insForm.get('inspectiondetails').value != undefined && this.insForm.get('inspectiondetails').value.inspectionStepId != null) {
            this.insForm.get('isVinCh').setValue(true);
            this.insForm.get('isPlateCh').setValue(true);
            this.insForm.get('isManfCh').setValue(true);
          }
          this.setVehicleDetailValues();
          let plateType = this.insForm.get('inspectiondetails').value.plateType.toString().padStart(2, '0');
          let plateNo = this.insForm.get('inspectiondetails').value.plateNo;
          this.barCodeTxt = plateType + plateNo;
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
          });
          this.getPreviousDeviceDefects();
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    if (this.recNo) {
      this.isExternal = false;
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.serachReceiptNo, this.recNo.toString(), null, this.sectionId).subscribe(response => {
        if (response.items != null) {
          this.insForm.get('inspectiondetails').setValue(response.items);
          if (this.insForm.get('inspectiondetails').value != undefined && this.insForm.get('inspectiondetails').value.inspectionStepId != null) {
            this.insForm.get('isVinCh').setValue(true);
            this.insForm.get('isPlateCh').setValue(true);
            this.insForm.get('isManfCh').setValue(true);
          }
          this.selectServiceType = this.insForm.get('inspectiondetails').value.inspectionServiceType;
          let plateType = this.insForm.get('inspectiondetails').value.plateType.toString().padStart(2, '0');
          let plateNo = this.insForm.get('inspectiondetails').value.plateNo;
          this.barCodeTxt = plateType + plateNo;
          this.requestId = this.insForm.get('inspectiondetails').value.requestId;
          this.setVehicleDetailValues();
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
            this.getPreviousDeviceDefects();
          });
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        console.log('ERRRRORRRRR', error);
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    if (this.externalPlateType && this.externalPlateNo) {
      let plateTypeAndNo = this.externalPlateType + '' + this.externalPlateNo;
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.searchLicense, plateTypeAndNo, this.selectServiceType, this.sectionId).subscribe(response => {
        if (response.items != null) {
          this.insForm.get('inspectiondetails').setValue(response.items);
          if (this.insForm.get('inspectiondetails').value != undefined && this.insForm.get('inspectiondetails').value.inspectionStepId != null) {
            this.insForm.get('isVinCh').setValue(true);
            this.insForm.get('isPlateCh').setValue(true);
            this.insForm.get('isManfCh').setValue(true);
          }
          this.setVehicleDetailValues();
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
            this.getPreviousDeviceDefects();
          });
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    // this.setActiveTab('config');
    this.sharedService.defectCommentList$.subscribe(def => {
      if (def) {
        def.length > 0 ? this.isDefect = true : false;
      }
    });
    this.tankereRequestForm.get('height').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: this.tankereRequestForm.get('length').value,
        height: value,
        width: this.tankereRequestForm.get('width').value,
        factor: this.tankereRequestForm.get('factor').value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.tankereRequestForm.get('length').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: value,
        height: this.tankereRequestForm.get('height').value,
        width: this.tankereRequestForm.get('width').value,
        factor: this.tankereRequestForm.get('factor').value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.tankereRequestForm.get('width').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: this.tankereRequestForm.get('length').value,
        height: this.tankereRequestForm.get('height').value,
        width: value,
        factor: this.tankereRequestForm.get('factor').value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.tankereRequestForm.get('factor').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: this.tankereRequestForm.get('length').value,
        height: this.tankereRequestForm.get('height').value,
        width: this.tankereRequestForm.get('width').value,
        factor: value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_9__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.sharedService.isConfirmDef$.subscribe(isConfirm => {
      this.isConfirmedDefects = isConfirm;
      console.log(this.isConfirmedDefects);
      if (this.isConfirmedDefects) {
        this.getDefectList();
      }
    });
    //Open websocket call for fecthing the results of the devices
    this.hubConnectionBuilder = new _microsoft_signalr__WEBPACK_IMPORTED_MODULE_24__.HubConnectionBuilder().withUrl(src_environments_environment__WEBPACK_IMPORTED_MODULE_10__.environment.signalR.deviceInspectionStatusHubUrl).configureLogging(_microsoft_signalr__WEBPACK_IMPORTED_MODULE_25__.LogLevel.Information).build();
    this.hubConnectionBuilder.start().then(() => console.log('Connection started.......!')).catch(err => console.log('Error while connect with server'));
    this.hubConnectionBuilder.on('sentDeviceStatus', result => {
      console.log('device status=>', result);
      this.inpectionDeviceStatus = result.status;
      this.deviceStatusDescription = result.currentStatusDescription;
      if (this.inpectionDeviceStatus == src_app_core_utilities_enums_device_inspection_status_enum__WEBPACK_IMPORTED_MODULE_5__.DeviceInspectionStatus.InProgress) {
        this.isDeviceStatusShown = true;
        if (!this.isRunning) {
          this.isTimerVisiable = true;
          this.startStopTimer();
        }
      } else {
        if (this.isRunning) this.startStopTimer();
        this.isDeviceStatusShown = false;
        this.deviceInspectionProcessDto.requestId = this.requestId;
        this.deviceInspectionProcessDto.sectionId = this.sectionId;
        this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
          this.deviceResultsDto = res.items;
          console.log(this.deviceResultsDto);
        });
        this.getPreviousDeviceDefects();
      }
    });
  }
  getTankerCetificateFactorValue() {
    this.globalServ.getTankerCetificateFactorValue().subscribe(res => {
      this.tankereRequestForm.get('factor').setValue(res.items);
    });
  }
  calculateTankVolume() {
    // Volume = Length * Width * Height * 1000 * 0.7854
    const volume = this.tankereRequestForm.get('length').value * this.tankereRequestForm.get('width').value * this.tankereRequestForm.get('height').value * 1000 * 0.7854;
    // volume in litre
    return volume;
  }
  createTankerCertificateRequest() {
    if (this.isTankerService) {
      let tankerRequest = this.tankereRequestForm.value;
      tankerRequest.tankerCertRequestId = this.insForm.get('inspectiondetails').value.inspectionReqId;
      console.log(tankerRequest);
      this.inspectionService.submitTankerCertificateRequest(tankerRequest).subscribe(res => {
        if (res.errorMessage == null) this.logout();
      });
    }
    if (this.isTank) {
      const tankDetails = {
        requestId: this.insForm.get('inspectiondetails').value.inspectionReqId,
        length: parseFloat(this.tankereRequestForm.get('length').value),
        width: parseFloat(this.tankereRequestForm.get('width').value),
        height: parseFloat(this.tankereRequestForm.get('height').value),
        volume: parseInt(this.tankereRequestForm.get('volume').value)
      };
      this.inspectionService.fillInspectionTankValues(tankDetails).subscribe(res => {
        this.setActiveTab('visual-defect');
      });
    }
  }
  assignVehicleConfig(vconfig) {
    this.configDisabled = true;
    for (const config of vconfig) {
      switch (config.codeOperation) {
        case 25:
          this.insForm.get('selectedFuelType').setValue(config.codeValues);
          break;
        case 26:
          this.insForm.get('selectedDriveMode').setValue(config.codeValues);
          break;
        case 27:
          this.insForm.get('selectedParkingBrake').setValue(config.codeValues);
          break;
        case 28:
          this.insForm.get('milage').setValue(config.codeValues);
          break;
        case 29:
          this.insForm.get('nbAxles').setValue(config.codeValues);
          break;
        case 30:
          this.insForm.get('isDeviceSkiped').setValue(config.codeValues == "1" ? true : false);
          break;
        default:
          // Handle default case if necessary
          break;
      }
    }
    this.sharedService.setNbAxles(this.insForm.get('nbAxles').value);
  }
  removeConfigValidation() {
    this.insForm.get('selectedFuelType').clearValidators();
    this.insForm.get('selectedFuelType').updateValueAndValidity();
    this.insForm.get('selectedDriveMode').clearValidators();
    this.insForm.get('selectedDriveMode').updateValueAndValidity();
    this.insForm.get('selectedParkingBrake').clearValidators();
    this.insForm.get('selectedParkingBrake').updateValueAndValidity();
    this.insForm.get('nbAxles').clearValidators();
    this.insForm.get('nbAxles').updateValueAndValidity();
  }
  setVehicleDetailValues() {
    console.log(this.insForm.get('inspectiondetails').value);
    console.log(this.insForm.get('inspectiondetails').value.plateNo);
    this.sharedService.setSelectedDefectsPrevList(this.insForm.get('inspectiondetails').value.selectedDefects);
    if (this.insForm.get('inspectiondetails').value.vehicleConfiguration != null) {
      const vconfig = this.insForm.get('inspectiondetails').value.vehicleConfiguration;
      this.assignVehicleConfig(vconfig);
      //   this.setActiveTab("visual-defect");
      this.visualDefectActive = true;
      this.insForm.get('isVinCh').setValue(true);
      this.insForm.get('isPlateCh').setValue(true);
      this.insForm.get('isManfCh').setValue(true);
    }
    if (this.selectServiceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.VINStamping) {
      //   this.setActiveTab("vin");
      this.isVinService = true;
      if (this.insForm.get('inspectiondetails').value.serviceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.NewStamping) {
        this.isNewStamp = true;
        this.checkVinSeq();
        this.inspectionService.getQatarVinNumbersDetails(this.insForm.get('inspectiondetails').value.categoryId, this.insForm.get('inspectiondetails').value.requestId).subscribe(response => {
          this.insForm.get('qatarVinNo').setValue(response.items.qatarVinNo);
          this.insForm.get('fahesSerialNo').setValue(response.items.fahesSerialNo);
        });
      }
      if (this.insForm.get('inspectiondetails').value.serviceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.ReStamping) {
        this.isReStamp = true;
      }
    }
    if (this.selectServiceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.TankerCertificate) {
      //   this.setActiveTab("tanker");
      this.isTankerService = true;
      this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.tankerShapes).subscribe(data => {
        this.tankerShapes = data.items;
      });
    }
    if (this.isExternal) {
      this.removeConfigValidation();
    }
    console.log(this.insForm.get('inspectiondetails').value);
    this.getDefectList();
    if (this.defectList) {
      this.setActiveTab('visual-defect');
    }
    this.sharedService.setVinNo(this.insForm.get('inspectiondetails').value.vinNo);
    if (this.insForm.get('inspectiondetails').value.categoryId == 6 && this.selectServiceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Inspection) {
      this.isTank = true;
      this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.tankerShapes).subscribe(data => {
        this.tankerShapes = data.items;
      });
    }
    if (this.insForm.get('inspectiondetails').value.categoryId == 10) {
      this.insForm.get('selectedFuelType').clearValidators();
      this.insForm.get('selectedFuelType').updateValueAndValidity();
    }
    const color = this.insForm.get('colorList').value.find(color => color.lkCodeValue == this.insForm.get('inspectiondetails').value.colorId);
    this.insForm.get('colorValue').setValue(color.lkValueEname);
    this.insForm.get('pidValue').setValue(this.insForm.get('ownerTypes').value.find(pid => pid.lkCodeValue == this.insForm.get('inspectiondetails').value.ownerType).lkValueEname);
    this.insForm.get('vcategory').setValue(this.insForm.get('vehicleCategories').value.find(category => category.categoryId == this.insForm.get('inspectiondetails').value.categoryId).descriptionEn);
    this.insForm.get('plateTypeName').setValue(this.insForm.get('plateTypes').value.find(plate => plate.lkCodeValue == this.insForm.get('inspectiondetails').value.plateType).lkValueEname);
    const isoDate = new Date(this.insForm.get('inspectiondetails').value.licenseExpiryDate);
    const dateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_26__.DatePipe('en-US').transform(isoDate, 'MM-dd-yyyy');
    this.insForm.get('formatExpDate').setValue(dateFormat);
    // save the category type id
    const insCategId = this.insForm.get('inspectiondetails').value.categoryId;
    for (let ins of this.insForm.get('vehicleCategories').value) {
      if (ins.categoryId == insCategId) {
        this.sharedService.setVehcileCategory(ins.categoryTypeId);
      }
    }
    const reqId = this.insForm.get('inspectiondetails').value.requestId;
    this.inspectionService.getInspectionInstructionsByRequestId(this.insForm.get('inspectiondetails').value.serviceId, 1).subscribe(response => {
      console.log(response.items);
      this.instructions = response.items;
      //this.sharedService.setInsSection(this.instructions[0].sectionId);
      this.sharedService.setInsServId(parseInt(this.insForm.get('inspectiondetails').value.inspectionServiceId));
      this.sharedService.setVehicleType(parseInt(this.insForm.get('inspectiondetails').value.vehicleType));
      this.sharedService.setReqNo(this.insForm.get('inspectiondetails').value.requestId);
      if (this.isExternal) {
        this.sharedService.setInsRequest(this.insForm.get('inspectiondetails').value.inspectionReqId);
        const insStep = {
          inspectionReqId: this.insForm.get('inspectiondetails').value.inspectionReqId,
          requestId: reqId,
          inspectionServiceId: this.insForm.get('inspectiondetails').value.inspectionServiceId,
          laneId: this.laneId,
          sectionId: this.sectionId,
          inspectorId: this.userId,
          remarks: ''
        };
        if (!this.insForm.get('inspectiondetails').value.inspectionStepId) {
          this.inspectionService.createInspectionStep(insStep).subscribe(response => {
            this.sharedService.setInsStepId(response.items);
            console.log('test ins step', response.items);
          });
        } else {
          this.sharedService.setInsStepId(this.insForm.get('inspectiondetails').value.inspectionStepId);
        }
      }
      if (this.insForm.get('inspectiondetails').value.vehicleConfiguration != null) {
        const configurationRequest = {
          requestId: reqId,
          inspectorId: this.userId,
          sectionId: this.sectionId,
          laneId: this.laneId,
          remarks: 'remarks',
          deviceInputCodes: this.insForm.get('inspectiondetails').value.vehicleConfiguration,
          isDeviceFlagEnabled: this.insForm.get('inspectiondetails').value.isDeviceStarted == true ? true : false
        };
        this.inspectionRequest = new src_app_core_models_inspection_request__WEBPACK_IMPORTED_MODULE_3__.InspectionRequest(configurationRequest);
        console.log(this.inspectionRequest);
        if (this.insForm.get('inspectiondetails').value.isDeviceStarted == true) {
          this.insForm.get('deviceStartFlag').disable();
          this.insForm.get('deviceStartFlag').setValue(true);
        }
        this.inspectionService.createInspectionRequest(this.inspectionRequest).subscribe(response => {
          this.insForm.get('inspectiondetails.inspectionReqId').setValue(response.items.inspectionRequestId);
          this.sharedService.setInsStepId(response.items.inspectionStepId);
          this.sharedService.setInsRequest(parseInt(response.items.inspectionRequestId));
          this.insForm.get('isDeviceStarted').setValue(true);
          this.insForm.get('deviceStartFlag').disable();
          this.sharedService.setDeviceSkip(this.deviceEnableFlag);
          this.deviceStartRequestDto = {
            axle: 0,
            defectClassification: 2,
            defectMode: 3,
            evalutionId: 3,
            defectsCommentId: 0,
            defectSource: 2,
            inspectionReqId: response.items.inspectionRequestId,
            inspectionServiceId: this.insForm.get('inspectiondetails').value.inspectionServiceId,
            inspectionStepId: response.items.inspectionStepId,
            isDeviceSkipped: !this.deviceEnableFlag,
            locations: [''],
            remarks: '',
            requestId: this.insForm.get('inspectiondetails.requestId').value,
            sectionId: this.sectionId,
            status: 1,
            createdBy: this.userId
          };
          this.sharedService.setDeviceStartResultDetails(this.deviceStartRequestDto);
          this.savedConfig = true;
          //Open websocket call for fecthing the results of the devices
          this.hubConnectionBuilder = new _microsoft_signalr__WEBPACK_IMPORTED_MODULE_24__.HubConnectionBuilder().withUrl(src_environments_environment__WEBPACK_IMPORTED_MODULE_10__.environment.signalR.deviceInspectionStatusHubUrl).configureLogging(_microsoft_signalr__WEBPACK_IMPORTED_MODULE_25__.LogLevel.Information).build();
          this.hubConnectionBuilder.start().then(() => console.log('Connection started.......!')).catch(err => console.log('Error while connect with server'));
          this.hubConnectionBuilder.on('sentDeviceStatus', result => {
            this.inpectionDeviceStatus = result.status;
            this.deviceStatusDescription = result.currentStatusDescription;
            if (this.inpectionDeviceStatus == src_app_core_utilities_enums_device_inspection_status_enum__WEBPACK_IMPORTED_MODULE_5__.DeviceInspectionStatus.InProgress) {
              this.isDeviceStatusShown = true;
              if (!this.isRunning) {
                this.startStopTimer();
                this.isTimerVisiable = true;
              }
            } else {
              if (this.isRunning) this.startStopTimer();
              this.isDeviceStatusShown = false;
            }
          });
        });
      }
    });
    this.vehicleCategory = this.insForm.get('vcategory').value;
    let subColor = this.insForm.get('colorList').value.find(color => color.lkCodeValue == this.insForm.get('inspectiondetails').value.subColorId) != undefined ? this.insForm.get('colorList').value.find(color => color.lkCodeValue == this.insForm.get('inspectiondetails').value.subColorId).lkValueEname : null;
    this.insForm.get('subclr').setValue(subColor);
  }
  createTankereRequestForm() {
    this.tankereRequestForm = this.fb.group({
      shapeId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      length: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      width: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      height: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      factor: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      volume: [null],
      volumeUK: [null],
      volumeUS: [null],
      remarks: [null]
    });
  }
  submitVinRequest() {
    if (this.isReStamp) {
      const vinRequest = {
        vinStampingRequestId: this.insForm.get('inspectiondetails').value.inspectionReqId,
        qatarVinNo: this.insForm.get('inspectiondetails').value.vinNo,
        vinType: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.ReStamping,
        vehicleCategoryId: this.insForm.get('inspectiondetails').value.categoryId
      };
      this.inspectionService.submitVinStampingRequest(vinRequest).subscribe(res => {
        if (res.errorMessage == null) this.logout();
      });
    }
    if (this.isNewStamp) {
      const vinRequest = {
        vinStampingRequestId: this.insForm.get('inspectiondetails').value.inspectionReqId,
        qatarVinNo: this.insForm.get('qatarVinNo').value,
        vinType: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.NewStamping,
        vehicleCategoryId: this.insForm.get('inspectiondetails').value.categoryId
      };
      this.inspectionService.submitVinStampingRequest(vinRequest).subscribe(res => {
        if (res.errorMessage == null) this.logout();
      });
    }
  }
  setActiveTab(tab) {
    this.activeTab = tab;
    console.log(this.activeTab);
  }
  confirmIns() {
    // if (this.isExternal || this.sectionId == 2) {
    //   this.setActiveTab("visual-defect");
    // }
    // else {
    //   this.setActiveTab("config");
    // }
    this.setActiveTab('config');
  }
  cancelConfig() {
    this.isCancelConfig = true;
  }
  nextVI() {
    if (!this.isVinService || !this.isTankerService || !this.isExternal) {
      this.setActiveTab('config');
    }
    if (this.isVinService) {
      this.setActiveTab('vin');
    }
    if (this.isTankerService) {
      this.setActiveTab('tanker');
    }
    if (this.isExternal) {
      this.setActiveTab("visual-defect");
    }
  }
  checkVinSeq() {
    this.inspectionService.getVINSequences({
      categoryId: this.insForm.get('inspectiondetails').value.categoryId
    }).subscribe(response => {
      if (response.items[0].availableSeqCount <= 0) {
        this.enableVinSubmit = false;
        console.log(this.enableVinSubmit);
        console.log(!this.enableVinSubmit);
      } else {
        this.enableVinSubmit = true;
      }
    });
  }
  saveConfiguration() {
    console.log(this.insForm.get('selectedFuelType').value);
    console.log(this.insForm.get('selectedDriveMode').value);
    console.log(this.insForm.get('selectedParkingBrake').value);
    console.log(this.insForm.get('nbAxles').value);
    console.log(this.insForm.get('milage').value);
    this.deviceCodeList = [new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(25, this.insForm.get('selectedFuelType').value?.toString() ? this.insForm.get('selectedFuelType').value.toString() : null), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(26, this.insForm.get('selectedDriveMode').value?.toString() ? this.insForm.get('selectedDriveMode').value.toString() : null), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(27, this.insForm.get('selectedParkingBrake').value?.toString() ? this.insForm.get('selectedParkingBrake').value.toString() : null), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(28, this.insForm.get('milage').value.replace(/,/g, '')), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(29, this.insForm.get('nbAxles').value?.toString() ? this.insForm.get('nbAxles').value.toString() : null)
    // new DeviceInputCode(
    //   30,
    //   this.insForm.get('isDeviceSkiped').value ? "1" : "2"
    // )
    ];

    this.sharedService.setNbAxles(this.insForm.get('nbAxles').value);
    const reqId = this.insForm.get('inspectiondetails.requestId').value;
    const configurationRequest = {
      requestId: reqId,
      inspectorId: this.userId,
      sectionId: this.sectionId,
      laneId: this.laneId,
      remarks: 'remarks',
      deviceInputCodes: this.deviceCodeList,
      isDeviceFlagEnabled: this.deviceEnableFlag
    };
    if (this.insForm.get('isDeviceSkiped').value) this.isDeviceSkipConfirmed = true;
    this.inspectionRequest = new src_app_core_models_inspection_request__WEBPACK_IMPORTED_MODULE_3__.InspectionRequest(configurationRequest);
    console.log(this.inspectionRequest);
    this.inspectionService.createInspectionRequest(this.inspectionRequest).subscribe(response => {
      this.insForm.get('inspectiondetails.inspectionReqId').setValue(response.items.inspectionRequestId);
      this.sharedService.setInsStepId(response.items.inspectionStepId);
      this.sharedService.setInsRequest(parseInt(response.items.inspectionRequestId));
      this.sharedService.setDeviceSkip(this.deviceEnableFlag);
      this.deviceStartRequestDto = {
        axle: 0,
        defectClassification: 2,
        defectMode: 3,
        evalutionId: 3,
        defectsCommentId: 0,
        defectSource: 2,
        inspectionReqId: response.items.inspectionRequestId,
        inspectionServiceId: this.insForm.get('inspectiondetails').value.inspectionServiceId,
        inspectionStepId: response.items.inspectionStepId,
        isDeviceSkipped: !this.deviceEnableFlag,
        locations: [''],
        remarks: '',
        requestId: this.insForm.get('inspectiondetails.requestId').value,
        sectionId: this.sectionId,
        status: 1,
        createdBy: this.userId
      };
      this.sharedService.setDeviceStartResultDetails(this.deviceStartRequestDto);
      this.savedConfig = true;
      this.configDisabled = true;
    });
    this.nextConfig();
  }
  nextConfig() {
    if (this.isTank) {
      this.setActiveTab('tankdets');
    } else {
      this.setActiveTab('visual-defect');
    }
    this.visualDefectActive = true;
  }
  getDefectList() {
    if (this.isConfirmedDefects) {
      this.setActiveTab('defect-list');
    }
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.evaluationList).subscribe(response => {
      this.evaluationList = response.items;
    });
    console.log(this.insForm.get('inspectiondetails.inspectionReqId').value);
    if (this.insForm.get('inspectiondetails.inspectionReqId').value != undefined || this.insForm.get('inspectiondetails.inspectionReqId').value != '') this.inspectionService.getInspectionDefects(this.insForm.get('inspectiondetails.inspectionReqId').value).subscribe(response => {
      this.defectList = response.items;
      this.defectListSaved = response.items;
      this.isLocationEmpty = this.defectList.every(defect => defect.defectLocation === '');
    });
    if (this.insForm.get('inspectiondetails').value.isFinalStep) {
      let baseInspectionRequestDto = {
        requestId: this.requestId ? this.requestId : this.insForm.get('inspectiondetails').value.requestId
      };
      this.inspectionService.getInspectionResultDetails(baseInspectionRequestDto).subscribe(res => {
        this.classificationsResult = res.items;
      });
    }
  }
  checkDeleteDef(index) {
    this.defectDelIndex = index;
    this.confirmEval = this.defectList[index].evalution;
    console.log(this.confirmEval);
  }
  deleteDefectItemList(index) {
    const deleteDef = {
      inspectionReqId: this.insForm.get('inspectiondetails.inspectionReqId').value,
      defectsCommentId: this.defectList[index].defectCommentId
    };
    this.inspectionService.deleteInspectionDefect(deleteDef).subscribe(response => {
      this.getDefectList();
      this.defectDelIndex = null;
    });
  }
  //Action Type : Save =1 | Save & Update =2
  confirmAction() {
    if (this.isCancelConfig) {
      this.resetConfig();
      this.router.navigate(['/inspection/landing-inspection']);
    }
    if (this.isDefectConfirm) {
      let stepId;
      this.sharedService.insStepId$.subscribe(step => {
        stepId = step;
      });
      this.inspectionService.finishInspectionStep(stepId).subscribe(response => {
        if (this.actionType == src_app_core_utilities_enums_inspection_save_action_types_enum__WEBPACK_IMPORTED_MODULE_6__.InspectionSaveActionTypes.SaveAndUpdate) this.confirmDefectList();else {
          this.logout();
        }
      });
    }
  }
  logout() {
    var _this = this;
    return (0,_Users_os_Desktop_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!_this.isExternal) {
        yield _this.authService.logout();
      } else {
        _this.router.navigate(['/inspection/landing-inspection']);
      }
    })();
  }
  // reset the values chosen for vehicle configuration
  resetConfig() {
    this.insForm.get('selectedFuelType').setValue(null);
    this.insForm.get('selectedDriveMode').setValue(null);
    this.insForm.get('selectedParkingBrake').setValue(null);
    this.insForm.get('nbAxles').setValue(null);
    this.insForm.get('milage').setValue(null);
    this.insForm.get('isDeviceSkiped').setValue(false);
  }
  confirmDefectList() {
    if (this.insForm.get('inspectiondetails').value.isFinalStep) {
      this.inspectionService.submitInspectionRequest(this.insForm.get('inspectiondetails').value.requestId).subscribe(response => {
        this.logout();
        console.log('inspetion request ', response);
      });
    } else {
      if (!this.isExternal) {
        this.logout();
      }
    }
  }
  cancelDefectList() {
    // this.setActiveTab("visual-defect");
    window.location.reload();
  }
  back() {
    this.location.back();
  }
  confirmTankerCertificate() {
    this.createTankerCertificateRequest();
  }
  //#region timer:
  startStopTimer() {
    if (!this.isRunning && this.isDeviceStatusShown) {
      // Stop => Running
      this.timerId = setInterval(() => {
        this.ms++;
        if (this.ms >= 100) {
          this.ss++;
          this.ms = 0;
        }
        if (this.ss >= 60) {
          this.mm++;
          this.ss = 0;
        }
      }, 10);
    } else {
      clearInterval(this.timerId);
    }
    this.isRunning = !this.isRunning;
  }
  format(num) {
    return (num + '').length === 1 ? '0' + num : num + '';
  }
  startInspectionDevice() {
    if (this.insForm.get('inspectiondetails').value.vehicleConfiguration == null && this.insForm.get('deviceStartFlag').value == true || this.insForm.get('inspectiondetails').value.vehicleConfiguration != null && this.insForm.get('deviceStartFlag').value == true) {
      this.deviceEnableFlag = true;
      this.insForm.get('deviceStartFlag').disable();
    } else if (this.insForm.get('inspectiondetails').value.vehicleConfiguration == null && this.insForm.get('deviceStartFlag').value != true || this.insForm.get('inspectiondetails').value.vehicleConfiguration != null && this.insForm.get('deviceStartFlag').value != true) {
      this.deviceEnableFlag = false;
    }
    // if (this.insForm.get('inspectiondetails').value.vehicleConfiguration != null) {
    //   this.deviceCodeList = [
    //     new DeviceInputCode(
    //       25,
    //       this.insForm.get('selectedFuelType').value?.toString()
    //         ? this.insForm.get('selectedFuelType').value.toString()
    //         : null
    //     ),
    //     new DeviceInputCode(
    //       26,
    //       this.insForm.get('selectedDriveMode').value?.toString()
    //         ? this.insForm.get('selectedDriveMode').value.toString()
    //         : null
    //     ),
    //     new DeviceInputCode(
    //       27,
    //       this.insForm.get('selectedParkingBrake').value?.toString()
    //         ? this.insForm.get('selectedParkingBrake').value.toString()
    //         : null
    //     ),
    //     new DeviceInputCode(
    //       28,
    //       this.insForm.get('milage').value.replace(/,/g, '')
    //     ),
    //     new DeviceInputCode(
    //       29,
    //       this.insForm.get('nbAxles').value?.toString()
    //         ? this.insForm.get('nbAxles').value.toString()
    //         : null
    //     ),
    //     // new DeviceInputCode(
    //     //   30,
    //     //   this.insForm.get('isDeviceSkiped').value ? "1" : "2"
    //     // )
    //   ];
    //   const reqId = this.insForm.get('inspectiondetails.requestId').value;
    //   const configurationRequest = {
    //     requestId: reqId,
    //     inspectorId: this.userId,
    //     sectionId: this.sectionId,
    //     laneId: this.laneId,
    //     remarks: '',
    //     deviceInputCodes: this.deviceCodeList,
    //     isDeviceFlagEnabled: this.deviceEnableFlag
    //   };
    //   this.inspectionRequest = new InspectionRequest(configurationRequest);
    //   this.inspectionService.createInspectionRequest(this.inspectionRequest).subscribe((response) => {
    //     if (response.errorMessage == null) {
    //       this.insForm.get('isDeviceStarted').setValue(true);
    //       this.insForm.get('deviceStartFlag').disable();
    //       this.sharedService.setDeviceSkip(this.deviceEnableFlag);
    //     }
    //   });
    // }
  }
  //#endregion
  ngOnDestroy() {
    // setTimeout(() => {
    //   this.zone.run(() => {
    //     location.reload();
    //   });
    // }, 1500);
    this.isExternal = false;
    this.plateNo = null;
    this.plateType = null;
    this.vinNo = null;
    this.reqNo = null;
    this.recNo = null;
    this.isConfirmedDefects = false;
    this.sharedService.reset();
  }
  static #_ = this.ɵfac = function VehicleInspectionComponent_Factory(t) {
    return new (t || VehicleInspectionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_11__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_12__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_26__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_13__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_14__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_27__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_22__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_15__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_16__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_17__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_authentication_service_ts_service__WEBPACK_IMPORTED_MODULE_19__.AuthenticationServiceTsService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_22__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_20__.ThousandSeparatorService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdefineComponent"]({
    type: VehicleInspectionComponent,
    selectors: [["app-vehicle-inspection"]],
    inputs: {
      mainDefects: "mainDefects"
    },
    outputs: {
      vehicleCategory: "vehicleCategory",
      defectListSaved: "defectListSaved",
      changeCategory: "changeCategory"
    },
    decls: 413,
    vars: 117,
    consts: [[3, "formGroup"], [1, "inspection-tab-menu"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "v-details", "aria-selected", "true", 1, "nav-link", 3, "click"], ["class", "nav-item", "role", "presentation", 4, "ngIf"], ["role", "presentation", 1, "nav-item", 3, "hidden"], ["id", "profile-tab", "type", "button", "role", "tab", "aria-controls", "v-config", "aria-selected", "false", 1, "nav-link", "active", 3, "click"], ["id", "contact-tab", "type", "button", "role", "tab", "aria-controls", "contact", "aria-selected", "false", 1, "nav-link", 3, "click"], ["id", "defect-tab", "type", "button", "role", "tab", "aria-controls", "contact", "aria-selected", "false", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "instructions", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "plno", 1, "ml-auto"], [4, "ngIf"], [1, "inspection-tab-content"], ["class", "stop-watch", 4, "ngIf"], ["class", "device-status", 4, "ngIf"], [1, "row"], [1, "col-12"], ["id", "myTabContent", 1, "tab-content"], ["id", "v-details", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], [1, "tab-item-content"], [1, "section", "dashboard"], [1, "col-lg-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], ["class", "col", 4, "ngIf"], [1, "row", "form-fields"], ["formGroupName", "inspectiondetails", 1, "col-md-6", "col-lg-3"], ["for", "myInput"], ["type", "number", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "id", "myInput", "formControlName", "plateNo", "id", "highlightText", "readOnly", "", 1, "form-control"], [1, "col-md-6", "col-lg-3"], ["type", "text", "formControlName", "plateTypeName", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "vcategory", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "pidValue", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "ownerPID", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "ownerName", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "formatExpDate", "readonly", "", 1, "form-control"], ["type", "text", "id", "highlightText", "formControlName", "vinNo", "readOnly", "", 1, "form-control"], ["type", "text", "id", "highlightText", "formControlName", "manufacturersEname", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "modelEname", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "manufacturerYear", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "cylinders", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "weight", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "payloadWeight", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "colorValue", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "subclr", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "noOfSeat", "readOnly", "", 1, "form-control"], ["class", "row", 4, "ngIf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], ["id", "vin", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [1, "card"], ["type", "button", 1, "btn", "btn-dark-gray"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-orange", 3, "disabled"], ["id", "tanker", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [1, "col-md-3"], [1, "st-label"], ["formControlName", "shapeId", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "length", 1, "form-control"], ["type", "text", "formControlName", "width", 1, "form-control"], ["type", "text", "formControlName", "height", 1, "form-control"], ["type", "text", "formControlName", "factor", 1, "form-control"], ["type", "text", "formControlName", "volume", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "volumeUK", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "volumeUS", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "remarks", 1, "form-control"], ["style", "color: orange;margin-top: 10px;", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#tankerConfirmationModal", 1, "btn", "btn-orange", 3, "disabled"], ["id", "instructions", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [4, "ngFor", "ngForOf"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], ["id", "v-config", "role", "tabpanel", "aria-labelledby", "profile-tab", 1, "tab-pane", "fade", "show"], ["_ngcontent-bws-c51", "", 1, "row", "justify-content-between"], [1, "col-md-10"], ["_ngcontent-bws-c51", ""], ["style", "display: contents;", 4, "ngIf"], [1, "row", "justify-content-between"], ["class", "col-lg-5", 4, "ngIf"], [1, "col-lg-5"], ["class", "col-6", 4, "ngFor", "ngForOf"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], [1, "col-lg-6"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "placeholder", "ex: 2", "formControlName", "nbAxles", 1, "form-control", 3, "readonly"], ["type", "text", "placeholder", "ex: 100,0000", "oninput", "this.value = this.value.replace(/[^0-9,]/g, '').replace(/\\D/g, '').replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',').replace(/^0+(?=\\d)/, '')", "formControlName", "milage", 1, "form-control", 3, "readonly"], ["id", "vd-main-cat", "role", "tabpanel", "aria-labelledby", "contact-tab", 1, "tab-pane", "fade", "show"], ["id", "defect-list", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [1, "defect-list-title"], [1, "defect-device-result"], [3, "ngStyle", "click", 4, "ngIf"], [1, "table", "table-striped", "defect-table"], ["scope", "col"], ["scope", "col", 4, "ngIf"], ["id", "defRes", 4, "ngIf"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-outline-gray"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 3, "click", 4, "ngIf"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-orange", 3, "click"], ["id", "confirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-body"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "class", "btn btn-outline-secondary border-0", "data-bs-dismiss", "modal", 3, "click", 4, "ngIf"], ["id", "confirmationModalDel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/Check circle.svg"], ["header", "Previous Defects", 3, "visible", "modal", "draggable", "resizable", "maximizable", "visibleChange"], ["header", "Brake Reads", 3, "visible", "modal", "draggable", "resizable", "maximizable", "visibleChange"], [1, "table-bordered", "table-striped"], ["id", "headertb"], ["header", "Exhaust Read", 3, "visible", "modal", "draggable", "resizable", "maximizable", "visibleChange"], ["id", "tankerConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "tankerConfirmationModal", "aria-hidden", "true", 1, "modal", "fade"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "vin", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "tanker", "aria-selected", "true", 1, "nav-link", 3, "click"], [1, "stop-watch"], ["pTooltip", "Duration of device inspection", "tooltipPosition", "top", 1, "display"], [1, "device-status"], ["mode", "indeterminate"], [1, "col"], ["id", "chvin", 1, "row", "form-fields"], ["id", "checkDets", 1, "form-check"], ["id", "rcb", 1, "row"], [1, "form-check"], ["type", "checkbox", "formControlName", "isVinCh", "id", "v1", 1, "form-check-input", "chkbx"], ["for", "v1", 1, "form-check-label"], ["type", "checkbox", "formControlName", "isPlateCh", "id", "p1", 1, "form-check-input", "chkbx"], ["for", "p1", 1, "form-check-label"], ["type", "checkbox", "formControlName", "isManfCh", "id", "m1", 1, "form-check-input", "chkbx"], ["for", "m1", 1, "form-check-label"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "btn", "btn-orange", 3, "disabled", "click"], [1, "col-md-4"], ["type", "text", "formControlName", "qatarVinNo", "readonly", "", 1, "form-control"], ["id", "devbtn", 1, "col-md-4"], ["type", "button", 1, "btn", "btn-orange"], ["type", "text", "formControlName", "fahesSerialNo", "readonly", "", 1, "form-control"], ["formGroupName", "inspectiondetails", 1, "col-md-4"], ["type", "text", "formControlName", "vinNo", "readonly", "", 1, "form-control"], [3, "value"], [1, "error-message"], [2, "color", "orange", "margin-top", "10px"], [1, "bi", "bi-arrow-right-square-fill", 2, "font-size", "14px"], [2, "display", "contents"], ["for", "checkbox", "pTooltip", "Start Device", "tooltipPosition", "left", 1, "switch"], ["type", "checkbox", "id", "checkbox", "formControlName", "deviceStartFlag", "name", "deviceStartFlag", 3, "checked", "ngModelChange"], [1, "slider", "round"], [1, "col-6"], [1, "btn-radio"], ["type", "radio", "formControlName", "selectedFuelType", "name", "selectedFuelType", 3, "id", "value", "checked"], [1, "w-100", 3, "for"], ["type", "radio", "formControlName", "selectedDriveMode", "name", "selectedDriveMode", 3, "id", "value", "checked"], [1, "col-lg-4"], ["type", "radio", "formControlName", "selectedParkingBrake", "name", "selectedParkingBrake", 3, "id", "value", "checked"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-outline-gray", 3, "click"], [3, "ngStyle", "click"], [3, "click"], ["scope", "row"], ["data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "deletedefect", 3, "click"], [1, "bi", "bi-trash3-fill"], ["id", "defRes"], ["class", "pass", 4, "ngIf"], ["class", "fail", 4, "ngIf"], [1, "pass"], [1, "fail"]],
    template: function VehicleInspectionComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "html");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](2, "body")(3, "form", 0)(4, "div", 1)(5, "div", 2)(6, "ul", 3)(7, "li", 4)(8, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_8_listener() {
          return ctx.setActiveTab("details");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](9, " Vehicle Information ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](10, VehicleInspectionComponent_li_10_Template, 3, 4, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](11, VehicleInspectionComponent_li_11_Template, 3, 4, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](12, "li", 7)(13, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_13_listener() {
          return ctx.setActiveTab("config");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](14, " Vehicle Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](15, "li", 7)(16, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_16_listener() {
          return ctx.setActiveTab("tankdets");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](17, " Tank Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](18, "li", 7)(19, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_19_listener() {
          return ctx.setActiveTab("visual-defect");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](20, " Visual Defect List ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](21, "li", 7)(22, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_22_listener() {
          return ctx.getDefectList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](23, "Defect List");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](24, "li", 7)(25, "button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_25_listener() {
          return ctx.setActiveTab("inst");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](26, "Instructions");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](27, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](28, VehicleInspectionComponent_span_28_Template, 2, 0, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](29, " Vehicle Plate No: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](30, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](32, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](33, VehicleInspectionComponent_div_33_Template, 3, 3, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](34, VehicleInspectionComponent_div_34_Template, 4, 4, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](35, "div", 17)(36, "div", 18)(37, "div", 19)(38, "div", 20)(39, "div", 21)(40, "section", 22)(41, "div", 17)(42, "div", 23)(43, "div", 17)(44, "div", 18)(45, "div", 24)(46, "div", 25)(47, "div", 26)(48, "div", 27)(49, "h2", 28)(50, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](51, " Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](52, "div", 30)(53, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](54, VehicleInspectionComponent_div_54_Template, 18, 0, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](55, "div", 33)(56, "div", 34)(57, "label", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](58, " License Plate No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](59, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](60, "div", 37)(61, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](62, " License Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](63, "input", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](64, "div", 37)(65, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](66, "Vehicle Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](67, "input", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](68, "div", 37)(69, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](70, "Owner PID Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](71, "input", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](72, "div", 34)(73, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](74, "Owner PID");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](75, "input", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](76, "div", 34)(77, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](78, "Owner Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](79, "input", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](80, "div", 37)(81, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](82, "Istimara Expiry Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](83, "input", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](84, "div", 33)(85, "div", 34)(86, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](87, "VIN No");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](88, "input", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](89, "div", 34)(90, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](91, "Manufacturer");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](92, "input", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](93, "div", 34)(94, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](95, "Model");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](96, "input", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](97, "div", 34)(98, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](99, "Manufacturing Year");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](100, "input", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](101, "div", 34)(102, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](103, "Cylinders");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](104, "input", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](105, "div", 34)(106, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](107, "Weight (kg)");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](108, "input", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](109, "div", 34)(110, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](111, "Payload Weight (kg)");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](112, "input", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](113, "div", 37)(114, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](115, "Color");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](116, "input", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](117, "div", 37)(118, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](119, "Sub Color");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](120, "input", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](121, "div", 34)(122, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](123, "Seats");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](124, "input", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](125, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](126, VehicleInspectionComponent_div_126_Template, 20, 2, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](127, "div", 17)(128, "div", 55)(129, "button", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_129_listener() {
          return ctx.back();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](130, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](131, VehicleInspectionComponent_button_131_Template, 2, 1, "button", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](132, "div", 58)(133, "div", 59)(134, "div", 21)(135, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](136, " VIN Stamping ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](137, VehicleInspectionComponent_div_137_Template, 8, 0, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](138, VehicleInspectionComponent_div_138_Template, 8, 0, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](139, VehicleInspectionComponent_div_139_Template, 9, 0, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](140, "br")(141, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](142, "div", 17)(143, "div", 55)(144, "button", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_144_listener() {
          return ctx.cancelDefectList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](145, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](146, "button", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](147, " Resend ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](148, "button", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](149, " Submit ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](150, "div", 62)(151, "div", 59)(152, "form", 0)(153, "div", 21)(154, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](155, " Tanker Certificate ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](156, "div", 17)(157, "div", 63)(158, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](159, "Tanker Shape *");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](160, "select", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](161, VehicleInspectionComponent_option_161_Template, 2, 2, "option", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](162, VehicleInspectionComponent_div_162_Template, 2, 0, "div", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](163, "div", 63)(164, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](165, " Length * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](166, "input", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](167, VehicleInspectionComponent_div_167_Template, 2, 0, "div", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](168, "div", 63)(169, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](170, " Width * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](171, "input", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](172, VehicleInspectionComponent_div_172_Template, 2, 0, "div", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](173, "div", 63)(174, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](175, " Height * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](176, "input", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](177, VehicleInspectionComponent_div_177_Template, 2, 0, "div", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](178, "div", 17)(179, "div", 63)(180, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](181, "Factor *");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](182, "input", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](183, VehicleInspectionComponent_div_183_Template, 2, 0, "div", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](184, "div", 63)(185, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](186, "Volume In Liter");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](187, "input", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](188, "div", 63)(189, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](190, "Volume In UK Gallon");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](191, "input", 73);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](192, "div", 63)(193, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](194, "Volume In US Gallon");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](195, "input", 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](196, "div", 63)(197, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](198, "Remarks");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](199, "input", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](200, VehicleInspectionComponent_div_200_Template, 2, 0, "div", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](201, VehicleInspectionComponent_div_201_Template, 2, 0, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](202, "br")(203, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](204, "div", 17)(205, "div", 77)(206, "button", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](207, " Submit ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](208, "div", 79)(209, "div", 59)(210, "div", 21)(211, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](212, " Instructions ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](213, VehicleInspectionComponent_h3_213_Template, 3, 1, "h3", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](214, "div", 17)(215, "div", 55)(216, "button", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_216_listener() {
          return ctx.back();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](217, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](218, "button", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_218_listener() {
          return ctx.confirmIns();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](219, "Next");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](220, "div", 82)(221, "div", 59)(222, "div", 21)(223, "div", 83)(224, "div", 84)(225, "h2", 85);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](226, " Vehicle Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](227, VehicleInspectionComponent_div_227_Template, 4, 3, "div", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](228, "div", 87);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](229, VehicleInspectionComponent_div_229_Template, 6, 1, "div", 88);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](230, "div", 89)(231, "div", 17)(232, "div", 18)(233, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](234, "Drive Mode");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](235, VehicleInspectionComponent_div_235_Template, 5, 6, "div", 90);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](236, "div", 89)(237, "div", 17)(238, "div", 18)(239, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](240, "Parking Brake");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](241, VehicleInspectionComponent_div_241_Template, 5, 6, "div", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](242, "div", 87)(243, "div", 89)(244, "div", 33)(245, "div", 92)(246, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](247, "No. of Axles");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](248, "input", 93);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](249, "div", 92)(250, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](251, "Mileage(km) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](252, VehicleInspectionComponent_span_252_Template, 2, 0, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](253, "input", 94);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](254, VehicleInspectionComponent_div_254_Template, 6, 1, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](255, VehicleInspectionComponent_div_255_Template, 4, 0, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](256, "div", 95);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](257, "visual-defect-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](258, "div", 96)(259, "div", 59)(260, "div", 21)(261, "div", 97)(262, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](263, " Defects List ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](264, "div", 98);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](265, VehicleInspectionComponent_b_265_Template, 2, 3, "b", 99);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](266, " \u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](267, VehicleInspectionComponent_b_267_Template, 2, 3, "b", 99);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](268, " \u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](269, VehicleInspectionComponent_ng_container_269_Template, 3, 0, "ng-container", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](270, "table", 100)(271, "thead")(272, "tr")(273, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](274, "Main Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](275, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](276, "Defects");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](277, VehicleInspectionComponent_th_277_Template, 2, 0, "th", 102);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](278, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](279, "Remarks");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](280, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](281, "Evaluation");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](282, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](283, "Classification");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](284, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](285, " -");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](286, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](287, VehicleInspectionComponent_tr_287_Template, 14, 7, "tr", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](288, VehicleInspectionComponent_div_288_Template, 5, 4, "div", 103);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](289, "div", 17)(290, "div", 55)(291, "button", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_291_listener() {
          return ctx.backToVisualDefectsPage();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](292, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](293, "button", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](294, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](295, VehicleInspectionComponent_button_295_Template, 4, 0, "button", 105);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](296, "button", 106);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_296_listener() {
          ctx.isDefectConfirm = true;
          return ctx.actionType = 1;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](297, "Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](298, "div", 107)(299, "div", 108)(300, "div", 109);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](301, "div", 110);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](302, "div", 111)(303, "div", 17)(304, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](305, "img", 112);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](306, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](307, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](308, VehicleInspectionComponent_div_308_Template, 2, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](309, VehicleInspectionComponent_div_309_Template, 2, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](310, VehicleInspectionComponent_div_310_Template, 4, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](311, VehicleInspectionComponent_div_311_Template, 4, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](312, VehicleInspectionComponent_div_312_Template, 2, 1, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](313, "br")(314, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](315, "button", 113);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_315_listener() {
          ctx.isCancelConfig = false;
          ctx.isDefectConfirm = false;
          return ctx.defectDelIndex = null;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](316, "img", 114);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](317, VehicleInspectionComponent_button_317_Template, 2, 0, "button", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](318, VehicleInspectionComponent_button_318_Template, 2, 0, "button", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](319, VehicleInspectionComponent_button_319_Template, 2, 0, "button", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](320, VehicleInspectionComponent_button_320_Template, 2, 0, "button", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](321, "div", 116)(322, "div", 108)(323, "div", 109);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](324, "div", 110);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](325, "div", 111)(326, "div", 17)(327, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](328, "img", 112);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](329, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](330, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](331, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](332);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](333, "br")(334, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](335, "button", 117);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](336, "img", 114);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](337, "button", 113);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_337_listener() {
          return ctx.deleteDefectItemList(ctx.defectDelIndex);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](338, "img", 118);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](339, "p-dialog", 119);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("visibleChange", function VehicleInspectionComponent_Template_p_dialog_visibleChange_339_listener($event) {
          return ctx.previousInspectionDefectsVisiblityPopup = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](340, "table", 100)(341, "thead")(342, "tr")(343, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](344, "Main Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](345, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](346, "Defects");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](347, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](348, "Remarks");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](349, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](350, "Evaluation");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](351, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](352, "Classification");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](353, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](354, VehicleInspectionComponent_tr_354_Template, 16, 5, "tr", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](355, "p-dialog", 120);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("visibleChange", function VehicleInspectionComponent_Template_p_dialog_visibleChange_355_listener($event) {
          return ctx.brakeVisiblility = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](356, "table", 121)(357, "thead")(358, "tr", 122)(359, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](360, "Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](361, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](362, "Left Value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](363, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](364, "Right Value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](365, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](366, "Weight");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](367, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](368, "Actual Difference");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](369, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](370, "Difference Operation");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](371, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](372, "Max Difference");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](373, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](374, "Actual Deceleration");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](375, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](376, "Deceleration Operation");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](377, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](378, "Min Deceleration");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](379, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](380, VehicleInspectionComponent_tr_380_Template, 21, 8, "tr", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](381, "p-dialog", 123);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("visibleChange", function VehicleInspectionComponent_Template_p_dialog_visibleChange_381_listener($event) {
          return ctx.exhaustVisiblility = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](382, "table", 121)(383, "thead")(384, "tr", 122)(385, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](386, " Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](387, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](388, "Reading Value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](389, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](390, "Operation");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](391, "th", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](392, "Limit Value");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](393, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](394, VehicleInspectionComponent_tr_394_Template, 9, 4, "tr", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](395, "div", 124)(396, "div", 108)(397, "div", 109);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](398, "div", 110);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](399, "div", 111)(400, "div", 17)(401, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](402, "img", 112);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](403, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](404, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](405, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](406, " Are you sure from tanker measurement values ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](407, "br")(408, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](409, "button", 117);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](410, "img", 114);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](411, "button", 113);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_411_listener() {
          return ctx.confirmTankerCertificate();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](412, "img", 118);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("formGroup", ctx.insForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "details");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isVinService);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService || ctx.isExternal);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleProp"]("pointer-events", ctx.isConfirmedDefects || !ctx.insForm.get("isVinCh").value || !ctx.insForm.get("isPlateCh").value || !ctx.insForm.get("isManfCh").value ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "config");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService || !ctx.isTank);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleProp"]("pointer-events", ctx.isConfirmedDefects ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "tankdets");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleProp"]("pointer-events", !ctx.visualDefectActive || ctx.isConfirmedDefects || !ctx.insForm.get("isVinCh").value || !ctx.insForm.get("isPlateCh").value || !ctx.insForm.get("isManfCh").value ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "visual-defect");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleProp"]("pointer-events", !ctx.isConfirmedDefects ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "defect-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isExternal);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ctx.insForm.get("inspectiondetails").value.plateNo, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isTimerVisiable);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isDeviceStatusShown);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "details");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.insForm.get("inspectiondetails").value != undefined && ctx.insForm.get("inspectiondetails").value.inspectionStepId == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](72);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isExternal);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx.isConfirmedDefects);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "vin");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isNewStamp);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isNewStamp);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isReStamp);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("disabled", !ctx.enableVinSubmit);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "tanker" || ctx.activeTab === "tankdets");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("formGroup", ctx.tankereRequestForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.tankerShapes);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("shapeId").hasError("required") && ctx.tankereRequestForm.get("shapeId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("length").hasError("required") && ctx.tankereRequestForm.get("length").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("width").hasError("required") && ctx.tankereRequestForm.get("width").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("height").hasError("required") && ctx.tankereRequestForm.get("height").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("factor").hasError("required") && ctx.tankereRequestForm.get("factor").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("remarks").hasError("required") && ctx.tankereRequestForm.get("remarks").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isTankerMeasurementDiffersFromLastYear);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("disabled", ctx.tankereRequestForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.instructions);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "config");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.insForm.get("inspectiondetails").value.isVehicleConfigRequired);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.insForm.get("inspectiondetails").value.categoryId != 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.insForm.get("driveModes").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.insForm.get("parkingBrakes").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx.configDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isExternal);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx.configDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx.configDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.configDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "visual-defect");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵclassProp"]("active", ctx.activeTab === "defect-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.deviceResultsDto.isBrakeTested);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.deviceResultsDto.isExhaustEmissTested);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.previousDeviceDefects.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx.isLocationEmpty);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.defectList);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.classificationsResult != undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.insForm.get("inspectiondetails").value.isFinalStep);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isVinService);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx.isDefectConfirm && ctx.activeTab == "defect-list" && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isDefectConfirm && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isCancelConfig && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.defectDelIndex != null && !ctx.isDefectConfirm && !ctx.isCancelConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isDefectConfirm || ctx.isCancelConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.defectDelIndex != null && !ctx.isDefectConfirm && !ctx.isCancelConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx.isDefectConfirm && ctx.activeTab == "defect-list" && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isVinService && ctx.activeTab == "vin");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" Are you sure you want to delete this ", ctx.confirmEval, " defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpureFunction0"](114, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("visible", ctx.previousInspectionDefectsVisiblityPopup)("modal", true)("draggable", false)("resizable", false)("maximizable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.previousDeviceDefects);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpureFunction0"](115, _c3));
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("visible", ctx.brakeVisiblility)("modal", true)("draggable", false)("resizable", false)("maximizable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](25);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.brakeReads);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵpureFunction0"](116, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("visible", ctx.exhaustVisiblility)("modal", true)("draggable", false)("resizable", false)("maximizable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx.exhaustEmissReads);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_26__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_26__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_26__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_23__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_23__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_23__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormControlName, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormGroupName, primeng_progressbar__WEBPACK_IMPORTED_MODULE_28__.ProgressBar, primeng_dialog__WEBPACK_IMPORTED_MODULE_29__.Dialog, primeng_tooltip__WEBPACK_IMPORTED_MODULE_30__.Tooltip, _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_21__.VisualDefectListComponent],
    styles: ["#confirmationModal[_ngcontent-%COMP%] {\n    font-weight: bold;\n    text-align: center;\n    font-size: 20px;\n}\n\n#confirmationModal2[_ngcontent-%COMP%] {\n    font-weight: bold;\n    text-align: center;\n    font-size: 20px;\n}\n\n#confirmationModalDel[_ngcontent-%COMP%] {\n    font-weight: bold;\n    text-align: center;\n    font-size: 20px;\n}\n\n.device-status[_ngcontent-%COMP%] {\n    padding: 10px;\n}\n\n#plno[_ngcontent-%COMP%] {\n    padding: 20px;\n    float: right;\n}\n\n.error-message[_ngcontent-%COMP%] {\n    color: red;\n    font-style: italic;\n}\n\n.btn-orange[_ngcontent-%COMP%]:disabled {\n    background-color: #ef9c3d;\n    color: #ffff;\n}\n\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\n    appearance: none;\n    margin: 0;\n}\n\n#v-details[_ngcontent-%COMP%] {\n    background-color: #ffff;\n}\n\nh2[_ngcontent-%COMP%] {\n    border: 0px;\n}\n\n.accordion-item[_ngcontent-%COMP%] {\n    border: 0px;\n}\n\n[_ngcontent-%COMP%]::placeholder {\n    font-size: 14px;\n    color: grey !important;\n    opacity: 0.5;\n    font-style: italic;\n}\n\n#btnConfirm[_ngcontent-%COMP%] {\n    margin-top: 0;\n}\n\n.end-btns[_ngcontent-%COMP%] {\n    margin-top: 0px;\n}\n\n#techLeg[_ngcontent-%COMP%] {\n    text-align: center;\n    margin-bottom: 30px;\n    display: flex;\n    justify-content: center;\n}\n\n#defRes[_ngcontent-%COMP%] {\n    border-radius: 5px;\n    padding: 10px;\n    width: 600px !important;\n    background-color: #ffff;\n    color: #ef9c3d;\n    font-weight: bold;\n    font-size: large;\n    margin-right: 20px;\n    margin-left: 200px;\n}\n\n.pass[_ngcontent-%COMP%] {\n    border: 1px solid rgb(35, 168, 35);\n    border-radius: 5px;\n    padding: 10px;\n    width: 200px;\n    color: rgb(35, 168, 35);\n    background-color: #ffff;\n    font-weight: bold;\n    justify-content: center;\n    margin-right: 40px;\n}\n\n.fail[_ngcontent-%COMP%] {\n    border: 1px solid red;\n    border-radius: 5px;\n    padding: 10px;\n    width: 200px;\n    color: red;\n    background-color: #ffff;\n    font-weight: bold;\n    justify-content: center;\n    margin-left: 40px;\n}\n\n.defect-device-result[_ngcontent-%COMP%] {\n    font-size: 19px;\n    text-align: right;\n}\n\n.defect-list-title[_ngcontent-%COMP%] {\n    float: left;\n}\n\np-dialog[_ngcontent-%COMP%]   table[_ngcontent-%COMP%] {\n    width: 100% !important;\n}\n\n.classification-result[_ngcontent-%COMP%] {\n    margin: 27px;\n    font-size: medium;\n    font-weight: 700;\n}\n\n.chkbx[_ngcontent-%COMP%] {\n    width: 1.5em;\n    height: 1.5em;\n}\n\n.chkbx[_ngcontent-%COMP%]:focus {\n    outline: none;\n    border: none;\n}\n\n.chkbx[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked {\n    background-color: #F89828 !important;\n    border: solid 1px #F89828 !important;\n}\n\ninput[type=\"checkbox\"][_ngcontent-%COMP%] {\n    margin-right: 10px;\n    color: #ef9c3d;\n}\n\n.form-check-label[_ngcontent-%COMP%] {\n    margin-left: 5px;\n    color: black;\n}\n\n#rcb[_ngcontent-%COMP%] {\n    margin-top: 5px;\n}\n\n#tankerConfirmationModal[_ngcontent-%COMP%] {\n    font-weight: bold;\n    text-align: center;\n    font-size: 20px;\n}\n\n#checkDets[_ngcontent-%COMP%] {\n    border: 1px solid #ef9c3d;\n    width: 200px;\n    border-radius: 10px;\n    font-size: larger;\n    margin-bottom: 20px;\n}\n\n#v1[_ngcontent-%COMP%], #p1[_ngcontent-%COMP%], #m1[_ngcontent-%COMP%] {\n    color: black;\n}\n\n#highlightText[_ngcontent-%COMP%] {\n    border: 1px solid #ef9c3d;\n}\n\n.stop-watch[_ngcontent-%COMP%] {\n    font-family: 'Source Code Pro', monospace;\n    text-align: center;\n    font-size: 2em;\n    padding: 30px;\n}\n\n#arrowNav[_ngcontent-%COMP%] {\n    float: right;\n    border: 1px solid #F89828;\n    background-color: #ffff;\n    color: #F89828;\n}\n\n    #arrowNav[_ngcontent-%COMP%]:hover {\n        color: #ffff;\n        background-color: #F89828;\n    }\n\n#devbtn[_ngcontent-%COMP%] {\n    margin-top: 35px;\n}\n\n.switch[_ngcontent-%COMP%] {\n    display: inline-block;\n    height: 34px;\n    position: relative;\n    width: 60px;\n}\n\n    .switch[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n        display: none;\n    }\n\n.slider[_ngcontent-%COMP%] {\n    background-color: #ccc;\n    bottom: 0;\n    cursor: pointer;\n    left: 0;\n    position: absolute;\n    right: 0;\n    top: 0;\n    transition: .4s;\n}\n\n    .slider[_ngcontent-%COMP%]:before {\n        background-color: #fff;\n        bottom: 4px;\n        content: \"\";\n        height: 26px;\n        left: 4px;\n        position: absolute;\n        transition: .4s;\n        width: 26px;\n    }\n\ninput[_ngcontent-%COMP%]:checked    + .slider[_ngcontent-%COMP%] {\n    background-color: #f0bc82;\n}\n\n    input[_ngcontent-%COMP%]:checked    + .slider[_ngcontent-%COMP%]:before {\n        transform: translateX(26px);\n    }\n\n.slider.round[_ngcontent-%COMP%] {\n    border-radius: 34px;\n}\n\n    .slider.round[_ngcontent-%COMP%]:before {\n        border-radius: 50%;\n    }\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL2NvbXBvbmVudHMvdmVoaWNsZS1pbnNwZWN0aW9uL3ZlaGljbGUtaW5zcGVjdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksYUFBYTtBQUNqQjs7QUFFQTtJQUNJLGFBQWE7SUFDYixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksVUFBVTtJQUNWLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCOztBQUVBOztJQUdJLGdCQUFnQjtJQUNoQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSx1QkFBdUI7QUFDM0I7O0FBRUE7SUFDSSxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxlQUFlO0lBQ2Ysc0JBQXNCO0lBQ3RCLFlBQVk7SUFDWixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksZUFBZTtBQUNuQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIsYUFBYTtJQUNiLHVCQUF1QjtBQUMzQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLHVCQUF1QjtJQUN2QixjQUFjO0lBQ2QsaUJBQWlCO0lBQ2pCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksa0NBQWtDO0lBQ2xDLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2IsWUFBWTtJQUNaLHVCQUF1QjtJQUN2Qix1QkFBdUI7SUFDdkIsaUJBQWlCO0lBQ2pCLHVCQUF1QjtJQUN2QixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxxQkFBcUI7SUFDckIsa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixZQUFZO0lBQ1osVUFBVTtJQUNWLHVCQUF1QjtJQUN2QixpQkFBaUI7SUFDakIsdUJBQXVCO0lBQ3ZCLGlCQUFpQjtBQUNyQjs7QUFFQTtJQUNJLGVBQWU7SUFDZixpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLFlBQVk7SUFDWixhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksYUFBYTtJQUNiLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxvQ0FBb0M7SUFDcEMsb0NBQW9DO0FBQ3hDOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixpQkFBaUI7SUFDakIsbUJBQW1CO0FBQ3ZCOztBQUVBOzs7SUFHSSxZQUFZO0FBQ2hCOztBQUVBO0lBQ0kseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0kseUNBQXlDO0lBQ3pDLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsYUFBYTtBQUNqQjs7QUFFQTtJQUNJLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsdUJBQXVCO0lBQ3ZCLGNBQWM7QUFDbEI7O0lBRUk7UUFDSSxZQUFZO1FBQ1oseUJBQXlCO0lBQzdCOztBQUVKO0lBQ0ksZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0kscUJBQXFCO0lBQ3JCLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsV0FBVztBQUNmOztJQUVJO1FBQ0ksYUFBYTtJQUNqQjs7QUFFSjtJQUNJLHNCQUFzQjtJQUN0QixTQUFTO0lBQ1QsZUFBZTtJQUNmLE9BQU87SUFDUCxrQkFBa0I7SUFDbEIsUUFBUTtJQUNSLE1BQU07SUFDTixlQUFlO0FBQ25COztJQUVJO1FBQ0ksc0JBQXNCO1FBQ3RCLFdBQVc7UUFDWCxXQUFXO1FBQ1gsWUFBWTtRQUNaLFNBQVM7UUFDVCxrQkFBa0I7UUFDbEIsZUFBZTtRQUNmLFdBQVc7SUFDZjs7QUFFSjtJQUNJLHlCQUF5QjtBQUM3Qjs7SUFFSTtRQUNJLDJCQUEyQjtJQUMvQjs7QUFFSjtJQUNJLG1CQUFtQjtBQUN2Qjs7SUFFSTtRQUNJLGtCQUFrQjtJQUN0QiIsInNvdXJjZXNDb250ZW50IjpbIiNjb25maXJtYXRpb25Nb2RhbCB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuI2NvbmZpcm1hdGlvbk1vZGFsMiB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuI2NvbmZpcm1hdGlvbk1vZGFsRGVsIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4uZGV2aWNlLXN0YXR1cyB7XG4gICAgcGFkZGluZzogMTBweDtcbn1cblxuI3Bsbm8ge1xuICAgIHBhZGRpbmc6IDIwcHg7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4uZXJyb3ItbWVzc2FnZSB7XG4gICAgY29sb3I6IHJlZDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG59XG5cbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xuICAgIGNvbG9yOiAjZmZmZjtcbn1cblxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcbmlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b24ge1xuICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcbiAgICBhcHBlYXJhbmNlOiBub25lO1xuICAgIG1hcmdpbjogMDtcbn1cblxuI3YtZGV0YWlscyB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmY7XG59XG5cbmgyIHtcbiAgICBib3JkZXI6IDBweDtcbn1cblxuLmFjY29yZGlvbi1pdGVtIHtcbiAgICBib3JkZXI6IDBweDtcbn1cblxuOjpwbGFjZWhvbGRlciB7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGNvbG9yOiBncmV5ICFpbXBvcnRhbnQ7XG4gICAgb3BhY2l0eTogMC41O1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbn1cblxuI2J0bkNvbmZpcm0ge1xuICAgIG1hcmdpbi10b3A6IDA7XG59XG5cbi5lbmQtYnRucyB7XG4gICAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG4jdGVjaExlZyB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuI2RlZlJlcyB7XG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgd2lkdGg6IDYwMHB4ICFpbXBvcnRhbnQ7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmY7XG4gICAgY29sb3I6ICNlZjljM2Q7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zaXplOiBsYXJnZTtcbiAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwMHB4O1xufVxuXG4ucGFzcyB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDM1LCAxNjgsIDM1KTtcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgcGFkZGluZzogMTBweDtcbiAgICB3aWR0aDogMjAwcHg7XG4gICAgY29sb3I6IHJnYigzNSwgMTY4LCAzNSk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmY7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLXJpZ2h0OiA0MHB4O1xufVxuXG4uZmFpbCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmVkO1xuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICBwYWRkaW5nOiAxMHB4O1xuICAgIHdpZHRoOiAyMDBweDtcbiAgICBjb2xvcjogcmVkO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIG1hcmdpbi1sZWZ0OiA0MHB4O1xufVxuXG4uZGVmZWN0LWRldmljZS1yZXN1bHQge1xuICAgIGZvbnQtc2l6ZTogMTlweDtcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLmRlZmVjdC1saXN0LXRpdGxlIHtcbiAgICBmbG9hdDogbGVmdDtcbn1cblxucC1kaWFsb2cgdGFibGUge1xuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG59XG5cbi5jbGFzc2lmaWNhdGlvbi1yZXN1bHQge1xuICAgIG1hcmdpbjogMjdweDtcbiAgICBmb250LXNpemU6IG1lZGl1bTtcbiAgICBmb250LXdlaWdodDogNzAwO1xufVxuXG4uY2hrYngge1xuICAgIHdpZHRoOiAxLjVlbTtcbiAgICBoZWlnaHQ6IDEuNWVtO1xufVxuXG4uY2hrYng6Zm9jdXMge1xuICAgIG91dGxpbmU6IG5vbmU7XG4gICAgYm9yZGVyOiBub25lO1xufVxuXG4uY2hrYnggaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdOmNoZWNrZWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4MjggIWltcG9ydGFudDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjRjg5ODI4ICFpbXBvcnRhbnQ7XG59XG5cbmlucHV0W3R5cGU9XCJjaGVja2JveFwiXSB7XG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIGNvbG9yOiAjZWY5YzNkO1xufVxuXG4uZm9ybS1jaGVjay1sYWJlbCB7XG4gICAgbWFyZ2luLWxlZnQ6IDVweDtcbiAgICBjb2xvcjogYmxhY2s7XG59XG5cbiNyY2Ige1xuICAgIG1hcmdpbi10b3A6IDVweDtcbn1cblxuI3RhbmtlckNvbmZpcm1hdGlvbk1vZGFsIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4jY2hlY2tEZXRzIHtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZWY5YzNkO1xuICAgIHdpZHRoOiAyMDBweDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGZvbnQtc2l6ZTogbGFyZ2VyO1xuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbiN2MSxcbiNwMSxcbiNtMSB7XG4gICAgY29sb3I6IGJsYWNrO1xufVxuXG4jaGlnaGxpZ2h0VGV4dCB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI2VmOWMzZDtcbn1cblxuLnN0b3Atd2F0Y2gge1xuICAgIGZvbnQtZmFtaWx5OiAnU291cmNlIENvZGUgUHJvJywgbW9ub3NwYWNlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXNpemU6IDJlbTtcbiAgICBwYWRkaW5nOiAzMHB4O1xufVxuXG4jYXJyb3dOYXYge1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjRjg5ODI4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmO1xuICAgIGNvbG9yOiAjRjg5ODI4O1xufVxuXG4gICAgI2Fycm93TmF2OmhvdmVyIHtcbiAgICAgICAgY29sb3I6ICNmZmZmO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xuICAgIH1cblxuI2RldmJ0biB7XG4gICAgbWFyZ2luLXRvcDogMzVweDtcbn1cblxuLnN3aXRjaCB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIGhlaWdodDogMzRweDtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgd2lkdGg6IDYwcHg7XG59XG5cbiAgICAuc3dpdGNoIGlucHV0IHtcbiAgICAgICAgZGlzcGxheTogbm9uZTtcbiAgICB9XG5cbi5zbGlkZXIge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNjY2M7XG4gICAgYm90dG9tOiAwO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBsZWZ0OiAwO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDA7XG4gICAgdHJhbnNpdGlvbjogLjRzO1xufVxuXG4gICAgLnNsaWRlcjpiZWZvcmUge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgICAgICBib3R0b206IDRweDtcbiAgICAgICAgY29udGVudDogXCJcIjtcbiAgICAgICAgaGVpZ2h0OiAyNnB4O1xuICAgICAgICBsZWZ0OiA0cHg7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdHJhbnNpdGlvbjogLjRzO1xuICAgICAgICB3aWR0aDogMjZweDtcbiAgICB9XG5cbmlucHV0OmNoZWNrZWQgKyAuc2xpZGVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjBiYzgyO1xufVxuXG4gICAgaW5wdXQ6Y2hlY2tlZCArIC5zbGlkZXI6YmVmb3JlIHtcbiAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDI2cHgpO1xuICAgIH1cblxuLnNsaWRlci5yb3VuZCB7XG4gICAgYm9yZGVyLXJhZGl1czogMzRweDtcbn1cblxuICAgIC5zbGlkZXIucm91bmQ6YmVmb3JlIHtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIH1cbiAgXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 75303:
/*!*****************************************************************************************!*\
  !*** ./src/app/modules/inspection/external-inspection/external-inspection.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExternalInspectionComponent": () => (/* binding */ ExternalInspectionComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_external_inspection_status__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/external-inspection-status */ 33219);
/* harmony import */ var src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/object-value-checker */ 12452);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);











function ExternalInspectionComponent_option_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const area_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", area_r6.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", area_r6.labelEname, " ");
  }
}
function ExternalInspectionComponent_option_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const location_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", location_r7.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"]("", location_r7.labelEname, " ");
  }
}
function ExternalInspectionComponent_div_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Date to must be more than date from ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function ExternalInspectionComponent_tr_81_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "td")(18, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_tr_81_Template_button_click_18_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10);
      const ext_r8 = restoredCtx.$implicit;
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r9.startExternalInspection(ext_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](19, " Start External Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ext_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r8.receiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r8.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r8.customerId, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r8.customerName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r8.contactPersonPhone, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r8.areaEname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r8.locationEname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ext_r8.externalVehicleStatusDescriptionEn);
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function ExternalInspectionComponent_li_87_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "li", 46)(1, "a", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_li_87_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r13);
      const i_r11 = restoredCtx.$implicit;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      ctx_r12.currentPage = i_r11 + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r12.getPagedExternal(ctx_r12.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const i_r11 = ctx.$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](2, _c0, ctx_r4.currentPage === i_r11 + 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](i_r11 + 1);
  }
}
function ExternalInspectionComponent_div_91_option_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const area_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", area_r19.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", area_r19.labelEname, " ");
  }
}
function ExternalInspectionComponent_div_91_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const location_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", location_r20.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"]("", location_r20.labelEname, " ");
  }
}
function ExternalInspectionComponent_div_91_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Date to must be more than date from ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function ExternalInspectionComponent_div_91_tr_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](16, " Completed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ext_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r21.receiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r21.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r21.customerId, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r21.customerName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r21.contactPersonPhone, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r21.areaEname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r21.locationEname, " ");
  }
}
function ExternalInspectionComponent_div_91_li_70_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "li", 46)(1, "a", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_div_91_li_70_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r24);
      const i_r22 = restoredCtx.$implicit;
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      ctx_r23.currentPage = i_r22 + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r23.getPagedHistoryExternal(ctx_r23.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const i_r22 = ctx.$implicit;
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](2, _c0, ctx_r18.currentPage === i_r22 + 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](i_r22 + 1);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
function ExternalInspectionComponent_div_91_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 48)(1, "div", 11)(2, "section", 12)(3, "form", 13)(4, "div", 14)(5, "div", 15)(6, "div", 16)(7, "div", 7)(8, "div", 17)(9, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10, " Area ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "select", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function ExternalInspectionComponent_div_91_Template_select_change_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r26);
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r25.getLocationArea(2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](12, "option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](13, ExternalInspectionComponent_div_91_option_13_Template, 2, 2, "option", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 17)(15, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](16, " Location ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "select", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](18, "option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](19, ExternalInspectionComponent_div_91_option_19_Template, 2, 2, "option", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](20, "div", 17)(21, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](22, " Receipt No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](23, "input", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "div", 17)(25, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](26, " Customer Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](27, "input", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "div", 17)(29, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](30, " From Date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "input", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ExternalInspectionComponent_div_91_Template_input_ngModelChange_31_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r26);
      const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r27.validateDateFilter());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "div", 17)(33, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](34, " To Date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](35, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ExternalInspectionComponent_div_91_Template_input_ngModelChange_35_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r26);
      const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r28.validateDateFilter());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](36, ExternalInspectionComponent_div_91_div_36_Template, 2, 0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](37, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](38, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](39, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_div_91_Template_button_click_39_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r26);
      const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r29.filterExternalHistory(1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](40, " Filter Results ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](41, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_div_91_Template_button_click_41_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r26);
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r30.filterExternalHistory(2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](42, " Clear Filter");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](43, "div", 30)(44, "table", 31)(45, "thead")(46, "tr", 32)(47, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](48, " Receipt No. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](50, " Plate No. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](51, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](52, " Customer ID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](53, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](54, " Customer Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](55, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](56, " Phone No. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](57, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](58, " Area ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](60, " Location ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](61, "th", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](62, " Status ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](63, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](64, ExternalInspectionComponent_div_91_tr_64_Template, 17, 7, "tr", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](65, "div", 35)(66, "ul", 36)(67, "li", 37)(68, "a", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_div_91_Template_a_click_68_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r26);
      const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      ctx_r31.currentPage = ctx_r31.currentPage - 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r31.getPagedHistoryExternal(ctx_r31.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](69, "i", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](70, ExternalInspectionComponent_div_91_li_70_Template, 3, 4, "li", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](71, "li", 37)(72, "a", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_div_91_Template_a_click_72_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r26);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      ctx_r32.currentPage = ctx_r32.currentPage + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r32.getPagedHistoryExternal(ctx_r32.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](73, "i", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx_r5.extHistForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r5.areaList);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r5.locationList);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx_r5.isDateFilterValid);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx_r5.isDateFilterValid);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r5.historyExternal);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](9, _c1, ctx_r5.currentPage == 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r5.pagesArray(ctx_r5.totalHist));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](11, _c1, ctx_r5.currentPage * ctx_r5.itemsPerPage >= ctx_r5.totalHist));
  }
}
class ExternalInspectionComponent {
  constructor(inspectionService, vehicleService, fb, sharedData, router, sideNav) {
    this.inspectionService = inspectionService;
    this.vehicleService = vehicleService;
    this.fb = fb;
    this.sharedData = sharedData;
    this.router = router;
    this.sideNav = sideNav;
    this.areaList = [];
    this.externalRequest = [];
    this.historyExternal = [];
    this.currentPage = 1;
    this.itemsPerPage = 10;
    this.externalInspectionStatus = src_app_core_utilities_enums_external_inspection_status__WEBPACK_IMPORTED_MODULE_0__.ExternalInpsectionStatus;
    this.isDateFilterValid = true;
    this.showHistExt = false;
    this.extInspectionForm = fb.group({
      selectedArea: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      selectedLocation: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      custName: [''],
      fromDate: [''],
      toDate: [''],
      receiptNo: ['']
    });
    this.extHistForm = fb.group({
      selectedArea: [''],
      selectedLocation: [''],
      custName: [''],
      fromDate: [''],
      toDate: [''],
      receiptNo: ['']
    });
  }
  ngOnInit() {
    this.sideNav.setHeaderValue(true, false);
    this.sideNav.setActiveEnt(3, 80);
    this.userId = parseInt(localStorage.getItem('userId'));
    this.stationId = parseInt(localStorage.getItem("stationId"));
    const extReq = {
      itemsFilter: {
        locationId: null,
        areaId: null,
        customerName: null,
        stationId: this.stationId,
        fromDate: null,
        toDate: null,
        receiptNo: null
      },
      pageIndex: 1,
      pageSize: this.itemsPerPage
    };
    // this.inspectionService.getExternalInspectionRequests(extReq).subscribe(
    //   (response) => {
    //     this.externalRequest = response.items.result;
    //     this.totalExt = response.items.totalRecords;
    //   }
    // );
    this.vehicleService.getAreas().subscribe(data => {
      this.areaList = data.items;
    });
  }
  checkAndSetToDate() {
    let toDate = this.extInspectionForm.get('toDate').value;
    let toDateObj = new Date(toDate);
    toDateObj.setHours(23, 59, 59, 999);
    console.log(toDateObj.toISOString());
    toDate = toDateObj.toISOString();
    this.updatedToDate = toDate;
  }
  validateDateFilter() {
    this.checkAndSetToDate();
    if (new Date(this.extInspectionForm.get('fromDate').value) > new Date(this.extInspectionForm.get('toDate').value)) {
      this.isDateFilterValid = false;
    } else {
      this.isDateFilterValid = true;
    }
  }
  getLocationArea(source) {
    // source: 1 -> current
    // source: 2 ->history
    const area = source == 1 ? this.extInspectionForm.get('selectedArea').value : this.extHistForm.get('selectedArea').value;
    this.vehicleService.getAreaLocations(area).subscribe(data => {
      this.locationList = data.items;
    });
    this.extInspectionForm.get('selectedLocation').setValue(this.extInspectionForm.get('selectedArea').value != 0 ? this.extInspectionForm.get('selectedArea').value : null);
  }
  filterExternal(action) {
    // Action:
    // 1 -> filter
    // 2 -> clear
    let extReq;
    if (action == 1) {
      extReq = {
        itemsFilter: {
          locationId: this.extInspectionForm.get('selectedLocation').value ? this.extInspectionForm.get('selectedLocation').value : null,
          areaId: this.extInspectionForm.get('selectedArea').value ? this.extInspectionForm.get('selectedArea').value : null,
          customerName: this.extInspectionForm.get('custName').value,
          stationId: this.stationId,
          fromDate: this.extInspectionForm.get('fromDate').value != "" ? new Date(this.extInspectionForm.get('fromDate').value) : null,
          toDate: this.extInspectionForm.get('toDate').value != "" ? this.updatedToDate : null,
          receiptNo: this.extInspectionForm.get('receiptNo').value
        },
        pageIndex: 1,
        pageSize: this.itemsPerPage
      };
    } else {
      this.extInspectionForm.get('selectedLocation').setValue(null);
      this.extInspectionForm.get('selectedArea').setValue(null);
      this.extInspectionForm.get('custName').setValue('');
      this.extInspectionForm.get('fromDate').setValue('');
      this.extInspectionForm.get('toDate').setValue('');
      this.extInspectionForm.get('receiptNo').setValue('');
      // extReq = {
      //   itemsFilter: {
      //     locationId: null,
      //     areaId: null,
      //     customerName: null,
      //     stationId: this.stationId,
      //     fromDate: null,
      //     toDate: null,
      //     receiptNo: null
      //   },
      //   pageIndex: 1,
      //   pageSize: this.itemsPerPage
      // }
      this.externalRequest = null;
    }
    this.inspectionService.getExternalInspectionRequests(extReq).subscribe(response => {
      this.externalRequest = response.items.result;
      this.totalExt = response.items.totalRecords;
    });
  }
  get totalPages() {
    if (this.totalExt > this.itemsPerPage) {
      return Math.ceil(this.totalExt / this.itemsPerPage);
    } else {
      return 1;
    }
  }
  get totalHist() {
    if (this.totalHistExt > this.itemsPerPage) {
      return Math.ceil(this.totalHistExt / this.itemsPerPage);
    } else {
      return 1;
    }
  }
  pagesArray(totalPages) {
    return Array.from({
      length: totalPages
    }, (_, index) => index);
  }
  getPagedExternal(page) {
    const extReq = {
      itemsFilter: {
        locationId: this.extInspectionForm.get('selectedLocation').value ? this.extInspectionForm.get('selectedLocation').value : null,
        areaId: this.extInspectionForm.get('selectedArea').value ? this.extInspectionForm.get('selectedArea').value : null,
        customerName: this.extInspectionForm.get('custName').value,
        stationId: this.stationId,
        fromDate: this.extInspectionForm.get('fromDate').value != "" ? new Date(this.extInspectionForm.get('fromDate').value) : null,
        toDate: this.extInspectionForm.get('toDate').value != "" ? new Date(this.extInspectionForm.get('toDate').value) : null,
        receiptNo: this.extInspectionForm.get('receiptNo').value ? this.extInspectionForm.get('receiptNo').value.toString() : null
      },
      pageIndex: page,
      pageSize: this.itemsPerPage
    };
    this.inspectionService.getExternalInspectionRequests(extReq).subscribe(response => {
      this.externalRequest = response.items.result;
      this.totalExt = response.items.totalRecords;
    });
  }
  startExternalInspection(ext) {
    // Reset the saved defect data from shared component
    //  this.sharedData.resetDefCmnt();
    //  this.sharedData.resetSaveDefectSrc();
    let startExternalRequestBody = {
      plateNo: parseInt(ext.plateNo),
      plateType: parseInt(ext.plateType),
      inspectorId: this.userId,
      vinNo: ext.vinNo,
      requestId: parseInt(ext.requestId)
    };
    this.inspectionService.startExternalInspectionRequest(startExternalRequestBody).subscribe(res => {
      var test = src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_1__.ObjectValueChecker.isNullOrEmpty(res.errorMessage);
      if (!src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_1__.ObjectValueChecker.isNullOrEmpty(res.errorMessage)) {
        this.sharedData.setExternalPlateType(ext.plateType > 9 ? ext.plateType : '0' + ext.plateType);
        this.sharedData.setExternalPlateNumber(ext.plateNo);
        this.sharedData.setExternalIns(true);
        this.router.navigate(['/inspection/vehicle-inspection']);
      }
    });
  }
  showHistory() {
    this.showHistExt = true;
    const histReq = {
      itemsFilter: {
        locationId: null,
        areaId: null,
        customerName: null,
        stationId: this.stationId,
        fromDate: null,
        toDate: null,
        receiptNo: null
      },
      pageIndex: 1,
      pageSize: this.itemsPerPage
    };
    this.inspectionService.getHistoryExternalInspectionRequests(histReq).subscribe(response => {
      this.historyExternal = response.items.result;
      this.totalHistExt = response.items.totalRecords;
    });
  }
  getPagedHistoryExternal(page) {
    const extReq = {
      itemsFilter: {
        locationId: this.extHistForm.get('selectedLocation').value ? this.extHistForm.get('selectedLocation').value : null,
        areaId: this.extHistForm.get('selectedArea').value ? this.extHistForm.get('selectedArea').value : null,
        customerName: this.extHistForm.get('custName').value,
        stationId: this.stationId,
        fromDate: this.extHistForm.get('fromDate').value != "" ? new Date(this.extHistForm.get('fromDate').value) : null,
        toDate: this.extHistForm.get('toDate').value != "" ? new Date(this.extHistForm.get('toDate').value) : null,
        receiptNo: this.extHistForm.get('receiptNo').value ? this.extHistForm.get('receiptNo').value.toString() : null
      },
      pageIndex: page,
      pageSize: this.itemsPerPage
    };
    this.inspectionService.getHistoryExternalInspectionRequests(extReq).subscribe(response => {
      this.historyExternal = response.items.result;
      this.totalHistExt = response.items.totalRecords;
    });
  }
  filterExternalHistory(action) {
    // Action:
    // 1 -> filter
    // 2 -> clear
    let extReq;
    if (action == 1) {
      extReq = {
        itemsFilter: {
          locationId: this.extHistForm.get('selectedLocation').value ? this.extHistForm.get('selectedLocation').value : null,
          areaId: this.extHistForm.get('selectedArea').value ? this.extHistForm.get('selectedArea').value : null,
          customerName: this.extHistForm.get('custName').value,
          stationId: this.stationId,
          fromDate: this.extHistForm.get('fromDate').value != "" ? new Date(this.extHistForm.get('fromDate').value) : null,
          toDate: this.extHistForm.get('toDate').value != "" ? this.updatedToDate : null,
          receiptNo: this.extHistForm.get('receiptNo').value
        },
        pageIndex: 1,
        pageSize: this.itemsPerPage
      };
    } else {
      this.extHistForm.get('selectedLocation').setValue(null);
      this.extHistForm.get('selectedArea').setValue(null);
      this.extHistForm.get('custName').setValue('');
      this.extHistForm.get('fromDate').setValue('');
      this.extHistForm.get('toDate').setValue('');
      this.extHistForm.get('receiptNo').setValue('');
      extReq = {
        itemsFilter: {
          locationId: null,
          areaId: null,
          customerName: null,
          stationId: this.stationId,
          fromDate: null,
          toDate: null,
          receiptNo: null
        },
        pageIndex: 1,
        pageSize: this.itemsPerPage
      };
    }
    this.inspectionService.getHistoryExternalInspectionRequests(extReq).subscribe(response => {
      this.historyExternal = response.items.result;
      this.totalHistExt = response.items.totalRecords;
    });
  }
  static #_ = this.ɵfac = function ExternalInspectionComponent_Factory(t) {
    return new (t || ExternalInspectionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_2__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: ExternalInspectionComponent,
    selectors: [["app-external-inspection"]],
    decls: 92,
    vars: 14,
    consts: [[1, "inspection-tab-menu"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "type", "button", "role", "tab", "data-bs-toggle", "tab", "data-bs-target", "#extRequest", "aria-controls", "extRequest", "aria-selected", "true", 1, "nav-link", "active"], ["id", "home-tab", "type", "button", "role", "tab", "data-bs-toggle", "tab", "data-bs-target", "#hist", "aria-controls", "hist", "aria-selected", "true", 1, "nav-link", 3, "click"], [1, "inspection-tab-content"], [1, "row"], [1, "col-12"], ["id", "myTabContent", 1, "tab-content"], ["id", "extRequest", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], [1, "tab-item-content"], [1, "section", "dashboard"], [3, "formGroup"], [1, "filter-section"], [1, "row", "mb-4"], [1, "col-lg-6"], [1, "col-md-4"], ["formControlName", "selectedArea", 1, "form-control", 3, "change"], ["value", ""], [3, "value", 4, "ngFor", "ngForOf"], ["formControlName", "selectedLocation", 1, "form-control"], ["type", "text", "formControlName", "receiptNo", 1, "form-control"], ["type", "text", "formControlName", "custName", 1, "form-control"], ["type", "date", "formControlName", "fromDate", 1, "form-control", 3, "ngModelChange"], ["type", "date", "formControlName", "toDate", 1, "form-control", 3, "ngModelChange"], ["class", "error-message", 4, "ngIf"], ["id", "btnFilter", 1, "col-md-4"], ["id", "btFilter", 1, "btn", "btn-outline-orange", 3, "disabled", "click"], ["id", "btClear", 1, "btn", "btn-outline-gray", 3, "click"], [1, "container", "mt-4"], [1, "table-bordered", "table-striped"], ["id", "headertb"], ["scope", "col"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], ["class", "tab-pane fade show active", "id", "hist", "role", "tabpanel", "aria-labelledby", "home-tab", 4, "ngIf"], [3, "value"], [1, "error-message"], ["id", "btnExt", 1, "btn", "btn-outline-orange", 3, "click"], [1, "page-item", 3, "ngClass"], ["id", "pagesId", 1, "page-link", 3, "click"], ["id", "hist", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"]],
    template: function ExternalInspectionComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "html")(1, "body")(2, "div", 0)(3, "div", 1)(4, "ul", 2)(5, "li", 3)(6, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](7, " External Inspection Requests ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "li", 3)(9, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_button_click_9_listener() {
          return ctx.showHistory();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10, " History ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "div", 6)(12, "div", 7)(13, "div", 8)(14, "div", 9)(15, "div", 10)(16, "div", 11)(17, "section", 12)(18, "form", 13)(19, "div", 14)(20, "div", 15)(21, "div", 16)(22, "div", 7)(23, "div", 17)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](25, " Area * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](26, "select", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function ExternalInspectionComponent_Template_select_change_26_listener() {
          return ctx.getLocationArea(1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](27, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](28, ExternalInspectionComponent_option_28_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "div", 17)(30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](31, " Location * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "select", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](33, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](34, ExternalInspectionComponent_option_34_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](35, "div", 17)(36, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](37, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](38, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](39, "div", 17)(40, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](41, " Customer Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](42, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](43, "div", 17)(44, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45, " From Date ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ExternalInspectionComponent_Template_input_ngModelChange_46_listener() {
          return ctx.validateDateFilter();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](47, "div", 17)(48, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](49, " To Date ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](50, "input", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ExternalInspectionComponent_Template_input_ngModelChange_50_listener() {
          return ctx.validateDateFilter();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](51, ExternalInspectionComponent_div_51_Template, 2, 0, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](52, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](53, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](54, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_button_click_54_listener() {
          return ctx.filterExternal(1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](55, " Filter Results ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_button_click_56_listener() {
          return ctx.filterExternal(2);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](57, " Clear Filter");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](58, "div", 30)(59, "table", 31)(60, "thead")(61, "tr", 32)(62, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](63, " Receipt No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](64, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](65, " Plate No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](67, " Customer ID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](68, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](69, " Customer Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](70, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](71, " Phone No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](72, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](73, " Area ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](74, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](75, " Location ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](76, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](77, " Status ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](78, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](79, " Action ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](80, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](81, ExternalInspectionComponent_tr_81_Template, 20, 8, "tr", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](82, "div", 35)(83, "ul", 36)(84, "li", 37)(85, "a", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_a_click_85_listener() {
          ctx.currentPage = ctx.currentPage - 1;
          return ctx.getPagedExternal(ctx.currentPage);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](86, "i", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](87, ExternalInspectionComponent_li_87_Template, 3, 4, "li", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](88, "li", 37)(89, "a", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_a_click_89_listener() {
          ctx.currentPage = ctx.currentPage + 1;
          return ctx.getPagedExternal(ctx.currentPage);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](90, "i", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](91, ExternalInspectionComponent_div_91_Template, 74, 13, "div", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.extInspectionForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.areaList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.locationList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx.isDateFilterValid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx.isDateFilterValid || !ctx.extInspectionForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.externalRequest);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](10, _c1, ctx.currentPage == 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.pagesArray(ctx.totalPages));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](12, _c1, ctx.currentPage * ctx.itemsPerPage >= ctx.totalExt));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.showHistExt);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName],
    styles: ["table[_ngcontent-%COMP%] {\n    margin-top: 50px;\n    text-align: center;\n    width: 100%;\n    border-collapse: collapse;\n    border-color: #fff;\n}\n\n#btnSearch[_ngcontent-%COMP%] {\n    float: right;\n}\n\n#btnExt[_ngcontent-%COMP%] {\n    font-size: 15px;\n}\n\n.pagination-container[_ngcontent-%COMP%] {\n    text-align: center;\n    margin-left: 500px;\n}\n\n.page-item[_ngcontent-%COMP%] {\n    margin: 0 2px;\n}\n\n.page-link[_ngcontent-%COMP%] {\n    cursor: pointer;\n    padding: 5px 5px;\n    text-decoration: none;\n}\n\n#pagesId[_ngcontent-%COMP%] {\n    background-color: white;\n    color: #F89828;\n}\n\nli.page-item.active[_ngcontent-%COMP%]   #pagesId[_ngcontent-%COMP%] {\n    background-color: #F89828;\n    color: white;\n    font-weight: bold;\n    border-color: #F89828;\n}\n\n.bi[_ngcontent-%COMP%] {\n    color: #F89828;\n}\n\n#btnFilter[_ngcontent-%COMP%] {\n    margin-top: 25px;\n}\n\n#btFilter[_ngcontent-%COMP%] {\n    margin-right: 5px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL2V4dGVybmFsLWluc3BlY3Rpb24vZXh0ZXJuYWwtaW5zcGVjdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gseUJBQXlCO0lBQ3pCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxlQUFlO0FBQ25COztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGFBQWE7QUFDakI7O0FBRUE7SUFDSSxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLHVCQUF1QjtJQUN2QixjQUFjO0FBQ2xCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixpQkFBaUI7SUFDakIscUJBQXFCO0FBQ3pCOztBQUVBO0lBQ0ksY0FBYztBQUNsQjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbInRhYmxlIHtcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIGJvcmRlci1jb2xvcjogI2ZmZjtcbn1cblxuI2J0blNlYXJjaCB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4jYnRuRXh0IHtcbiAgICBmb250LXNpemU6IDE1cHg7XG59XG5cbi5wYWdpbmF0aW9uLWNvbnRhaW5lciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi1sZWZ0OiA1MDBweDtcbn1cblxuLnBhZ2UtaXRlbSB7XG4gICAgbWFyZ2luOiAwIDJweDtcbn1cblxuLnBhZ2UtbGluayB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHBhZGRpbmc6IDVweCA1cHg7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG4jcGFnZXNJZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgY29sb3I6ICNGODk4Mjg7XG59XG5cbmxpLnBhZ2UtaXRlbS5hY3RpdmUgI3BhZ2VzSWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGJvcmRlci1jb2xvcjogI0Y4OTgyODtcbn1cblxuLmJpIHtcbiAgICBjb2xvcjogI0Y4OTgyODtcbn1cblxuI2J0bkZpbHRlciB7XG4gICAgbWFyZ2luLXRvcDogMjVweDtcbn1cblxuI2J0RmlsdGVyIHtcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 98442:
/*!*****************************************************************!*\
  !*** ./src/app/modules/inspection/inspection-base.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionBaseComponent": () => (/* binding */ InspectionBaseComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 60124);


class InspectionBaseComponent {
  static #_ = this.ɵfac = function InspectionBaseComponent_Factory(t) {
    return new (t || InspectionBaseComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: InspectionBaseComponent,
    selectors: [["app-inspection-base"]],
    decls: 1,
    vars: 0,
    template: function InspectionBaseComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
    encapsulation: 2
  });
}

/***/ }),

/***/ 81473:
/*!*********************************************************!*\
  !*** ./src/app/modules/inspection/inspection.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionModule": () => (/* binding */ InspectionModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var primeng_progressbar__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/progressbar */ 88395);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/badge */ 52381);
/* harmony import */ var _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/landing-page/landing-page.component */ 16564);
/* harmony import */ var _inspection_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inspection-base.component */ 98442);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _components_vehicle_inspection_vehicle_inspection_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/vehicle-inspection/vehicle-inspection.component */ 59560);
/* harmony import */ var _pages_visualDefect_main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/visualDefect/main-visual-defect/main-visual-defect.component */ 26591);
/* harmony import */ var _pages_visualDefect_sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/visualDefect/sub-visual-defect/sub-visual-defect.component */ 39481);
/* harmony import */ var _pages_visualDefect_sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/visualDefect/sub-visual-defect-comments/sub-visual-defect-comments.component */ 97226);
/* harmony import */ var _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/visualDefect/visual-defect-list/visual-defect-list.component */ 12207);
/* harmony import */ var _external_inspection_external_inspection_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./external-inspection/external-inspection.component */ 75303);
/* harmony import */ var _pages_visualDefect_popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/visualDefect/popup-defect/popup-defect.component */ 92961);
/* harmony import */ var _pages_visualDefect_confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/visualDefect/confirm-defects/confirm-defects.component */ 17767);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dialog */ 1837);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/tooltip */ 24329);
/* harmony import */ var primeng_confirmpopup__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! primeng/confirmpopup */ 82919);
/* harmony import */ var primeng_toast__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! primeng/toast */ 29129);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! primeng/button */ 76328);
/* harmony import */ var _components_delete_confirm_delete_confirm_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/delete-confirm/delete-confirm.component */ 82412);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 22560);
























const routes = [{
  path: '',
  component: _inspection_base_component__WEBPACK_IMPORTED_MODULE_1__.InspectionBaseComponent,
  children: [{
    path: 'landing-inspection',
    component: _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__.LandingPageComponent
  }, {
    path: 'vehicle-inspection',
    component: _components_vehicle_inspection_vehicle_inspection_component__WEBPACK_IMPORTED_MODULE_3__.VehicleInspectionComponent
  }, {
    path: 'external-inspection',
    component: _external_inspection_external_inspection_component__WEBPACK_IMPORTED_MODULE_8__.ExternalInspectionComponent
  }]
}];
class InspectionModule {
  static #_ = this.ɵfac = function InspectionModule_Factory(t) {
    return new (t || InspectionModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineNgModule"]({
    type: InspectionModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule.forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, primeng_progressbar__WEBPACK_IMPORTED_MODULE_16__.ProgressBarModule, primeng_badge__WEBPACK_IMPORTED_MODULE_17__.BadgeModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_18__.DialogModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_19__.TooltipModule, primeng_confirmpopup__WEBPACK_IMPORTED_MODULE_20__.ConfirmPopupModule, primeng_toast__WEBPACK_IMPORTED_MODULE_21__.ToastModule, primeng_button__WEBPACK_IMPORTED_MODULE_22__.ButtonModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵsetNgModuleScope"](InspectionModule, {
    declarations: [_inspection_base_component__WEBPACK_IMPORTED_MODULE_1__.InspectionBaseComponent, _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__.LandingPageComponent, _components_vehicle_inspection_vehicle_inspection_component__WEBPACK_IMPORTED_MODULE_3__.VehicleInspectionComponent, _pages_visualDefect_main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_4__.MainVisualDefectComponent, _pages_visualDefect_sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_5__.SubVisualDefectComponent, _pages_visualDefect_sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_6__.SubVisualDefectCommentsComponent, _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_7__.VisualDefectListComponent, _external_inspection_external_inspection_component__WEBPACK_IMPORTED_MODULE_8__.ExternalInspectionComponent, _pages_visualDefect_popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_9__.PopupDefectComponent, _pages_visualDefect_confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_10__.ConfirmDefectsComponent, _components_delete_confirm_delete_confirm_component__WEBPACK_IMPORTED_MODULE_11__.DeleteConfirmComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, primeng_progressbar__WEBPACK_IMPORTED_MODULE_16__.ProgressBarModule, primeng_badge__WEBPACK_IMPORTED_MODULE_17__.BadgeModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_18__.DialogModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_19__.TooltipModule, primeng_confirmpopup__WEBPACK_IMPORTED_MODULE_20__.ConfirmPopupModule, primeng_toast__WEBPACK_IMPORTED_MODULE_21__.ToastModule, primeng_button__WEBPACK_IMPORTED_MODULE_22__.ButtonModule]
  });
})();

/***/ }),

/***/ 17767:
/*!****************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/confirm-defects/confirm-defects.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfirmDefectsComponent": () => (/* binding */ ConfirmDefectsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);





function ConfirmDefectsComponent_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Are you sure no more defects to be added ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ConfirmDefectsComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Are you sure there are no defects ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ConfirmDefectsComponent_button_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ConfirmDefectsComponent_button_18_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r3.confirmSaveDefects());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
class ConfirmDefectsComponent {
  constructor(sharedService, visualDefectService, globalServ) {
    this.sharedService = sharedService;
    this.visualDefectService = visualDefectService;
    this.globalServ = globalServ;
    this.deletionTrigger = false;
    this.isDefect = false;
    this.reviewClick = false;
    this.saveSubDefectComments = [];
    this.saveSubDefDevice = [];
    this.formDataArray = [];
    this.deviceSkip = false;
    this.saveSubDefDeviceSkipped = [];
  }
  ngOnChanges(changes) {
    console.log(changes);
    this.sharedService.isDeleteDefCmnt$.subscribe(del => {
      this.deletionTrigger = del;
      console.log(this.deletionTrigger);
      if (this.deletionTrigger) {
        console.log('Deletion occurred, refreshing...');
        this.sharedService.defectCommentList$.subscribe(def => {
          if (def) {
            def.length > 0 ? this.isDefect = true : this.isDefect = false;
            console.log(def.length);
            console.log(this.isDefect);
          }
        });
      }
      console.log(this.isDefect);
    });
  }
  ngOnInit() {
    this.sharedService.defectCommentList$.subscribe(def => {
      if (def) {
        def.length > 0 ? this.isDefect = true : this.isDefect = false;
      }
    });
    this.sharedService.isDeviceSkip$.subscribe(dev => {
      if (dev) this.deviceSkip = dev;
    });
    this.sharedService.deviceStartRequestDto$.subscribe(response => {
      if (response) this.saveSubDefDeviceSkipped.push(response);
    });
  }
  confirmSaveDefects() {
    debugger;
    if (!this.isDefect) {
      if (!this.deviceSkip && this.saveSubDefDeviceSkipped) {
        this.sharedService.setSaveSubDefectComments(this.saveSubDefDeviceSkipped);
        this.sharedService.saveSubDefectComments$.subscribe(saveDef => {
          console.log(saveDef);
          if (saveDef) {
            this.saveSubDefectComments = saveDef;
            if (this.reviewClick) {
              this.visualDefectService.createInspectionResult(this.saveSubDefectComments).subscribe(response => {
                if (response.items) {
                  this.sharedService.setConfirmDef(true);
                  this.sharedService.resetDefCmnt();
                  this.sharedService.resetSaveDefectSrc();
                  this.isDefect = false;
                  this.sharedService.formData$.subscribe(files => {
                    this.formDataArray = files;
                  });
                  for (const file of this.formDataArray) {
                    this.globalServ.uploadAttachement(file).subscribe(response => {});
                  }
                  this.reviewClick = false;
                }
              });
            }
          }
        });
      }
    }
    if (this.isDefect) {
      if (!this.deviceSkip && this.saveSubDefDeviceSkipped) this.sharedService.setSaveSubDefectComments(this.saveSubDefDeviceSkipped);
      this.sharedService.saveSubDefectComments$.subscribe(saveDef => {
        console.log(saveDef);
        if (saveDef) {
          this.saveSubDefectComments = saveDef;
          if (this.reviewClick) {
            this.visualDefectService.createInspectionResult(this.saveSubDefectComments).subscribe(response => {
              if (response.items) {
                this.sharedService.setConfirmDef(true);
                this.sharedService.resetDefCmnt();
                this.sharedService.resetSaveDefectSrc();
                this.isDefect = false;
                this.sharedService.formData$.subscribe(files => {
                  this.formDataArray = files;
                });
                for (const file of this.formDataArray) {
                  this.globalServ.uploadAttachement(file).subscribe(response => {});
                }
                this.reviewClick = false;
              }
            });
          }
        }
      });
    } else {
      this.sharedService.setConfirmDef(true);
    }
  }
  static #_ = this.ɵfac = function ConfirmDefectsComponent_Factory(t) {
    return new (t || ConfirmDefectsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_2__.GlobalConfigService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ConfirmDefectsComponent,
    selectors: [["app-confirm-defects"]],
    inputs: {
      deletionTrigger: "deletionTrigger"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵNgOnChangesFeature"]],
    decls: 19,
    vars: 3,
    consts: [["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal2", 1, "btn", "btn-orange", 3, "click"], ["id", "confirmationModal2", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-body"], [1, "row"], [1, "col-12"], ["src", "./assets/img/red-question.svg", "width", "40px"], [4, "ngIf"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "class", "btn btn-outline-secondary border-0", "data-bs-dismiss", "modal", 3, "click", 4, "ngIf"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"]],
    template: function ConfirmDefectsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ConfirmDefectsComponent_Template_button_click_0_listener() {
          return ctx.reviewClick = true;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "Review");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 1)(3, "div", 2)(4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 5)(7, "div", 6)(8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "img", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](11, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, ConfirmDefectsComponent_div_12_Template, 2, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, ConfirmDefectsComponent_div_13_Template, 2, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](14, "br")(15, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](17, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](18, ConfirmDefectsComponent_button_18_Template, 2, 0, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isDefect);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.isDefect);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.reviewClick);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf],
    styles: ["#confirmationModal2[_ngcontent-%COMP%] {\n    font-weight: bold;\n    text-align: center;\n    font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9jb25maXJtLWRlZmVjdHMvY29uZmlybS1kZWZlY3RzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGVBQWU7QUFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyIjY29uZmlybWF0aW9uTW9kYWwyIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyMHB4O1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 26591:
/*!**********************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/main-visual-defect/main-visual-defect.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainVisualDefectComponent": () => (/* binding */ MainVisualDefectComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_utilities_enums_main_defects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/main-defects */ 54733);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../confirm-defects/confirm-defects.component */ 17767);








function MainVisualDefectComponent_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 3)(1, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MainVisualDefectComponent_div_12_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r5);
      const defect_r3 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r4.onSelectDefect(defect_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 15)(3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 18)(6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const defect_r3 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r0.getDefectIconByDefectId(defect_r3 == null ? null : defect_r3.mainDefectId), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", defect_r3 == null ? null : defect_r3.mainDefectId, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", defect_r3 == null ? null : defect_r3.defectNameEn, "");
  }
}
function MainVisualDefectComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 3)(1, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MainVisualDefectComponent_div_14_Template_a_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.onSelectDefect(ctx_r6.legalRequirement));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 19)(3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 18)(6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r1.getDefectIconByDefectId(ctx_r1.legalRequirement == null ? null : ctx_r1.legalRequirement.mainDefectId), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r1.legalRequirement == null ? null : ctx_r1.legalRequirement.mainDefectId, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.legalRequirement == null ? null : ctx_r1.legalRequirement.defectNameEn);
  }
}
function MainVisualDefectComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 3)(1, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MainVisualDefectComponent_div_15_Template_a_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.showAllComments());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 20)(3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Comments ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
}
class MainVisualDefectComponent {
  constructor(visualDefectService, sharedData) {
    this.visualDefectService = visualDefectService;
    this.sharedData = sharedData;
    this.selectedDefect = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    this.mainDefectList = [];
    this.mainDefectFilter = '';
    this.isOkComments = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    this.mainDefects = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
  }
  ngOnInit() {
    this.getMainVisualDefects();
    this.sharedData.isDeleteDefCmnt$.subscribe(def => {
      this.deletionTrigger = def;
    });
    this.sharedData.reqNo$.subscribe(req => {
      this.requestInsId = parseInt(req);
    });
  }
  getDefectIconByDefectId(defectId) {
    switch (defectId) {
      case 2100:
        return './assets/img/defects-icon/brake_system.svg';
      case 2200:
        return './assets/img/defects-icon/steering.svg';
      case 2300:
        return './assets/img/defects-icon/visibility.svg';
      case 2400:
        return './assets/img/defects-icon/lighting.svg';
      case 2500:
        return './assets/img/defects-icon/axles.svg';
      case 2600:
        return './assets/img/defects-icon/chasis.svg';
      case 2700:
        return './assets/img/defects-icon/engine.svg';
      case 2800:
        return './assets/img/defects-icon/other_equip.svg';
      case 2900:
        return './assets/img/defects-icon/environment.svg';
      case 3000:
        return './assets/img/defects-icon/public_transport.svg';
      case 3100:
        return './assets/img/defects-icon/brake_system.svg';
      case 4100:
        return './assets/img/defects-icon/water_tanker.svg';
    }
    return '';
  }
  getMainVisualDefects() {
    this.visualDefectService.getMainVisualDefects({
      requestId: this.requestInsId,
      nameEn: this.mainDefectFilter == '' ? null : this.mainDefectFilter
    }).subscribe(res => {
      this.mainDefectList = res.items;
      let legalRequirementIndex = this.mainDefectList.findIndex(x => x.mainDefectId == src_app_core_utilities_enums_main_defects__WEBPACK_IMPORTED_MODULE_0__.MainDefectEnum.LegalRequirements);
      if (legalRequirementIndex > -1) this.legalRequirement = this.mainDefectList.splice(legalRequirementIndex, 1)[0];
    });
  }
  onSelectDefect(defectId) {
    this.selectedDefect.emit(defectId);
  }
  showAllComments() {
    this.isOkComments.emit(true);
  }
  static #_ = this.ɵfac = function MainVisualDefectComponent_Factory(t) {
    return new (t || MainVisualDefectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: MainVisualDefectComponent,
    selectors: [["main-visual-defect"]],
    inputs: {
      requestId: "requestId"
    },
    outputs: {
      selectedDefect: "selectedDefect",
      isOkComments: "isOkComments",
      mainDefects: "mainDefects"
    },
    decls: 19,
    vars: 5,
    consts: [[1, "vd-content-hld"], [1, "vd-title"], [1, "row"], [1, "col-lg-4"], [1, "search-fld"], [1, "bi", "bi-search"], ["type", "text", "placeholder", "Search Main Visual Defects", "value", "", 1, "form-control", 2, "padding-left", "45px", 3, "ngModel", "ngModelChange"], [1, "col-12"], [1, "row", 2, "--bs-gutter-y", "1.5rem"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], [1, "row", 2, "--bs-gutter-y", "0.75rem", "margin-top", "1.5rem", "margin-bottom", "1.5rem"], ["class", "col-lg-4", 4, "ngIf"], ["id", "btnConfirm", 1, "col-12", "end-btns"], [3, "deletionTrigger"], [1, "card-link", 3, "click"], [1, "vd-card", "red-card"], [1, "vd-icon"], [3, "src"], [1, "vd-card-title"], [1, "vd-card", "yellow-card"], [1, "vd-card", "green-card"], ["src", "./assets/img/defects-icon/comments.svg"]],
    template: function MainVisualDefectComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "div", 0)(2, "div", 1)(3, "div", 2)(4, "div", 3)(5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "i", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function MainVisualDefectComponent_Template_input_ngModelChange_7_listener($event) {
          return ctx.mainDefectFilter = $event;
        })("ngModelChange", function MainVisualDefectComponent_Template_input_ngModelChange_7_listener() {
          return ctx.getMainVisualDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 7)(9, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, " Visual Defect Main Category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](12, MainVisualDefectComponent_div_12_Template, 10, 3, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, MainVisualDefectComponent_div_14_Template, 10, 3, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, MainVisualDefectComponent_div_15_Template, 9, 0, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 2)(17, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](18, "app-confirm-defects", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.mainDefectFilter);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.mainDefectList);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.legalRequirement != undefined && ctx.legalRequirement.defectNameEn.includes(ctx.mainDefectFilter) || "3100".includes(ctx.mainDefectFilter));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", "Comments".toLowerCase().includes(ctx.mainDefectFilter.toLowerCase()));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("deletionTrigger", ctx.deletionTrigger);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_3__.ConfirmDefectsComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 92961:
/*!**********************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/popup-defect/popup-defect.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PopupDefectComponent": () => (/* binding */ PopupDefectComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 59295);
/* harmony import */ var src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-comments-type */ 53104);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/tooltip */ 24329);












function PopupDefectComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx_r0.errorMessage, " ");
  }
}
function PopupDefectComponent_div_13_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 28)(1, "div", 29)(2, "div", 30)(3, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](4, "img", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "input", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_13_div_1_Template_input_change_5_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r11);
      const sd_r8 = restoredCtx.$implicit;
      const i_r9 = restoredCtx.index;
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r10.selectedDefCmnt(sd_r8, i_r9, 3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "label", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "a", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PopupDefectComponent_div_13_div_1_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r11);
      const i_r9 = restoredCtx.index;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r12.deleteDefectComment(i_r9, ctx_r12.savedDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](9, "i", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "a", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](11, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const sd_r8 = ctx.$implicit;
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("src", ctx_r7.getSubDefectCommentIconByDefectId(sd_r8.commentType), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsanitizeUrl"])("title", ctx_r7.mapEvaluationName(sd_r8.commentType));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("id", sd_r8.defCommentId)("value", sd_r8.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵclassProp"]("shrink-text", (sd_r8 == null ? null : sd_r8.descriptionEn) && (sd_r8 == null ? null : sd_r8.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("for", sd_r8.defCommentId)("pTooltip", (sd_r8 == null ? null : sd_r8.subDefectDescriptionEn) + "-" + sd_r8.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate2"](" ", sd_r8.subDefectDescriptionEn, " - ", sd_r8.descriptionEn, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵstyleProp"]("pointer-events", sd_r8.defectSource == 2 ? "none" : "auto");
  }
}
function PopupDefectComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, PopupDefectComponent_div_13_div_1_Template, 12, 12, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r1.selectedDefectsPrevList);
  }
}
function PopupDefectComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 28)(1, "div", 29)(2, "div", 30)(3, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_14_Template_input_change_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r16);
      const df_r13 = restoredCtx.$implicit;
      const i_r14 = restoredCtx.index;
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r15.selectedDefCmnt(df_r13.defectCmnt, i_r14, 2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "label", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "a", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PopupDefectComponent_div_14_Template_a_click_6_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r16);
      const i_r14 = restoredCtx.index;
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r17.deleteDefectComment(i_r14, ctx_r17.prevDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](7, "i", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "a", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](9, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const df_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("id", df_r13 == null ? null : df_r13.defectCmnt.defCommentId)("value", df_r13 == null ? null : df_r13.defectCmnt.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵclassProp"]("shrink-text", (df_r13 == null ? null : df_r13.descriptionEn) && (df_r13 == null ? null : df_r13.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("for", df_r13 == null ? null : df_r13.defectCmnt.defCommentId)("pTooltip", (df_r13 == null ? null : df_r13.defectCmnt.subDefectDescriptionEn) + "-" + df_r13.defectCmnt.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate2"](" ", df_r13 == null ? null : df_r13.defectCmnt.subDefectDescriptionEn, " - ", df_r13 == null ? null : df_r13.defectCmnt.descriptionEn, "");
  }
}
function PopupDefectComponent_span_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function PopupDefectComponent_div_26_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "input", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PopupDefectComponent_div_26_ng_container_1_ng_container_1_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r23.selectedEvaluation = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2).$implicit;
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("id", ev_r18.lkCodeValue)("value", ev_r18.lkValueEname)("ngModel", ctx_r21.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("for", ev_r18.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ev_r18.lkValueEname, " ");
  }
}
function PopupDefectComponent_div_26_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "input", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PopupDefectComponent_div_26_ng_container_1_ng_container_2_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r27);
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r26.selectedEvaluation = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2).$implicit;
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("id", ev_r18.lkCodeValue)("value", ev_r18.lkValueEname)("ngModel", ctx_r22.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵattribute"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("for", ev_r18.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ev_r18.lkValueEname, " ");
  }
}
function PopupDefectComponent_div_26_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, PopupDefectComponent_div_26_ng_container_1_ng_container_1_Template, 4, 5, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](2, PopupDefectComponent_div_26_ng_container_1_ng_container_2_Template, 4, 6, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]().$implicit;
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx_r20.isReadOnlyEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r20.isReadOnlyEvaluation && ctx_r20.selectedEvaluation == ev_r18.lkValueEname);
  }
}
function PopupDefectComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, PopupDefectComponent_div_26_ng_container_1_Template, 3, 2, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ev_r18.lkCodeValue != 1);
  }
}
function PopupDefectComponent_div_27_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r42);
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r41.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r30.selectedDefLocArray == null ? null : ctx_r30.selectedDefLocArray.includes("FC"))("disabled", ctx_r30.disableDef);
  }
}
function PopupDefectComponent_div_27_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r44);
      const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r43.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r31.selectedDefLocArray == null ? null : ctx_r31.selectedDefLocArray.includes("FL"))("disabled", ctx_r31.disableDef);
  }
}
function PopupDefectComponent_div_27_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r46 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r46);
      const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r45.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r32.selectedDefLocArray == null ? null : ctx_r32.selectedDefLocArray.includes("FR"))("disabled", ctx_r32.disableDef);
  }
}
function PopupDefectComponent_div_27_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r48);
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r47.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r33.selectedDefLocArray == null ? null : ctx_r33.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r33.disableDef);
  }
}
function PopupDefectComponent_div_27_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r50);
      const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r49.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r34.selectedDefLocArray == null ? null : ctx_r34.selectedDefLocArray.includes("CL"))("disabled", ctx_r34.disableDef);
  }
}
function PopupDefectComponent_div_27_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r52);
      const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r51.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r35.selectedDefLocArray == null ? null : ctx_r35.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r35.disableDef);
  }
}
function PopupDefectComponent_div_27_div_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r54 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_19_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r54);
      const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r53.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r36.selectedDefLocArray == null ? null : ctx_r36.selectedDefLocArray.includes("CC"))("disabled", ctx_r36.disableDef);
  }
}
function PopupDefectComponent_div_27_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r56 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r56);
      const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r55.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r37.selectedDefLocArray == null ? null : ctx_r37.selectedDefLocArray.includes("CR"))("disabled", ctx_r37.disableDef);
  }
}
function PopupDefectComponent_div_27_div_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r58 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_25_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r58);
      const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r57.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r38.selectedDefLocArray == null ? null : ctx_r38.selectedDefLocArray.includes("RC"))("disabled", ctx_r38.disableDef);
  }
}
function PopupDefectComponent_div_27_div_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r60 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_27_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r60);
      const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r59.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r39.selectedDefLocArray == null ? null : ctx_r39.selectedDefLocArray.includes("RL"))("disabled", ctx_r39.disableDef);
  }
}
function PopupDefectComponent_div_27_div_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r62 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_29_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r62);
      const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r61.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r40.selectedDefLocArray == null ? null : ctx_r40.selectedDefLocArray.includes("RR"))("disabled", ctx_r40.disableDef);
  }
}
function PopupDefectComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 7)(1, "div", 44)(2, "div", 45)(3, "div", 46)(4, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, PopupDefectComponent_div_27_div_5_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](7, PopupDefectComponent_div_27_div_7_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](9, PopupDefectComponent_div_27_div_9_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "div", 51)(11, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](12, PopupDefectComponent_div_27_div_12_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](14, PopupDefectComponent_div_27_div_14_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](16, PopupDefectComponent_div_27_div_16_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "div", 55)(18, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](19, PopupDefectComponent_div_27_div_19_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](20, "div", 57)(21, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](22, PopupDefectComponent_div_27_div_22_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](23, "div", 58)(24, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](25, PopupDefectComponent_div_27_div_25_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](26, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](27, PopupDefectComponent_div_27_div_27_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](29, PopupDefectComponent_div_27_div_29_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](30, "img", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.fc);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.fl);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.fr);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.axle1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.cl);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.axle2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.cc);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.cr);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.rc);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.rl);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.rr);
  }
}
function PopupDefectComponent_div_28_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r82);
      const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r81.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r63.selectedDefLocArray == null ? null : ctx_r63.selectedDefLocArray.includes("FC"))("disabled", ctx_r63.disableDef);
  }
}
function PopupDefectComponent_div_28_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r83.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r64 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r64.selectedDefLocArray == null ? null : ctx_r64.selectedDefLocArray.includes("FL"))("disabled", ctx_r64.disableDef);
  }
}
function PopupDefectComponent_div_28_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r86);
      const ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r85.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r65.selectedDefLocArray == null ? null : ctx_r65.selectedDefLocArray.includes("FR"))("disabled", ctx_r65.disableDef);
  }
}
function PopupDefectComponent_div_28_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r88);
      const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r87.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r66.selectedDefLocArray == null ? null : ctx_r66.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r66.disableDef);
  }
}
function PopupDefectComponent_div_28_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r90 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r90);
      const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r89.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r67.selectedDefLocArray == null ? null : ctx_r67.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r67.disableDef);
  }
}
function PopupDefectComponent_div_28_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r92);
      const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r91.updateSelectedValues(4, $event, "axle3"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 3 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r68.selectedDefLocArray == null ? null : ctx_r68.selectedDefLocArray.includes("AXLE3"))("disabled", ctx_r68.disableDef);
  }
}
function PopupDefectComponent_div_28_div_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r94 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_18_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r94);
      const ctx_r93 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r93.updateSelectedValues(8, $event, "axle4"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 4 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r69.selectedDefLocArray == null ? null : ctx_r69.selectedDefLocArray.includes("AXLE4"))("disabled", ctx_r69.disableDef);
  }
}
function PopupDefectComponent_div_28_div_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r96 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_20_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r96);
      const ctx_r95 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r95.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 108);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r70.selectedDefLocArray == null ? null : ctx_r70.selectedDefLocArray.includes("CL"))("disabled", ctx_r70.disableDef);
  }
}
function PopupDefectComponent_div_28_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r98 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r98);
      const ctx_r97 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r97.updateSelectedValues(16, $event, "axle5"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 5 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r71.selectedDefLocArray == null ? null : ctx_r71.selectedDefLocArray.includes("AXLE5"))("disabled", ctx_r71.disableDef);
  }
}
function PopupDefectComponent_div_28_div_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r100 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_24_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r100);
      const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r99.updateSelectedValues(32, $event, "axle6"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 6 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r72.selectedDefLocArray == null ? null : ctx_r72.selectedDefLocArray.includes("AXLE6"))("disabled", ctx_r72.disableDef);
  }
}
function PopupDefectComponent_div_28_div_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r102 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_26_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r102);
      const ctx_r101 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r101.updateSelectedValues(64, $event, "axle7"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 7 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r73.selectedDefLocArray == null ? null : ctx_r73.selectedDefLocArray.includes("AXLE7"))("disabled", ctx_r73.disableDef);
  }
}
function PopupDefectComponent_div_28_div_28_Template(rf, ctx) {
  if (rf & 1) {
    const _r104 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_28_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r104);
      const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r103.updateSelectedValues(128, $event, "axle8"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 8 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r74.selectedDefLocArray == null ? null : ctx_r74.selectedDefLocArray.includes("AXLE8"))("disabled", ctx_r74.disableDef);
  }
}
function PopupDefectComponent_div_28_div_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r106 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 115);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_30_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r106);
      const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r105.updateSelectedValues(256, $event, "axle9"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 116);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " 9 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r75.selectedDefLocArray == null ? null : ctx_r75.selectedDefLocArray.includes("AXLE9"))("disabled", ctx_r75.disableDef);
  }
}
function PopupDefectComponent_div_28_div_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r108 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_33_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r108);
      const ctx_r107 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r107.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r76.selectedDefLocArray == null ? null : ctx_r76.selectedDefLocArray.includes("CC"))("disabled", ctx_r76.disableDef);
  }
}
function PopupDefectComponent_div_28_div_36_Template(rf, ctx) {
  if (rf & 1) {
    const _r110 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_36_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r110);
      const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r109.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r77.selectedDefLocArray == null ? null : ctx_r77.selectedDefLocArray.includes("CR"))("disabled", ctx_r77.disableDef);
  }
}
function PopupDefectComponent_div_28_div_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r112 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_39_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r112);
      const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r111.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r78.selectedDefLocArray == null ? null : ctx_r78.selectedDefLocArray.includes("RC"))("disabled", ctx_r78.disableDef);
  }
}
function PopupDefectComponent_div_28_div_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r114 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_41_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r114);
      const ctx_r113 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r113.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r79.selectedDefLocArray == null ? null : ctx_r79.selectedDefLocArray.includes("RL"))("disabled", ctx_r79.disableDef);
  }
}
function PopupDefectComponent_div_28_div_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r116 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 60)(1, "input", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_43_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r116);
      const ctx_r115 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r115.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "label", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx_r80.selectedDefLocArray == null ? null : ctx_r80.selectedDefLocArray.includes("RR"))("disabled", ctx_r80.disableDef);
  }
}
function PopupDefectComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 7)(1, "div", 44)(2, "div", 45)(3, "div", 46)(4, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, PopupDefectComponent_div_28_div_5_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](7, PopupDefectComponent_div_28_div_7_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](9, PopupDefectComponent_div_28_div_9_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "div", 82)(11, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](12, PopupDefectComponent_div_28_div_12_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "div", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](14, PopupDefectComponent_div_28_div_14_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "div", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](16, PopupDefectComponent_div_28_div_16_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "div", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](18, PopupDefectComponent_div_28_div_18_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](19, "div", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](20, PopupDefectComponent_div_28_div_20_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](21, "div", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](22, PopupDefectComponent_div_28_div_22_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](23, "div", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](24, PopupDefectComponent_div_28_div_24_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](25, "div", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](26, PopupDefectComponent_div_28_div_26_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](28, PopupDefectComponent_div_28_div_28_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "div", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](30, PopupDefectComponent_div_28_div_30_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "div", 55)(32, "div", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](33, PopupDefectComponent_div_28_div_33_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "div", 94)(35, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](36, PopupDefectComponent_div_28_div_36_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](37, "div", 58)(38, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](39, PopupDefectComponent_div_28_div_39_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](41, PopupDefectComponent_div_28_div_41_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](43, PopupDefectComponent_div_28_div_43_Template, 4, 2, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](44, "img", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.fc);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.fl);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.fr);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 1 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle1));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 2 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle2));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 3 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle3));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 4 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle4));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.cl);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 5 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle5));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 6 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle6));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 7 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle7));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 8 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle8));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 9 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle9));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.cc);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.cr);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.rc);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.rl);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.rr);
  }
}
class PopupDefectComponent {
  constructor(sharedData, lookupServ, el, renderer, inspectionService, visualService) {
    this.sharedData = sharedData;
    this.lookupServ = lookupServ;
    this.el = el;
    this.renderer = renderer;
    this.inspectionService = inspectionService;
    this.visualService = visualService;
    this.deleteDefectCommentEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    this.onClickFileEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_6__.EventEmitter();
    this.checkboxStates = {};
    this.prevSavedDefects = [];
    this.selectedDefLocArray = [];
    this.showDefectVehicle = false;
    this.showDefectTruck = false;
    this.evaluationList = [];
    this.prevDef = 2;
    this.savedDef = 3;
  }
  ngOnInit() {
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.evaluationList).subscribe(response => {
      this.evaluationList = response.items;
      // Filter out evaluation ok/comment
      this.evaluationList = this.evaluationList.filter(item => item.lkCodeValue !== 2);
    });
    // get if vehicle is heavy or light to display popup
    this.sharedData.vehicleType$.subscribe(categType => {
      this.categoryType = categType;
      this.categoryType == 1 ? this.showDefectVehicle = true : this.showDefectTruck = true;
      console.log(this.categoryType);
    });
    this.sharedData.insRequestId$.subscribe(insReqID => {
      this.insRequestId = insReqID;
    });
    // get nb axles to display heavy equipment axles
    this.sharedData.nbAxles$.subscribe(axles => {
      if (axles == null) {
        this.nbAxles = 9;
      } else {
        this.nbAxles = axles;
      }
    });
    this.sharedData.selectedDefectsPrevList$.subscribe(defects => {
      this.selectedDefectsPrevList = defects;
    });
    this.sharedData.defectCommentList$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.take)(1)).subscribe(def => {
      this.prevSavedDefects = def;
      console.log(this.prevSavedDefects);
    });
    console.log(this.selectedDefectsPrevList[0]);
    if (this.prevSavedDefects[0] != undefined) this.selectedDefCmnt(this.prevSavedDefects[0].defectCmnt, 0, this.prevDef);
  }
  selectedDefCmnt(defectCmnt, index, defSource) {
    console.log(defectCmnt);
    this.isRemarkRequired = defectCmnt.isRemarkRequired;
    console.log(defectCmnt);
    this.selectedDefItemLocation = defectCmnt.defectLocation;
    console.log(this.selectedDefItemLocation);
    if (defSource == 1) {
      this.disableDef = false;
      this.remarkCmnt = this.saveSubDefectComments[index]?.remarks;
      this.selectedEvaluation = this.mapEvaluationName(this.saveSubDefectComments[index]?.evalutionId);
      if (this.selectedEvaluation == "Comment") {
        this.selectedEvaluation = "OK/Comment";
      }
      this.selectedEvaluationCode = this.saveSubDefectComments[index]?.evalutionId;
      this.selectedDefLocArray = this.saveSubDefectComments[index] ? this.saveSubDefectComments[index].locations : [];
    }
    if (defSource == 2) {
      this.disableDef = false;
      this.sharedData.saveSubDefectComments$.subscribe(savedef => {
        this.saveSubDefectComments = savedef;
        this.selectedDefLocArray = savedef[index] ? savedef[index].locations : [];
        this.remarkCmnt = savedef[index] ? savedef[index].remarks : null;
        this.selectedEvaluation = this.mapEvaluationName(savedef[index] ? savedef[index].evalutionId : null);
        if (this.selectedEvaluation == "Comment") {
          this.selectedEvaluation = "OK/Comment";
        }
        this.selectedEvaluationCode = savedef[index] ? savedef[index].evalutionId : null;
      });
    }
    if (defSource == 3) {
      this.disableDef = true;
      this.remarkCmnt = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].remarks : null;
      this.selectedEvaluation = this.mapEvaluationName(this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null);
      if (this.selectedEvaluation == "Comment") {
        this.selectedEvaluation = "OK/Comment";
      }
      this.selectedEvaluationCode = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null;
      this.selectedDefectValues = this.selectedDefectsPrevList[index].locationValue ? this.selectedDefectsPrevList[index].locationValue : 0;
      this.selectedDefLocArray = this.selectedDefectsPrevList[index].selectedDefectLocation;
      console.log(this.selectedDefectsPrevList[index]);
    }
    console.log(this.selectedDefLocArray.includes('AXLE1'));
    console.log(this.selectedDefLocArray);
    //this.resetCheckboxes();
    //  this.selectedDefItemLocation = defectCmnt.defectLocation;
    this.defectCommentIndex = index;
    //this.isCheckboxDisable = defectCmnt.locationValue ? true : false;
    this.isReadOnlyEvaluation = true;
  }
  updateSelectedValues(value, event, loc) {
    const isChecked = event.target.checked;
    if (isChecked) {
      this.selectedDefectValues += value;
      this.selectedDefLocArray.push(loc.toUpperCase());
      this.checkDefectLocation(loc);
      this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray;
      this.sharedData.setSaveSubDefectComments(this.saveSubDefectComments);
    } else {
      this.selectedDefectValues -= value;
      const locIndex = this.selectedDefLocArray.indexOf(loc.toUpperCase());
      if (locIndex !== -1) {
        this.selectedDefLocArray.splice(locIndex, 1);
      }
    }
  }
  updateRemark() {
    this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt : this.selectedDefectsPrevList[this.defectCommentIndex].remarks = this.remarkCmnt;
    //this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt;
  }

  checkDefectLocation(loc) {
    const defectLoc = this.selectedSubDefectComments[this.defectCommentIndex].defectLocation;
    switch (loc) {
      case 'fl':
        defectLoc.fl = true;
        break;
      case 'fc':
        defectLoc.fc = true;
        break;
      case 'fr':
        defectLoc.fr = true;
        break;
      case 'cl':
        defectLoc.cl = true;
        break;
      case 'cc':
        defectLoc.cc = true;
        break;
      case 'cr':
        defectLoc.cr = true;
        break;
      case 'axle1':
        defectLoc.axle1 = true;
        break;
      case 'axle2':
        defectLoc.axle2 = true;
        break;
      case 'axle3':
        defectLoc.axle3 = true;
        break;
      case 'axle4':
        defectLoc.axle4 = true;
        break;
      case 'axle5':
        defectLoc.axle5 = true;
        break;
      case 'axle6':
        defectLoc.axle6 = true;
        break;
      case 'axle7':
        defectLoc.axle7 = true;
        break;
      case 'axle8':
        defectLoc.axle8 = true;
        break;
      case 'axle9':
        defectLoc.axle9 = true;
        break;
      case 'rl':
        defectLoc.rl = true;
        break;
      case 'rr':
        defectLoc.rr = true;
        break;
      case 'rc':
        defectLoc.rc = true;
        break;
      default:
        break;
    }
    this.selectedDefItemLocation = defectLoc;
  }
  mapEvaluationName(evId) {
    return evId == 3 ? "Major" : evId == 4 ? "Minor" : evId == 1 ? "Inspector Decides" : "Comment";
  }
  getSubDefectCommentIconByDefectId(defectCommentType) {
    switch (defectCommentType) {
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.InspectorDecides:
        return './assets/img/defects-icon/status_info.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.OKComment:
        return './assets/img/defects-icon/status_comment.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.Major:
        return './assets/img/defects-icon/status_up.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.Minor:
        return './assets/img/defects-icon/status_down.svg';
    }
    return '';
  }
  resetCheckboxes() {
    for (const key in this.checkboxStates) {
      if (this.checkboxStates.hasOwnProperty(key)) {
        this.checkboxStates[key] = false;
      }
    }
  }
  checkDeleteDef(index, sourcenb) {
    this.defectDelIndex = index;
    //this.confirmEval = 
    this.delSource = sourcenb;
  }
  deleteDefectComment(index, source) {
    this.remarkCmnt = '';
    if (source == this.savedDef) {
      this.sharedData.deleteDefectCmnt(this.selectedDefectsPrevList[index].defCommentId);
      const deleteDef = {
        inspectionReqId: this.insRequestId,
        defectsCommentId: this.selectedDefectsPrevList[index].defCommentId
      };
      console.log(deleteDef);
      this.inspectionService.deleteInspectionDefect(deleteDef).subscribe(response => {
        this.selectedDefectsPrevList.splice(index, 1);
      });
    }
    if (source == this.prevDef) {
      this.sharedData.deleteSaveSubDefectComment(this.prevSavedDefects[index].defectCmnt.defCommentId);
      this.prevSavedDefects.splice(index, 1);
      this.sharedData.setDeleteDefCmnt();
    }
    if (this.selectedSubDefectComments?.length + this.prevSavedDefects?.length + this.selectedDefectsPrevList?.length == 0) {
      this.closeVehicleImage();
    }
  }
  onFileUploadModalHidden() {
    console.log("file hidden");
    const fileUploadModal = this.el.nativeElement.querySelector('#fileUploadModal');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
  }
  closeVehicleImage() {
    const fileUploadModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
  }
  onFileUploadData(fInfo) {
    console.log("test");
    //  this.onFileUploadModalHidden();
  }

  mapSubDefect(subId) {
    let subName;
    // this.visualService.getSubVisualDefects({ subDefectId: subId }).subscribe(
    //   (response) => {
    //     subName = response.items.descriptionEn;
    //   }
    // );
    return subName;
  }
  static #_ = this.ɵfac = function PopupDefectComponent_Factory(t) {
    return new (t || PopupDefectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_4__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_5__.VisualDefectService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: PopupDefectComponent,
    selectors: [["app-popup-defect"]],
    inputs: {
      selectedDefectsPrevList: "selectedDefectsPrevList",
      errorMessage: "errorMessage"
    },
    outputs: {
      deleteDefectCommentEvent: "deleteDefectCommentEvent",
      onClickFileEvent: "onClickFileEvent"
    },
    decls: 52,
    vars: 10,
    consts: [[1, "modal-header"], [1, "df-counter"], [1, "counter-btn"], ["class", "error-message", 4, "ngIf"], [1, "modal-body"], [1, "pop-content"], [1, "row"], [1, "col-lg-6"], [1, "row", "form-fields"], [4, "ngIf"], ["class", "col-lg-12 mb-2", 4, "ngFor", "ngForOf"], [1, "col-12"], [1, "st-label"], [1, "txtarea", "w-100", 3, "ngModel", "disabled", "ngModelChange", "change"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["class", "col-lg-6", 4, "ngIf"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-orange"], ["id", "confirmationModalDel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabeldel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"], [1, "error-message"], [1, "col-lg-12", "mb-2"], [1, "outline-radio-container"], [1, "outline-radio", "d-flex", "align-items-center"], [1, "defect-evaluation-classification-coloir"], ["data-toggle", "tooltip", "data-placement", "top", 2, "height", "33px", 3, "src", "title"], ["type", "radio", "name", "sd.defCommentCode", 3, "id", "value", "change"], ["id", "labelPop", "tooltipPosition", "top", 3, "for", "pTooltip"], [3, "click"], [1, "bi", "bi-trash-fill", "poptrash"], ["data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal"], [1, "bi", "bi-paperclip"], ["type", "radio", "name", "df?.defCommentCode", 3, "id", "value", "change"], ["tooltipPosition", "top", 3, "for", "pTooltip"], [1, "btn-radio"], ["type", "radio", "name", "ev.lkValueEname", 3, "id", "value", "ngModel", "ngModelChange"], [3, "for"], [1, "car-img-wrap"], [1, "car-img-hold"], [1, "top-chkboxes"], [1, "fc", "chkbx"], ["class", "form-check", 4, "ngIf"], [1, "fl", "chkbx"], [1, "fr", "chkbx"], [1, "left-chkboxes"], [1, "b1", "chkbx"], [1, "cl", "chkbx"], [1, "b2", "chkbx"], [1, "center-chkboxes"], [1, "c", "chkbx"], [1, "right-chkboxes"], [1, "bottom-chkboxes"], ["src", " ./assets/img/car_outline.svg", 1, "car-img"], [1, "form-check"], ["type", "checkbox", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fc", 1, "form-check-label"], ["type", "checkbox", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fl", 1, "form-check-label"], ["type", "checkbox", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b1", 1, "form-check-label"], ["type", "checkbox", "id", "cl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b2", 1, "form-check-label"], ["type", "checkbox", "id", "c", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "c", 1, "form-check-label"], ["type", "checkbox", "id", "cr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cr", 1, "form-check-label"], ["type", "checkbox", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rc", 1, "form-check-label"], ["type", "checkbox", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], [1, "truck-left-chkboxes"], [1, "t1", "chkbx"], [1, "t2", "chkbx"], [1, "t3", "chkbx"], [1, "t4", "chkbx"], [1, "tcl", "chkbx"], [1, "t5", "chkbx"], [1, "t6", "chkbx"], [1, "t7", "chkbx"], [1, "t8", "chkbx"], [1, "t9", "chkbx"], [1, "c-truck", "chkbx"], [1, "truck-right-chkboxes"], [1, "tcr", "chkbx"], ["src", "./assets/img/truck-outline.svg", 1, "car-img"], ["type", "checkbox", "value", "", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t1", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t2", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t3", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t3", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t4", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t4", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t5", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t6", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t7", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t7", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t8", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t8", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t9", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t9", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rr", 1, "form-check-label"]],
    template: function PopupDefectComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " Defects ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, PopupDefectComponent_div_6_Template, 2, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "div", 8)(12, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](13, PopupDefectComponent_div_13_Template, 2, 1, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](14, PopupDefectComponent_div_14_Template, 10, 8, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "div", 6)(16, "div", 11)(17, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](18, " Remarks ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](19, PopupDefectComponent_span_19_Template, 2, 0, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](20, "textarea", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function PopupDefectComponent_Template_textarea_ngModelChange_20_listener($event) {
          return ctx.remarkCmnt = $event;
        })("change", function PopupDefectComponent_Template_textarea_change_20_listener() {
          return ctx.updateRemark();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](21, "div", 6)(22, "div", 11)(23, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](24, "Evaluation");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](25, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](26, PopupDefectComponent_div_26_Template, 2, 1, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](27, PopupDefectComponent_div_27_Template, 31, 11, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](28, PopupDefectComponent_div_28_Template, 45, 18, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "div", 16)(30, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](31, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](33, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "div", 19)(35, "div", 20)(36, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](37, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](38, "div", 4)(39, "div", 6)(40, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](41, "img", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](43, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45, " Are you sure you want to delete this defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](46, "br")(47, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](49, "img", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](50, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function PopupDefectComponent_Template_button_click_50_listener() {
          return ctx.deleteDefectComment(ctx.defectDelIndex, ctx.delSource);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](51, "img", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", (ctx.selectedSubDefectComments == null ? null : ctx.selectedSubDefectComments.length) + (ctx.prevSavedDefects == null ? null : ctx.prevSavedDefects.length) + (ctx.selectedDefectsPrevList == null ? null : ctx.selectedDefectsPrevList.length), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.errorMessage);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectsPrevList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.prevSavedDefects);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.isRemarkRequired);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.remarkCmnt)("disabled", ctx.disableDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.evaluationList.slice().reverse());
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.showDefectVehicle);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.showDefectTruck && !ctx.showDefectVehicle);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgModel, primeng_tooltip__WEBPACK_IMPORTED_MODULE_10__.Tooltip],
    styles: ["#fileUploadModal[_ngcontent-%COMP%] {\n    z-index: 2000;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9wb3B1cC1kZWZlY3QvcG9wdXAtZGVmZWN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0FBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiI2ZpbGVVcGxvYWRNb2RhbCB7XG4gICAgei1pbmRleDogMjAwMDtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 97226:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/sub-visual-defect-comments/sub-visual-defect-comments.component.ts ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubVisualDefectCommentsComponent": () => (/* binding */ SubVisualDefectCommentsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_utilities_enums_defect_comments_sort_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-comments-sort-type */ 84187);
/* harmony import */ var src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-comments-type */ 53104);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_models_visual_defects_save_sub_defects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/visual-defects/save-sub-defects */ 46587);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 59295);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/file.service */ 75349);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../shared/file-uploads/file-uploads.component */ 19465);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/tooltip */ 24329);
/* harmony import */ var _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../confirm-defects/confirm-defects.component */ 17767);



















function SubVisualDefectCommentsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 4)(1, "div", 5)(2, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "a", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_11_Template_a_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r10.navigateBackToSubDefects());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](5, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6, " Change Sub Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ctx_r0.selectedSubDefect.descriptionEn, " ");
  }
}
const _c0 = function (a0) {
  return {
    "lightblue-card-selected": a0
  };
};
const _c1 = function (a0) {
  return {
    "lightblue-card": a0
  };
};
function SubVisualDefectCommentsComponent_div_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 14)(1, "a", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_44_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r15);
      const subDefectComment_r12 = restoredCtx.$implicit;
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r14.onSelectSubDefectComment(subDefectComment_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](3, "img", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 67)(5, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const subDefectComment_r12 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("pointer-events", ctx_r1.isDefectCommentPresent(subDefectComment_r12) ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](8, _c0, subDefectComment_r12.selected))("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](10, _c1, !subDefectComment_r12.selected));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx_r1.getSubDefectCommentIconByDefectId(subDefectComment_r12.commentType), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"])("title", ctx_r1.mapEvaluationName(subDefectComment_r12.commentType));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", subDefectComment_r12.defCommentCode, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", subDefectComment_r12.descriptionEn, " ");
  }
}
function SubVisualDefectCommentsComponent_div_54_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ctx_r16.errorMessage, " ");
  }
}
function SubVisualDefectCommentsComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 10)(1, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, " Defects ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, SubVisualDefectCommentsComponent_div_54_div_5_Template, 2, 1, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", (ctx_r2.selectedSubDefectComments == null ? null : ctx_r2.selectedSubDefectComments.length) + (ctx_r2.prevSavedDefects == null ? null : ctx_r2.prevSavedDefects.length) + (ctx_r2.selectedDefectsPrevList == null ? null : ctx_r2.selectedDefectsPrevList.length), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r2.errorMessage);
  }
}
function SubVisualDefectCommentsComponent_div_55_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ctx_r17.errorMessage, " ");
  }
}
function SubVisualDefectCommentsComponent_div_55_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 10)(1, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, " Defect ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, SubVisualDefectCommentsComponent_div_55_div_3_Template, 2, 1, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r3.errorMessage);
  }
}
function SubVisualDefectCommentsComponent_div_60_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div")(1, "div", 72)(2, "div", 73)(3, "div", 74)(4, "input", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_1_Template_input_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r21);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r20.selectedSubDefCmnt = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "a", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_1_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r21);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r22.deleteDefectComment(ctx_r22.selectedSubDefectComments.length - 1, ctx_r22.currentDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](8, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_1_Template_a_click_9_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r21);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r23.onClickFile(ctx_r23.selectedSubDefectComments[ctx_r23.selectedSubDefectComments.length - 1] == null ? null : ctx_r23.selectedSubDefectComments[ctx_r23.selectedSubDefectComments.length - 1].defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](10, "span", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].defCommentId)("value", ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].descriptionEn)("ngModel", ctx_r18.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("pTooltip", ctx_r18.selectedSubDefect.descriptionEn + "-" + (ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].descriptionEn))("for", ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate2"](" ", ctx_r18.selectedSubDefect.descriptionEn, " - ", ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].descriptionEn, "");
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72)(1, "div", 73)(2, "div", 74)(3, "div", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "img", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_input_ngModelChange_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r30.selectedSubDefCmnt = $event);
    })("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_input_ngModelChange_5_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const sd_r28 = restoredCtx.$implicit;
      const i_r29 = restoredCtx.index;
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r32.selectedDefCmnt(sd_r28, i_r29, 3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "label", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const i_r29 = restoredCtx.index;
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r33.checkDeleteDef(i_r29, ctx_r33.savedDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_a_click_10_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const sd_r28 = restoredCtx.$implicit;
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r34.onClickFile(sd_r28.defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "span", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const sd_r28 = ctx.$implicit;
    const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx_r27.getSubDefectCommentIconByDefectId(sd_r28.commentType), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"])("title", ctx_r27.mapEvaluationName(sd_r28.commentType));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", sd_r28.defCommentId)("value", sd_r28.descriptionEn)("ngModel", ctx_r27.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (sd_r28 == null ? null : sd_r28.descriptionEn) && (sd_r28 == null ? null : sd_r28.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", sd_r28.defCommentId)("pTooltip", (sd_r28 == null ? null : sd_r28.subDefectDescriptionEn) + "-" + sd_r28.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate2"](" ", sd_r28 == null ? null : sd_r28.subDefectDescriptionEn, " - ", sd_r28.descriptionEn, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("pointer-events", sd_r28.defectSource == 2 ? "none" : "auto");
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template, 12, 13, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r24.selectedDefectsPrevList);
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72)(1, "div", 73)(2, "div", 74)(3, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_input_ngModelChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r37.selectedSubDefCmnt = $event);
    })("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_input_ngModelChange_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const df_r35 = restoredCtx.$implicit;
      const i_r36 = restoredCtx.index;
      const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r39.selectedDefCmnt(df_r35.defectCmnt, i_r36, 2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "label", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "a", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_a_click_6_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const i_r36 = restoredCtx.index;
      const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r40.checkDeleteDef(i_r36, ctx_r40.prevDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](7, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const df_r35 = restoredCtx.$implicit;
      const i_r36 = restoredCtx.index;
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r41.onClickFile(df_r35[i_r36].defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "span", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const df_r35 = ctx.$implicit;
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", df_r35 == null ? null : df_r35.defectCmnt.defCommentId)("value", df_r35 == null ? null : df_r35.defectCmnt.descriptionEn)("ngModel", ctx_r25.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (df_r35 == null ? null : df_r35.descriptionEn) && (df_r35 == null ? null : df_r35.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", df_r35 == null ? null : df_r35.defectCmnt.defCommentId)("pTooltip", (df_r35 == null ? null : df_r35.subDefectDescriptionEn) + "-" + df_r35.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate2"](" ", df_r35 == null ? null : df_r35.subDefectDescriptionEn, " - ", df_r35 == null ? null : df_r35.defectCmnt.descriptionEn, "");
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72)(1, "div", 73)(2, "div", 74)(3, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_input_ngModelChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r44.selectedSubDefCmnt = $event);
    })("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_input_ngModelChange_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const sd_r42 = restoredCtx.$implicit;
      const i_r43 = restoredCtx.index;
      const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r46.selectedDefCmnt(sd_r42, i_r43, 1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "label", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "a", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_a_click_6_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const i_r43 = restoredCtx.index;
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r47.deleteDefectComment(i_r43, ctx_r47.currentDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](7, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const sd_r42 = restoredCtx.$implicit;
      const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r48.onClickFile(sd_r42.defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "span", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const sd_r42 = ctx.$implicit;
    const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", sd_r42.defCommentId)("value", sd_r42.descriptionEn)("ngModel", ctx_r26.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (sd_r42 == null ? null : sd_r42.descriptionEn) && (sd_r42 == null ? null : sd_r42.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", sd_r42.defCommentId)("pTooltip", sd_r42.subDefectDescriptionEn + "-" + sd_r42.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate2"](" ", sd_r42.subDefectDescriptionEn, " - ", sd_r42.descriptionEn, "");
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_60_div_2_div_1_Template, 2, 1, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template, 10, 9, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template, 10, 9, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r19.selectedDefectsPrevList);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r19.prevSavedDefects);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r19.selectedSubDefectComments);
  }
}
function SubVisualDefectCommentsComponent_div_60_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_60_div_1_Template, 11, 9, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, SubVisualDefectCommentsComponent_div_60_div_2_Template, 4, 3, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx_r4.isDefectCountSelected);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r4.isDefectCountSelected);
  }
}
function SubVisualDefectCommentsComponent_span_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
}
function SubVisualDefectCommentsComponent_label_75_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "label", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1, "Evaluation");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
}
function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r55 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "input", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r55);
      const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r54.selectedEvaluation = $event);
    })("change", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template_input_change_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r55);
      const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      const i_r50 = ctx_r57.index;
      const ev_r49 = ctx_r57.$implicit;
      const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      ctx_r56.errorMessage = "";
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r56.selectEvaluation(i_r50, ev_r49.lkCodeValue));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", ev_r49.lkCodeValue)("value", ev_r49.lkValueEname)("ngModel", ctx_r52.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵattribute"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", ev_r49.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ev_r49.lkValueEname, " ");
  }
}
function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r60 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "input", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r60);
      const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r59.selectedEvaluation = $event);
    })("change", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template_input_change_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r60);
      const ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      const i_r50 = ctx_r62.index;
      const ev_r49 = ctx_r62.$implicit;
      const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      ctx_r61.errorMessage = "";
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r61.selectEvaluation(i_r50, ev_r49.lkCodeValue));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", ev_r49.lkCodeValue)("value", ev_r49.lkValueEname)("ngModel", ctx_r53.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", ev_r49.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ev_r49.lkValueEname, " ");
  }
}
function SubVisualDefectCommentsComponent_div_77_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template, 4, 6, "ng-container", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template, 4, 5, "ng-container", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r51.isReadOnlyEvaluation && ctx_r51.selectedEvaluation == ev_r49.lkValueEname);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx_r51.isReadOnlyEvaluation);
  }
}
function SubVisualDefectCommentsComponent_div_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_77_ng_container_1_Template, 3, 2, "ng-container", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ev_r49.lkCodeValue != 1);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r77 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r77);
      const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r76.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r65.selectedDefLocArray == null ? null : ctx_r65.selectedDefLocArray.includes("FC"))("disabled", ctx_r65.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r79 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r79);
      const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r78.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r66.selectedDefLocArray == null ? null : ctx_r66.selectedDefLocArray.includes("FL"))("disabled", ctx_r66.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r81 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r81);
      const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r80.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r67.selectedDefLocArray == null ? null : ctx_r67.selectedDefLocArray.includes("FR"))("disabled", ctx_r67.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 115);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r83);
      const ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r82.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 116);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r68.selectedDefLocArray == null ? null : ctx_r68.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r68.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r85 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r85);
      const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r84.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r69.selectedDefLocArray == null ? null : ctx_r69.selectedDefLocArray.includes("CL"))("disabled", ctx_r69.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r87 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r87);
      const ctx_r86 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r86.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r70.selectedDefLocArray == null ? null : ctx_r70.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r70.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r89 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_19_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r89);
      const ctx_r88 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r88.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r71.selectedDefLocArray == null ? null : ctx_r71.selectedDefLocArray.includes("CC"))("disabled", ctx_r71.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r91 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 123);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r91);
      const ctx_r90 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r90.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 124);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r72.selectedDefLocArray == null ? null : ctx_r72.selectedDefLocArray.includes("CR"))("disabled", ctx_r72.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r93 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_25_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r93);
      const ctx_r92 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r92.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r73.selectedDefLocArray == null ? null : ctx_r73.selectedDefLocArray.includes("RC"))("disabled", ctx_r73.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r95 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 127);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_27_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r95);
      const ctx_r94 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r94.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 128);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r74.selectedDefLocArray == null ? null : ctx_r74.selectedDefLocArray.includes("RL"))("disabled", ctx_r74.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r97 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_29_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r97);
      const ctx_r96 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r96.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r75.selectedDefLocArray == null ? null : ctx_r75.selectedDefLocArray.includes("RR"))("disabled", ctx_r75.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 3)(1, "div", 92)(2, "div", 93)(3, "div", 94)(4, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, SubVisualDefectCommentsComponent_div_78_div_5_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, SubVisualDefectCommentsComponent_div_78_div_7_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "div", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, SubVisualDefectCommentsComponent_div_78_div_9_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 99)(11, "div", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, SubVisualDefectCommentsComponent_div_78_div_12_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](14, SubVisualDefectCommentsComponent_div_78_div_14_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](16, SubVisualDefectCommentsComponent_div_78_div_16_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "div", 103)(18, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](19, SubVisualDefectCommentsComponent_div_78_div_19_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](20, "div", 105)(21, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](22, SubVisualDefectCommentsComponent_div_78_div_22_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "div", 106)(24, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](25, SubVisualDefectCommentsComponent_div_78_div_25_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](27, SubVisualDefectCommentsComponent_div_78_div_27_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "div", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](29, SubVisualDefectCommentsComponent_div_78_div_29_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](30, "img", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.fc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.fl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.fr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.axle1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.cl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.axle2));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.cc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.cr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.rc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.rl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.rr));
  }
}
function SubVisualDefectCommentsComponent_div_79_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r117 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 145);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r117);
      const ctx_r116 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r116.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r98 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r98.selectedDefLocArray == null ? null : ctx_r98.selectedDefLocArray.includes("FC"))("disabled", ctx_r98.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r119 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r119);
      const ctx_r118 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r118.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r99.selectedDefLocArray == null ? null : ctx_r99.selectedDefLocArray.includes("FL"))("disabled", ctx_r99.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r121 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r121);
      const ctx_r120 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r120.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r100 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r100.selectedDefLocArray == null ? null : ctx_r100.selectedDefLocArray.includes("FR"))("disabled", ctx_r100.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r123 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r123);
      const ctx_r122 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r122.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r101 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r101.selectedDefLocArray == null ? null : ctx_r101.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r101.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r125 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r125);
      const ctx_r124 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r124.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r102 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r102.selectedDefLocArray == null ? null : ctx_r102.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r102.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r127 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r127);
      const ctx_r126 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r126.updateSelectedValues(4, $event, "axle3"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 3 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r103.selectedDefLocArray == null ? null : ctx_r103.selectedDefLocArray.includes("AXLE3"))("disabled", ctx_r103.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r129 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_18_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r129);
      const ctx_r128 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r128.updateSelectedValues(8, $event, "axle4"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 4 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r104 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r104.selectedDefLocArray == null ? null : ctx_r104.selectedDefLocArray.includes("AXLE4"))("disabled", ctx_r104.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r131 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 155);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_20_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r131);
      const ctx_r130 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r130.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r105.selectedDefLocArray == null ? null : ctx_r105.selectedDefLocArray.includes("CL"))("disabled", ctx_r105.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r133 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r133);
      const ctx_r132 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r132.updateSelectedValues(16, $event, "axle5"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 5 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r106 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r106.selectedDefLocArray == null ? null : ctx_r106.selectedDefLocArray.includes("AXLE5"))("disabled", ctx_r106.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r135 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_24_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r135);
      const ctx_r134 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r134.updateSelectedValues(32, $event, "axle6"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 6 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r107 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r107.selectedDefLocArray == null ? null : ctx_r107.selectedDefLocArray.includes("AXLE6"))("disabled", ctx_r107.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r137 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 159);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_26_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r137);
      const ctx_r136 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r136.updateSelectedValues(64, $event, "axle7"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 160);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 7 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r108.selectedDefLocArray == null ? null : ctx_r108.selectedDefLocArray.includes("AXLE7"))("disabled", ctx_r108.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_28_Template(rf, ctx) {
  if (rf & 1) {
    const _r139 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_28_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r139);
      const ctx_r138 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r138.updateSelectedValues(128, $event, "axle8"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 8 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r109.selectedDefLocArray == null ? null : ctx_r109.selectedDefLocArray.includes("AXLE8"))("disabled", ctx_r109.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r141 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 163);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_30_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r141);
      const ctx_r140 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r140.updateSelectedValues(256, $event, "axle9"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 9 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r110 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r110.selectedDefLocArray == null ? null : ctx_r110.selectedDefLocArray.includes("AXLE9"))("disabled", ctx_r110.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r143 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_33_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r143);
      const ctx_r142 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r142.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r111.selectedDefLocArray == null ? null : ctx_r111.selectedDefLocArray.includes("CC"))("disabled", ctx_r111.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_36_Template(rf, ctx) {
  if (rf & 1) {
    const _r145 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_36_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r145);
      const ctx_r144 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r144.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r112 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r112.selectedDefLocArray == null ? null : ctx_r112.selectedDefLocArray.includes("CR"))("disabled", ctx_r112.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r147 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_39_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r147);
      const ctx_r146 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r146.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r113 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r113.selectedDefLocArray == null ? null : ctx_r113.selectedDefLocArray.includes("RC"))("disabled", ctx_r113.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r149 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_41_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r149);
      const ctx_r148 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r148.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 128);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r114 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r114.selectedDefLocArray == null ? null : ctx_r114.selectedDefLocArray.includes("RL"))("disabled", ctx_r114.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r151 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 108)(1, "input", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_43_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r151);
      const ctx_r150 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r150.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 170);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r115 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r115.selectedDefLocArray == null ? null : ctx_r115.selectedDefLocArray.includes("RR"))("disabled", ctx_r115.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 3)(1, "div", 92)(2, "div", 93)(3, "div", 94)(4, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, SubVisualDefectCommentsComponent_div_79_div_5_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, SubVisualDefectCommentsComponent_div_79_div_7_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "div", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, SubVisualDefectCommentsComponent_div_79_div_9_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 130)(11, "div", 131);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, SubVisualDefectCommentsComponent_div_79_div_12_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "div", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](14, SubVisualDefectCommentsComponent_div_79_div_14_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 133);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](16, SubVisualDefectCommentsComponent_div_79_div_16_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "div", 134);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](18, SubVisualDefectCommentsComponent_div_79_div_18_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "div", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](20, SubVisualDefectCommentsComponent_div_79_div_20_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "div", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](22, SubVisualDefectCommentsComponent_div_79_div_22_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "div", 137);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](24, SubVisualDefectCommentsComponent_div_79_div_24_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "div", 138);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](26, SubVisualDefectCommentsComponent_div_79_div_26_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](27, "div", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](28, SubVisualDefectCommentsComponent_div_79_div_28_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](29, "div", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](30, SubVisualDefectCommentsComponent_div_79_div_30_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](31, "div", 103)(32, "div", 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](33, SubVisualDefectCommentsComponent_div_79_div_33_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](34, "div", 142)(35, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](36, SubVisualDefectCommentsComponent_div_79_div_36_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](37, "div", 106)(38, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](39, SubVisualDefectCommentsComponent_div_79_div_39_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](40, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](41, SubVisualDefectCommentsComponent_div_79_div_41_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](42, "div", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](43, SubVisualDefectCommentsComponent_div_79_div_43_Template, 4, 2, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](44, "img", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.fc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.fl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.fr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 1 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 2 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle2));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 3 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle3));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 4 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle4));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.cl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 5 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle5));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 6 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle6));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 7 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle7));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 8 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle8));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 9 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle9));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.cc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.cr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.rc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.rl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.rr));
  }
}
const _c2 = function (a0) {
  return {
    "whitebg": a0
  };
};
class SubVisualDefectCommentsComponent {
  constructor(visualDefectService, lookupServ, sharedData, fileService, globalServ, renderer, el, inspectionService, ngZone) {
    this.visualDefectService = visualDefectService;
    this.lookupServ = lookupServ;
    this.sharedData = sharedData;
    this.fileService = fileService;
    this.globalServ = globalServ;
    this.renderer = renderer;
    this.el = el;
    this.inspectionService = inspectionService;
    this.ngZone = ngZone;
    this.isOkComments = false;
    this.selectedComment = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.changeCategory = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.changeSubCategory = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.openModalEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.selectedDefect = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.selectedSubDefectComments = [];
    this.saveSubDefectComments = [];
    this.prevSavedDefects = [];
    this.defDetailsAdd = [];
    this.showDefectVehicle = false;
    this.showDefectTruck = false;
    this.isCheckboxDisable = false;
    this.isDefectSaved = false;
    this.evaluationList = [];
    this.formDataArray = [];
    this.decimalValue = 300;
    this.decimalValue2 = 130;
    this.binaryDecomposition = [];
    this.isReadOnlyEvaluation = false;
    this.selectedDefectValues = 0;
    this.checkboxStates = {};
    this.remarkCmnt = '';
    this.isDefectCountSelected = false;
    // assign value flags to check from which origin are the defects:
    this.currentDef = 1;
    this.prevDef = 2;
    this.savedDef = 3;
    this.locationAdded = false;
    this.selectedDefLocArray = [];
    this.fileInfo = [];
  }
  ngOnInit() {
    /*  this.sharedData.userId$.subscribe((userId) => {
        this.userId = userId;
      });
      */
    this.userId = parseInt(localStorage.getItem('userId'));
    console.log(this.defectListSaved);
    if (this.isOkComments) {
      this.defectCommentRequestDto = {
        mainDefectId: undefined,
        subDefectId: undefined,
        descriptionEn: undefined,
        orderByCommentId: undefined,
        orderByDescription: undefined,
        recent: 10
      };
    } else {
      this.defectCommentRequestDto = {
        mainDefectId: this.selectedMainDefect.mainDefectId,
        subDefectId: this.selectedSubDefect.subDefectId,
        descriptionEn: undefined,
        orderByCommentId: undefined,
        orderByDescription: undefined,
        recent: 10
      };
    }
    this.getSubVisualDefectsComments();
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.evaluationList).subscribe(response => {
      this.evaluationList = response.items;
      if (this.selectedMainDefect.mainDefectId != src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.mainComment) {
        // Filter out evaluation ok/comment
        this.evaluationList = this.evaluationList.filter(item => item.lkCodeValue !== 2);
      }
    });
    // get if vehicle is heavy or light to display popup
    this.sharedData.vehicleType$.subscribe(categType => {
      this.categoryType = categType;
    });
    this.categoryType == 1 ? this.showDefectVehicle = true : this.showDefectTruck = true;
    this.calculateBinaryDecomposition();
    // get the request id to check the vehicle defects
    this.sharedData.reqNo$.subscribe(reqID => {
      this.requestId = parseInt(reqID);
    });
    this.sharedData.insRequestId$.subscribe(insReqID => {
      this.insRequestId = insReqID;
    });
    this.sharedData.insServiceId$.subscribe(servId => {
      this.insServiceId = servId;
    });
    this.sharedData.insSectionId$.subscribe(sectionId => {
      this.sectionId = sectionId;
    });
    this.sharedData.insStepId$.subscribe(stepId => {
      this.inspectionStepId = stepId;
    });
    this.sharedData.selectedDefectsPrevList$.subscribe(defects => {
      this.selectedDefectsPrevList = defects;
    });
    this.sharedData.defectCommentList$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.take)(1)).subscribe(def => {
      this.prevSavedDefects = def;
    });
    this.sharedData.saveSubDefectComments$.subscribe(def => {
      console.log("saved def", def);
    });
    // get nb axles to display heavy equipment axles
    this.sharedData.nbAxles$.subscribe(axles => {
      if (axles == null) {
        this.nbAxles = 9;
      } else {
        this.nbAxles = axles;
      }
    });
    this.getSubDefects();
  }
  openModal() {
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    console.log(carImagePopModal);
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
    this.openModalEvent.emit();
  }
  isDefectCommentPresent(subDefectComment) {
    let isPresent = false; //this.prevSavedDefects[0]?.defectCmnt.defCommentId == subDefectComment.defCommentId;
    if (this.prevSavedDefects && this.prevSavedDefects.length > 0) {
      for (let df of this.prevSavedDefects) {
        if (df.defectCmnt.defCommentId == subDefectComment.defCommentId) {
          return true;
        }
      }
      return isPresent;
    }
    if (this.selectedDefectsPrevList.length > 0) {
      for (let df of this.selectedDefectsPrevList) {
        if (df.defCommentId == subDefectComment.defCommentId) {
          return true;
        }
      }
      return isPresent;
    }
    return false;
  }
  filterOnDescription() {
    this.visualDefectService.getSubVisualDefectsComments(this.defectCommentRequestDto).subscribe(res => {
      this.subDefectCommentsList = res.items;
    });
  }
  getSubDefectCommentIconByDefectId(defectCommentType) {
    switch (defectCommentType) {
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.InspectorDecides:
        return './assets/img/defects-icon/status_info.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.OKComment:
        return './assets/img/defects-icon/status_comment.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.Major:
        return './assets/img/defects-icon/status_up.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.Minor:
        return './assets/img/defects-icon/status_down.svg';
    }
    return '';
  }
  getSubVisualDefectsComments() {
    this.visualDefectService.getSubVisualDefectsComments(this.defectCommentRequestDto).subscribe(res => {
      this.subDefectCommentsList = res.items;
    });
  }
  toggleOrderByCommentId() {
    this.defectCommentRequestDto.orderByCommentId = this.defectCommentRequestDto.orderByCommentId ? undefined : src_app_core_utilities_enums_defect_comments_sort_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentSortType.Ascending;
    this.defectCommentRequestDto.recent = undefined;
    this.defectCommentRequestDto.orderByDescription = undefined;
    this.getSubVisualDefectsComments();
  }
  toggleOrderByDescription() {
    this.defectCommentRequestDto.orderByDescription = this.defectCommentRequestDto.orderByDescription ? undefined : src_app_core_utilities_enums_defect_comments_sort_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentSortType.Ascending;
    this.defectCommentRequestDto.orderByCommentId = undefined;
    this.defectCommentRequestDto.recent = undefined;
    this.getSubVisualDefectsComments();
  }
  toggleRecentFilter() {
    this.defectCommentRequestDto.recent = this.defectCommentRequestDto.recent ? undefined : 10;
    this.defectCommentRequestDto.orderByDescription = undefined;
    this.defectCommentRequestDto.orderByCommentId = undefined;
    this.getSubVisualDefectsComments();
  }
  isDefectCommentSelected(subDefectCommentId) {
    return this.selectedSubDefectComments.find(x => x.defCommentId == subDefectCommentId) != undefined;
  }
  onSelectSubDefectComment(subDefectComment) {
    let subDefectCommentIndex;
    if (this.isDefectCommentSelected(subDefectComment.defCommentId)) {
      subDefectComment.selected = false;
      subDefectCommentIndex = this.selectedSubDefectComments.findIndex(x => x.defCommentId = subDefectComment.defCommentId);
      this.selectedSubDefectComments.splice(subDefectCommentIndex, 1);
      this.defDetailsAdd.splice(subDefectCommentIndex, 1);
      this.saveSubDefectComments.splice(subDefectCommentIndex, 1);
      this.isDefectCountSelected = false;
      //this.deleteDefectComment(subDefectCommentIndex, this.currentDef);
    } else {
      subDefectCommentIndex = this.selectedSubDefectComments.findIndex(x => x.defCommentId = subDefectComment.defCommentId);
      subDefectComment.selected = true;
      this.selectedSubDefectComments.push(subDefectComment);
      this.selectedSubDefCmnt = subDefectComment.descriptionEn;
      //  if (Object.values(subDefectComment.defectLocation).every(value => value === false)) {
      this.selectedDefCmnt(subDefectComment, subDefectCommentIndex + 1, 1);
      // this.selectSingleDefCmnt(subDefectComment);
      const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
      this.renderer.addClass(carImagePopModal, 'show');
      this.renderer.setStyle(carImagePopModal, 'display', 'block');
      // }
      // else {
      //   console.log("subbb", subDefectComment);
      //   this.selectedDefCmnt(subDefectComment, subDefectCommentIndex + 1, 1);
      // }
    }
  }

  navigateBackToMainDefects() {
    this.changeCategory.emit(true);
  }
  navigateBackToSubDefects() {
    this.changeSubCategory.emit(true);
  }
  updateLetterCount() {
    this.letterCount = this.remarkCmnt.length;
    if (this.remarkCmnt != '') {
      this.canClosePopup = true;
    } else {
      this.canClosePopup = false;
    }
    this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt : this.selectedDefectsPrevList[this.defectCommentIndex].remarks = this.remarkCmnt;
    console.log(this.saveSubDefectComments[this.defectCommentIndex]);
    //this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt;
  }

  insertVin() {
    let vin;
    this.sharedData.vinNo$.subscribe(vinNo => {
      console.log(vinNo);
      vin = vinNo;
      this.remarkCmnt += vin;
      this.updateLetterCount();
    });
  }
  selectedDefCmnt(defectCmnt, index, defSource) {
    this.isRemarkRequired = defectCmnt.isRemarkRequired;
    console.log(defectCmnt);
    this.selectedDefItemLocation = defectCmnt.defectLocation;
    this.defectCommentValue = defectCmnt;
    this.selectedSubDefCmnt = defectCmnt.descriptionEn;
    if (!this.isDefectCountSelected) {
      this.uncheckLoc = true;
      this.disableDef = false;
      console.log(index);
      this.selectedCommentIndex = index;
      //this.selectedDefectValues = 0;
      //this.resetCheckboxes();
      this.selectedDefLocArray = [];
      this.remarkCmnt = '';
      this.defectCommentIndex = index;
      if (defectCmnt.commentType == src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.InspectorDecides && !this.isDefectCountSelected) {
        this.isReadOnlyEvaluation = false;
        this.selectedEvaluation = '';
        this.canClosePopup = false;
      } else {
        console.log(this.evaluationList);
        console.log(defectCmnt.commentType);
        this.selectedEvaluation = this.evaluationList.find(evaluation => evaluation.lkCodeValue == defectCmnt.commentType).lkValueEname;
        this.isReadOnlyEvaluation = true;
        this.canClosePopup = true;
      }
      if (this.isRemarkRequired) {
        if (this.remarkCmnt != '') {
          this.canClosePopup = true;
        } else {
          this.canClosePopup = false;
        }
      }
      if (defectCmnt.locationValue && !this.selectedDefectValues) {
        this.locationAdded = false;
      } else {
        this.locationAdded = true;
      }
      // save the selected sub defect comment in a new item
      const defectComment = {
        inspectionStepId: this.inspectionStepId,
        inspectionReqId: this.insRequestId,
        requestId: this.requestId,
        inspectionServiceId: this.insServiceId,
        sectionId: this.sectionId,
        defectMode: defectCmnt.mode,
        defectsCommentId: defectCmnt.defCommentId,
        defectClassification: defectCmnt.defectClassification,
        remarks: this.remarkCmnt,
        status: 1,
        defectSource: defectCmnt.defectSource,
        evalutionId: defectCmnt.commentType != 1 ? defectCmnt.commentType : this.selectedEvaluationCode,
        locations: this.selectedDefLocArray,
        axle: 0,
        createdBy: this.userId
      };
      console.log("SAVED DEF", this.saveSubDefectComments);
      const isSaveDefectAlreadyAdded = this.saveSubDefectComments.some(def => def?.defectsCommentId == this.saveSubDefectComments[index]?.defectsCommentId);
      if (isSaveDefectAlreadyAdded) {
        // The defect is already in the array
        console.log('Defect already added');
      } else {
        // The defect is not in the array, so add it
        this.saveSubDefectComments[index] = new src_app_core_models_visual_defects_save_sub_defects__WEBPACK_IMPORTED_MODULE_3__.SaveSubDefectComments(defectComment);
      }
      const isDefectAlreadyAdded = this.defDetailsAdd.some(item => item.defectCmnt?.defCommentCode === this.selectedSubDefectComments[index]?.defCommentCode);
      if (!isDefectAlreadyAdded) {
        console.log("add def", this.defDetailsAdd);
        const defDetails = {
          defectCmnt: this.selectedSubDefectComments[this.defectCommentIndex]
        };
        this.defDetailsAdd.push(defDetails);
      }
      this.selectedDefectValues = 0;
      this.selectedDefLocArray = [];
    } else {
      console.log("def cmnt from popup", defectCmnt);
      this.uncheckLoc = false;
      if (defSource == 1) {
        this.disableDef = false;
        this.remarkCmnt = this.saveSubDefectComments[index]?.remarks;
        this.selectedEvaluation = this.mapEvaluationName(this.saveSubDefectComments[index]?.evalutionId);
        if (this.selectedEvaluation == "Comment") {
          this.selectedEvaluation = "OK/Comment";
        }
        this.selectedDefLocArray = this.saveSubDefectComments[index].locations;
        this.selectedEvaluationCode = this.saveSubDefectComments[index]?.evalutionId;
        console.log(this.saveSubDefectComments[index]?.locations);
      }
      if (defSource == 2) {
        this.disableDef = false;
        this.updateprev = true;
        this.sharedData.saveSubDefectComments$.subscribe(savedef => {
          this.remarkCmnt = savedef[index] ? savedef[index].remarks : null;
          this.selectedDefLocArray = savedef[index] ? savedef[index].locations : null;
          this.selectedEvaluation = this.mapEvaluationName(savedef[index] ? savedef[index].evalutionId : null);
          if (this.selectedEvaluation == "Comment") {
            this.selectedEvaluation = "OK/Comment";
          }
          this.selectedEvaluationCode = savedef[index] ? savedef[index].evalutionId : null;
          this.saveSubDefectComments = savedef;
          console.log(savedef[index]);
        });
        console.log(this.saveSubDefectComments[index]);
      }
      if (defSource == 3) {
        this.disableDef = true;
        this.remarkCmnt = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].remarks : null;
        this.selectedDefLocArray = this.selectedDefectsPrevList[index].selectedDefectLocation.toString().split(',');
        this.selectedDefectValues = this.selectedDefectsPrevList[index].locationValue ? this.selectedDefectsPrevList[index].locationValue : 0;
        this.selectedEvaluation = this.mapEvaluationName(this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null);
        if (this.selectedEvaluation == "Comment") {
          this.selectedEvaluation = "OK/Comment";
        }
        this.selectedEvaluationCode = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null;
      }
      // this.resetCheckboxes();
      //  this.selectedDefItemLocation = defectCmnt.defectLocation;
      this.defectCommentIndex = index;
      //this.isCheckboxDisable = defectCmnt.locationValue ? true : false;
      this.isReadOnlyEvaluation = true;
      this.canClosePopup = true;
      console.log(this.selectedDefLocArray);
      if (this.isRemarkRequired) {
        if (this.remarkCmnt != '') {
          this.canClosePopup = true;
        } else {
          this.canClosePopup = false;
        }
      }
      console.log(this.selectedDefectValues);
    }
  }
  updateSelectedValues(value, event, loc) {
    const isChecked = event.target.checked;
    if (isChecked) {
      this.selectedDefectValues += value;
      console.log(loc);
      console.log(this.selectedDefLocArray);
      this.selectedDefLocArray.push(loc.toUpperCase());
      console.log(this.selectedDefLocArray);
      this.checkDefectLocation(loc);
      this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray;
      this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray : this.selectedDefectsPrevList[this.defectCommentIndex].selectedDefectLocation = this.selectedDefLocArray;
      if (this.isDefectCountSelected) {
        this.sharedData.setSaveSubDefectComments(this.saveSubDefectComments);
      }
    } else {
      this.selectedDefectValues -= value;
      const locIndex = this.selectedDefLocArray.indexOf(loc.toUpperCase());
      console.log(this.selectedDefectValues);
      console.log(loc);
      console.log(this.selectedDefLocArray);
      if (locIndex !== -1) {
        this.selectedDefLocArray.splice(locIndex, 1);
      }
      this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray : this.selectedDefectsPrevList[this.defectCommentIndex].selectedDefectLocation = this.selectedDefLocArray;
    }
    if (this.selectedDefectValues) {
      this.locationAdded = true;
    } else {
      this.locationAdded = false;
    }
  }
  mapEvaluationName(evId) {
    return evId == 3 ? "Major" : evId == 4 ? "Minor" : evId == 1 ? "Inspector Decides" : "Comment";
  }
  checkDefectLocation(loc) {
    const defectLoc = this.selectedSubDefectComments[this.defectCommentIndex].defectLocation;
    switch (loc) {
      case 'fl':
        defectLoc.fl = true;
        break;
      case 'fc':
        defectLoc.fc = true;
        break;
      case 'fr':
        defectLoc.fr = true;
        break;
      case 'cl':
        defectLoc.cl = true;
        break;
      case 'cc':
        defectLoc.cc = true;
        break;
      case 'cr':
        defectLoc.cr = true;
        break;
      case 'axle1':
        defectLoc.axle1 = true;
        break;
      case 'axle2':
        defectLoc.axle2 = true;
        break;
      case 'axle3':
        defectLoc.axle3 = true;
        break;
      case 'axle4':
        defectLoc.axle4 = true;
        break;
      case 'axle5':
        defectLoc.axle5 = true;
        break;
      case 'axle6':
        defectLoc.axle6 = true;
        break;
      case 'axle7':
        defectLoc.axle7 = true;
        break;
      case 'axle8':
        defectLoc.axle8 = true;
        break;
      case 'axle9':
        defectLoc.axle9 = true;
        break;
      case 'rl':
        defectLoc.rl = true;
        break;
      case 'rr':
        defectLoc.rr = true;
        break;
      case 'rc':
        defectLoc.rc = true;
        break;
      default:
        break;
    }
    this.selectedDefItemLocation = defectLoc;
  }
  selectEvaluation(index, evaluationCode) {
    this.selectedEvaluationCode = evaluationCode;
    this.canClosePopup = true;
    this.saveSubDefectComments[this.selectedCommentIndex].evalutionId = this.selectedEvaluationCode;
  }
  resetCheckboxes() {
    for (const key in this.checkboxStates) {
      if (this.checkboxStates.hasOwnProperty(key)) {
        this.checkboxStates[key] = false;
      }
    }
  }
  checkDeleteDef(index, sourcenb) {
    this.defectDelIndex = index;
    //this.confirmEval = 
    this.delSource = sourcenb;
  }
  deleteDefectComment(index, source) {
    this.remarkCmnt = '';
    if (source == this.savedDef) {
      this.selectedDefectsPrevList.splice(index, 1);
      this.sharedData.deleteDefectCmnt(this.selectedDefectsPrevList[index].defCommentId);
      const deleteDef = {
        inspectionReqId: this.insRequestId,
        defectsCommentId: this.selectedDefectsPrevList[0].defCommentId
      };
      console.log(deleteDef);
      this.inspectionService.deleteInspectionDefect(deleteDef).subscribe(response => {});
    }
    if (source == this.currentDef) {
      console.log("cuurent def del");
      this.selectedSubDefectComments.splice(index, 1);
      this.saveSubDefectComments.splice(index, 1);
      this.defDetailsAdd.splice(index, 1);
      console.log(this.selectedSubDefectComments);
      console.log(this.saveSubDefectComments);
    }
    if (source == this.prevDef) {
      this.sharedData.deleteSaveSubDefectComment(this.prevSavedDefects[index].defectCmnt.defCommentId);
      this.prevSavedDefects.splice(index, 1);
      this.deletionTrigger = true;
      this.sharedData.setDeleteDefCmnt();
    }
    if (!this.isDefectCountSelected && this.selectedSubDefectComments.length == 0) {
      this.closeVehicleImage();
    }
    if (this.isDefectCountSelected && this.selectedSubDefectComments.length + this.prevSavedDefects.length + this.selectedDefectsPrevList.length == 0) {
      this.closeVehicleImage();
    }
  }
  onFileUploadModalHidden() {
    const fileUploadModal = this.el.nativeElement.querySelector('#fileUploadModal');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
  }
  closeVehicleImage() {
    const fileUploadModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    this.saveChanges();
  }
  openFileModal() {
    const fileUploadModal = this.el.nativeElement.querySelector('#fileUploadModal');
    this.renderer.addClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'block');
  }
  onClickFile(defId) {
    this.openFileModal();
    this.selectedFileDefId = defId;
  }
  onFileUploadData(fInfo) {
    this.fileInfo.push({
      defId: this.selectedFileDefId,
      fileInfo: fInfo
    });
    console.log(this.fileInfo);
    const fileInfoArray = this.fileService.getFileData();
    for (const fileInfo of fileInfoArray) {
      if (fileInfo) {
        const formData = new FormData();
        formData.append('requestId', this.requestId.toString());
        formData.append('sectionId', this.sectionId.toString());
        formData.append('defectId', this.selectedFileDefId.toString());
        formData.append('serviceTypeId', '');
        formData.append('serviceId', '');
        formData.append('mimeType', fileInfo.mimeType);
        formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.InspectionImages.toString());
        formData.append('createdBy', this.userId.toString());
        formData.append('fileData', fileInfo.fileData, fileInfo.filename);
        this.formDataArray.push(formData);
        this.sharedData.setFormData(this.formDataArray);
      }
    }
    this.onFileUploadModalHidden();
  }
  calculateBinaryDecomposition() {
    /*
    if (this.showDefectVehicle) {
      let number = this.decimalValue;
           while (number > 0) {
        const power = Math.floor(Math.log2(number));
        const powerValue = Math.pow(2, power);
             this.binaryDecomposition.push(powerValue);
        number -= powerValue;
      }
           this.carPopup.forEach((popup) => {
        popup.flag = this.binaryDecomposition.includes(popup.decimal);
      });
    }
         if (this.showDefectTruck) {
      let n2 = this.decimalValue2;
           while (n2 > 0) {
        const power = Math.floor(Math.log2(n2));
        const powerValue = Math.pow(2, power);
        this.binaryDecomposition.push(powerValue);
        n2 -= powerValue;
      }
      this.truckPopup.forEach((popup) => {
        popup.flag = this.binaryDecomposition.includes(popup.decimal);
      });
    }
    */
  }
  cancelChanges() {
    const fileUploadModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    if (!this.isDefectCountSelected) {
      this.onSelectSubDefectComment(this.selectedSubDefectComments[this.defectCommentIndex]);
      this.deleteDefectComment(this.defectCommentIndex, this.currentDef);
    }
    this.isDefectCountSelected = false;
  }
  saveChanges() {
    console.log("CLICK ON SAVE CHANGES");
    if (this.selectedEvaluation && !this.isRemarkRequired || this.selectedEvaluation && this.isRemarkRequired && this.remarkCmnt != '') {
      if (!this.isDefectCountSelected) {
        // save the defect comments in a behavior subject
        const cleanSaveSubDefCmnt = [...new Set(this.saveSubDefectComments)];
        this.sharedData.setSaveSubDefectComments(cleanSaveSubDefCmnt);
        let cleanDefDetailsAdd = this.defDetailsAdd;
        if (this.defDetailsAdd.length > 1) {
          // Keep only the last item
          cleanDefDetailsAdd = [this.defDetailsAdd[this.defDetailsAdd.length - 1]];
        }
        this.sharedData.setDefectCmnt(cleanDefDetailsAdd);
        console.log(this.defDetailsAdd);
        console.log(this.saveSubDefectComments);
      }
      const modalElement = document.getElementById('CarImagePop');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        this.canClosePopup = false;
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    }
    this.navigateBackToSubDefects();
    this.isDefectCountSelected = false;
  }
  getSubDefects() {
    this.subDefPayload = {
      mainDefectId: undefined,
      subDefectId: undefined,
      descriptionEn: undefined,
      orderByCommentId: undefined,
      orderByDescription: undefined,
      recent: undefined
    };
    this.visualDefectService.getSubVisualDefectsComments(this.subDefPayload).subscribe(response => {
      this.subDefects = response.items;
    });
  }
  mapSubDefect(subId) {
    let subName;
    if (!this.isSubDefNameCalled) {
      this.inspectionService.getSubDefectNameById({
        subDefectId: subId
      }).subscribe(response => {
        this.isSubDefNameCalled = true;
        if (response.items[0].descriptionEn) {
          console.log(response.items[0].descriptionEn);
          subName = response.items[0].descriptionEn;
        }
      });
      return subName;
    }
  }
  static #_ = this.ɵfac = function SubVisualDefectCommentsComponent_Factory(t) {
    return new (t || SubVisualDefectCommentsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_5__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_6__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_8__.FileService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_9__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_10__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.NgZone));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
    type: SubVisualDefectCommentsComponent,
    selectors: [["sub-visual-defect-comments"]],
    inputs: {
      isOkComments: "isOkComments",
      selectedMainDefect: "selectedMainDefect",
      selectedSubDefect: "selectedSubDefect",
      vehicleCategory: "vehicleCategory",
      defectListSaved: "defectListSaved"
    },
    outputs: {
      selectedComment: "selectedComment",
      changeCategory: "changeCategory",
      changeSubCategory: "changeSubCategory",
      openModalEvent: "openModalEvent",
      selectedDefect: "selectedDefect"
    },
    decls: 107,
    vars: 33,
    consts: [[1, "vd-content-hld"], [1, "chnage-cat-section"], [1, "row", "mb-2"], [1, "col-lg-6"], [1, "row"], [1, "col-lg-12", "mb-4"], ["id", "btGray", 1, "btn-outline-gray"], [1, "btn-orange-outline", 3, "click"], [1, "bi", "bi-pencil-fill"], ["class", "row", 4, "ngIf"], [1, "df-counter"], ["data-bs-toggle", "modal", "data-bs-target", "#CarImagePop", 3, "click"], [1, "counter-btn"], [1, "vd-title"], [1, "col-lg-4"], [1, "search-fld"], [1, "bi", "bi-search"], ["type", "text", "placeholder", "Search Defects", "value", "", 1, "form-control", 2, "padding-left", "45px", 3, "ngModel", "ngModelChange"], [1, "mt-0"], [1, "sort-hold"], [1, "row", "justify-content-end"], [1, "col-auto"], ["data-toggle", "tooltip", "data-placement", "top", "title", "Sort By Frequently Used", 1, "sort-icon-item", 3, "ngClass", "click"], [3, "src"], ["data-toggle", "tooltip", "data-placement", "top", "title", "Sort Alphabetically", 1, "sort-icon-item", 3, "ngClass", "click"], ["data-toggle", "tooltip", "data-placement", "top", "title", "Sort By Defect ID", 1, "sort-icon-item", 3, "ngClass", "click"], [1, "row", 2, "--bs-gutter-y", "1.5rem"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], ["id", "endbtns", 1, "row"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], [3, "deletionTrigger"], ["data-bs-priority", "2000", "data-bs-backdrop", "static", "id", "CarImagePop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-xl", "Car-dialog"], [1, "modal-content"], [1, "modal-header"], ["class", "df-counter", 4, "ngIf"], [1, "modal-body"], [1, "pop-content"], ["class", "row form-fields", 4, "ngIf"], [1, "col-12"], [1, "st-label"], [4, "ngIf"], [1, "txtarea", "w-100", 3, "ngModel", "disabled", "ngModelChange", "input"], ["id", "letterCount", 1, "row"], [1, "shortcut"], ["id", "btnshort", 1, "btn-orange-outline", 3, "disabled", "click"], ["class", "st-label", 4, "ngIf"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["class", "col-lg-6", 4, "ngIf"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"], ["id", "confirmationModalDel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabeldel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], ["id", "contentconfirm", 1, "modal-content"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"], ["id", "fileUploadModal", "tabindex", "-1", "aria-labelledby", "fileUploadModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop", 3, "hidden.bs.modal"], [1, "modal-dialog", "modal-dialog-centered"], [3, "fileUploaded"], [1, "card-link", 3, "click"], [1, "vd-card", 3, "ngClass"], ["data-toggle", "tooltip", "data-placement", "top", 1, "status-icon", 3, "src", "title"], [1, "vd-card-title"], [1, "counter-btn", "p-0", 2, "padding", "0px!important"], ["class", "error-message", 4, "ngIf"], [1, "error-message"], [1, "row", "form-fields"], [1, "col-lg-12", "mb-2"], [1, "outline-radio-container"], [1, "outline-radio", "d-flex", "align-items-center"], ["type", "radio", "name", "selectedSubDefectComments[selectedSubDefectComments.length - 1]?.defCommentCode", 3, "id", "value", "ngModel", "ngModelChange"], ["tooltipPosition", "top", 3, "pTooltip", "for"], [3, "click"], [1, "bi", "bi-trash-fill", "poptrash"], ["data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal", "id", "attachA", 3, "click"], [1, "bi", "bi-paperclip"], ["class", "col-lg-12 mb-2", 4, "ngFor", "ngForOf"], [1, "defect-evaluation-classification-coloir"], ["data-toggle", "tooltip", "data-placement", "top", 2, "height", "33px", 3, "src", "title"], ["type", "radio", 3, "id", "value", "ngModel", "ngModelChange"], ["id", "labelPop", "tooltipPosition", "top", 3, "for", "pTooltip"], ["data-bs-toggle", "modal", "data-bs-target", "#confirmationModalDel", 3, "click"], ["tooltipPosition", "top", 3, "for", "pTooltip"], [1, "bi", "bi-paperclip", 2, "display", "inline-block"], [1, "btn-radio"], ["type", "radio", "name", "ev.lkValueEname", 3, "id", "value", "ngModel", "ngModelChange", "change"], [3, "for"], [1, "car-img-wrap"], [1, "car-img-hold"], [1, "top-chkboxes"], [1, "fc", "chkbx"], ["class", "form-check", 4, "ngIf"], [1, "fl", "chkbx"], [1, "fr", "chkbx"], [1, "left-chkboxes"], [1, "b1", "chkbx"], [1, "cl", "chkbx"], [1, "b2", "chkbx"], [1, "center-chkboxes"], [1, "c", "chkbx"], [1, "right-chkboxes"], [1, "bottom-chkboxes"], ["src", " ./assets/img/car_outline.svg", 1, "car-img"], [1, "form-check"], ["type", "checkbox", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fc", 1, "form-check-label"], ["type", "checkbox", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fl", 1, "form-check-label"], ["type", "checkbox", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b1", 1, "form-check-label"], ["type", "checkbox", "id", "cl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b2", 1, "form-check-label"], ["type", "checkbox", "id", "c", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "c", 1, "form-check-label"], ["type", "checkbox", "id", "cr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cr", 1, "form-check-label"], ["type", "checkbox", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rc", 1, "form-check-label"], ["type", "checkbox", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], [1, "truck-left-chkboxes"], [1, "t1", "chkbx"], [1, "t2", "chkbx"], [1, "t3", "chkbx"], [1, "t4", "chkbx"], [1, "tcl", "chkbx"], [1, "t5", "chkbx"], [1, "t6", "chkbx"], [1, "t7", "chkbx"], [1, "t8", "chkbx"], [1, "t9", "chkbx"], [1, "c-truck", "chkbx"], [1, "truck-right-chkboxes"], [1, "tcr", "chkbx"], ["src", "./assets/img/truck-outline.svg", 1, "car-img"], ["type", "checkbox", "value", "", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t1", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t2", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t3", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t3", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t4", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t4", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t5", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t6", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t7", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t7", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t8", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t8", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t9", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t9", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rr", 1, "form-check-label"]],
    template: function SubVisualDefectCommentsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_8_listener() {
          return ctx.navigateBackToMainDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](10, " Change Category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](11, SubVisualDefectCommentsComponent_div_11_Template, 7, 1, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 3)(13, "div", 10)(14, "a", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_14_listener() {
          ctx.isDefectCountSelected = true;
          return ctx.selectedDefCmnt(ctx.selectedSubDefectComments[ctx.selectedSubDefectComments.length - 1], ctx.selectedSubDefectComments.length - 1, 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](16, " Defects ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "div", 13)(20, "div", 4)(21, "div", 14)(22, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](23, "i", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](24, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_Template_input_ngModelChange_24_listener($event) {
          return ctx.defectCommentRequestDto.descriptionEn = $event;
        })("ngModelChange", function SubVisualDefectCommentsComponent_Template_input_ngModelChange_24_listener() {
          return ctx.filterOnDescription();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "div", 14)(26, "h2", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](27, " Visual Defects Selection");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "div", 14)(29, "div", 19)(30, "div", 20)(31, "div", 21)(32, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](33, " Sort ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](34, "div", 21)(35, "a", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_35_listener() {
          return ctx.toggleRecentFilter();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](36, "img", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](37, "div", 21)(38, "a", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_38_listener() {
          return ctx.toggleOrderByDescription();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](39, "img", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](40, "div", 21)(41, "a", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_41_listener() {
          return ctx.toggleOrderByCommentId();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](42, "img", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](43, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](44, SubVisualDefectCommentsComponent_div_44_Template, 9, 12, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](45, "div", 28)(46, "div", 29)(47, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_47_listener() {
          return ctx.navigateBackToSubDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](48, "Back");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](49, "app-confirm-defects", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](50, "div", 32)(51, "div", 33)(52, "div", 34)(53, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](54, SubVisualDefectCommentsComponent_div_54_Template, 6, 2, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](55, SubVisualDefectCommentsComponent_div_55_Template, 4, 1, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](56, "div", 37)(57, "div", 38)(58, "div", 4)(59, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](60, SubVisualDefectCommentsComponent_div_60_Template, 3, 2, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](61, "div", 4)(62, "div", 40)(63, "label", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](64, " Remarks ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](65, SubVisualDefectCommentsComponent_span_65_Template, 2, 0, "span", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](66, "textarea", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_Template_textarea_ngModelChange_66_listener($event) {
          return ctx.remarkCmnt = $event;
        })("input", function SubVisualDefectCommentsComponent_Template_textarea_input_66_listener() {
          return ctx.updateLetterCount();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](67, "div", 44)(68, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](69);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](70, "div", 45)(71, "button", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_71_listener() {
          return ctx.insertVin();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](72, "Vin No");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](73, "div", 4)(74, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](75, SubVisualDefectCommentsComponent_label_75_Template, 2, 0, "label", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](76, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](77, SubVisualDefectCommentsComponent_div_77_Template, 2, 1, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](78, SubVisualDefectCommentsComponent_div_78_Template, 31, 11, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](79, SubVisualDefectCommentsComponent_div_79_Template, 45, 18, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](80, "div", 50)(81, "button", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_81_listener() {
          return ctx.cancelChanges();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](82, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](83, "button", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_83_listener() {
          return ctx.saveChanges();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](84, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](85, "div", 53)(86, "div", 54)(87, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](88, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](89, "div", 37)(90, "div", 4)(91, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](92, "img", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](93, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](94, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](95, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](96, " Are you sure you want to delete this defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](97, "br")(98, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](99, "button", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](100, "img", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](101, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_101_listener() {
          return ctx.deleteDefectComment(ctx.defectDelIndex, ctx.delSource);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](102, "img", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](103, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("hidden.bs.modal", function SubVisualDefectCommentsComponent_Template_div_hidden_bs_modal_103_listener() {
          return ctx.onFileUploadModalHidden();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](104, "div", 62)(105, "div", 34)(106, "app-file-uploads", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("fileUploaded", function SubVisualDefectCommentsComponent_Template_app_file_uploads_fileUploaded_106_listener($event) {
          return ctx.onFileUploadData($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"]("", ctx.isOkComments ? "Comment" : ctx.selectedMainDefect.defectNameEn, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isOkComments);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("pointer-events", (ctx.selectedSubDefectComments == null ? null : ctx.selectedSubDefectComments.length) + (ctx.prevSavedDefects == null ? null : ctx.prevSavedDefects.length) + (ctx.selectedDefectsPrevList == null ? null : ctx.selectedDefectsPrevList.length) == 0 ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", (ctx.selectedSubDefectComments == null ? null : ctx.selectedSubDefectComments.length) + (ctx.prevSavedDefects == null ? null : ctx.prevSavedDefects.length) + (ctx.selectedDefectsPrevList == null ? null : ctx.selectedDefectsPrevList.length), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.defectCommentRequestDto.descriptionEn);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](27, _c2, ctx.defectCommentRequestDto.recent == undefined));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx.defectCommentRequestDto.recent == undefined ? "./assets/img/defects-icon/time_filter.svg" : "./assets/img/defects-icon/time_filter_white.svg", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](29, _c2, ctx.defectCommentRequestDto.orderByDescription == undefined));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx.defectCommentRequestDto.orderByDescription == undefined ? "./assets/img/defects-icon/letter_filter.svg" : "./assets/img/defects-icon/letter_filter_white.svg", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](31, _c2, ctx.defectCommentRequestDto.orderByCommentId == undefined));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx.defectCommentRequestDto.orderByCommentId == undefined ? "./assets/img/defects-icon/number_filter_orange.svg" : "./assets/img/defects-icon/number_filter.svg", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx.subDefectCommentsList);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("deletionTrigger", ctx.deletionTrigger);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isDefectCountSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isDefectCountSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isDefectSaved);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isRemarkRequired);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.remarkCmnt)("disabled", ctx.disableDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" length: ", ctx.letterCount, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", ctx.disableDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isReadOnlyEvaluation);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx.evaluationList.slice().reverse());
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.showDefectVehicle);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.showDefectTruck);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", !ctx.canClosePopup || !ctx.locationAdded);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgModel, _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_11__.FileUploadsComponent, primeng_tooltip__WEBPACK_IMPORTED_MODULE_17__.Tooltip, _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_12__.ConfirmDefectsComponent],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\n    color: #fb8d0d;\n    cursor: pointer;\n}\n\n.btn-orange[_ngcontent-%COMP%]:disabled {\n    background-color: #ef9c3d;\n    color: #ffff;\n}\n\n\n#fileUploadModal[_ngcontent-%COMP%] {\n    z-index: 2000;\n}\n\n#btGray[_ngcontent-%COMP%] {\n    background: #d5d7da;\n    color: #62656c;\n    font-weight: bold;\n}\n\n#btnshort[_ngcontent-%COMP%] {\n    font-size: small;\n    border-radius: 10px;\n    width: 30px;\n}\n\n#letterCount[_ngcontent-%COMP%] {\n    font-style: italic;\n    font-size: smaller;\n}\n\n.shortcut[_ngcontent-%COMP%] {\n    float: right;\n}\n\n\nlabel.shrink-text[_ngcontent-%COMP%] {\n    max-width: 100%;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    white-space: nowrap;\n    display: flex;\n    flex-wrap: nowrap;\n    justify-content: flex-start;\n    align-items: center;\n}\n\n#endbtns[_ngcontent-%COMP%] {\n    margin-top: 10px;\n}\n\n#fi[_ngcontent-%COMP%] {\n    font-size: 13px;\n    font-style: italic;\n}\n\n#attachA[_ngcontent-%COMP%] {\n    flex: none;\n    display: inline-block;\n}\n\n#contentconfirm[_ngcontent-%COMP%] {\n    width: 60%;\n    text-align: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9zdWItdmlzdWFsLWRlZmVjdC1jb21tZW50cy9zdWItdmlzdWFsLWRlZmVjdC1jb21tZW50cy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQjs7O0FBR0E7SUFDSSxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksbUJBQW1CO0lBQ25CLGNBQWM7SUFDZCxpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLFdBQVc7QUFDZjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxZQUFZO0FBQ2hCOzs7QUFHQTtJQUNJLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixhQUFhO0lBQ2IsaUJBQWlCO0lBQ2pCLDJCQUEyQjtJQUMzQixtQkFBbUI7QUFDdkI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxlQUFlO0lBQ2Ysa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksVUFBVTtJQUNWLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLFVBQVU7SUFDVixrQkFBa0I7QUFDdEIiLCJzb3VyY2VzQ29udGVudCI6WyIub3V0bGluZS1yYWRpby1jb250YWluZXI6aG92ZXIgLmJpIHtcbiAgICBjb2xvcjogI2ZiOGQwZDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG59XG5cbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xuICAgIGNvbG9yOiAjZmZmZjtcbn1cblxuXG4jZmlsZVVwbG9hZE1vZGFsIHtcbiAgICB6LWluZGV4OiAyMDAwO1xufVxuXG4jYnRHcmF5IHtcbiAgICBiYWNrZ3JvdW5kOiAjZDVkN2RhO1xuICAgIGNvbG9yOiAjNjI2NTZjO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4jYnRuc2hvcnQge1xuICAgIGZvbnQtc2l6ZTogc21hbGw7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICB3aWR0aDogMzBweDtcbn1cblxuI2xldHRlckNvdW50IHtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgZm9udC1zaXplOiBzbWFsbGVyO1xufVxuXG4uc2hvcnRjdXQge1xuICAgIGZsb2F0OiByaWdodDtcbn1cblxuXG5sYWJlbC5zaHJpbmstdGV4dCB7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtd3JhcDogbm93cmFwO1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4jZW5kYnRucyB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuI2ZpIHtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xufVxuXG4jYXR0YWNoQSB7XG4gICAgZmxleDogbm9uZTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbiNjb250ZW50Y29uZmlybSB7XG4gICAgd2lkdGg6IDYwJTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 39481:
/*!********************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/sub-visual-defect/sub-visual-defect.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubVisualDefectComponent": () => (/* binding */ SubVisualDefectComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../confirm-defects/confirm-defects.component */ 17767);







function SubVisualDefectComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 10)(1, "a", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SubVisualDefectComponent_div_22_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r3);
      const subDefect_r1 = restoredCtx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.onSelectDefect(subDefect_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 22)(3, "div", 23)(4, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const subDefect_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", subDefect_r1.subDefectId, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", subDefect_r1.descriptionEn, "");
  }
}
class SubVisualDefectComponent {
  constructor(visualDefectService, sharedData) {
    this.visualDefectService = visualDefectService;
    this.sharedData = sharedData;
    this.selectedDefect = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    this.subDefectFilter = '';
  }
  ngOnInit() {
    this.getSubVisualDefects();
    this.sharedData.isDeleteDefCmnt$.subscribe(def => {
      this.deletionTrigger = def;
    });
  }
  getSubVisualDefects() {
    this.visualDefectService.getSubVisualDefects({
      mainDefectId: this.selectedMainDefect.mainDefectId,
      descriptionEn: this.subDefectFilter == '' ? undefined : this.subDefectFilter
    }).subscribe(res => {
      this.subDefectList = res.items;
    });
  }
  onSelectDefect(SubDefect) {
    this.selectedDefect.emit(SubDefect);
  }
  navigateBackToMainDefects() {
    this.selectedDefect.emit(undefined);
  }
  static #_ = this.ɵfac = function SubVisualDefectComponent_Factory(t) {
    return new (t || SubVisualDefectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_0__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: SubVisualDefectComponent,
    selectors: [["sub-visual-defect"]],
    inputs: {
      selectedMainDefect: "selectedMainDefect"
    },
    outputs: {
      selectedDefect: "selectedDefect"
    },
    decls: 28,
    vars: 4,
    consts: [[1, "vd-content-hld"], [1, "chnage-cat-section"], [1, "row"], [1, "col-lg-6"], [1, "col-lg-12", "mb-4"], ["id", "btGray", 1, "btn-outline-gray"], [1, "btn-orange-outline", 3, "click"], [1, "bi", "bi-pencil-fill"], [1, "collg-6"], [1, "vd-title"], [1, "col-lg-4"], [1, "search-fld"], [1, "bi", "bi-search"], ["type", "text", "placeholder", "Search Sub Visual Defects", "value", "", 1, "form-control", 2, "padding-left", "45px", 3, "ngModel", "ngModelChange"], [1, "col-lg-12"], [1, "row", 2, "--bs-gutter-y", "1.5rem"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], ["id", "backBtn", 1, "row"], [1, "col-12", "end-btns", "mt-4"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], [3, "deletionTrigger"], [1, "card-link", 3, "click"], [1, "vd-card", "blue-card"], [1, "vd-card-title"]],
    template: function SubVisualDefectComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 2)(5, "div", 4)(6, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "a", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SubVisualDefectComponent_Template_a_click_8_listener() {
          return ctx.navigateBackToMainDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "i", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, " Change Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](11, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "div", 9)(13, "div", 2)(14, "div", 10)(15, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function SubVisualDefectComponent_Template_input_ngModelChange_17_listener($event) {
          return ctx.subDefectFilter = $event;
        })("ngModelChange", function SubVisualDefectComponent_Template_input_ngModelChange_17_listener() {
          return ctx.getSubVisualDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 14)(19, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Visual Defect Sub Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, SubVisualDefectComponent_div_22_Template, 8, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 17)(24, "div", 18)(25, "button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SubVisualDefectComponent_Template_button_click_25_listener() {
          return ctx.navigateBackToMainDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](26, " Back");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](27, "app-confirm-defects", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.selectedMainDefect.defectNameEn);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx.subDefectFilter);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.subDefectList);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("deletionTrigger", ctx.deletionTrigger);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgModel, _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_2__.ConfirmDefectsComponent],
    styles: ["#btGray[_ngcontent-%COMP%] {\n    background: #d5d7da;\n    color: #62656c;\n    font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9zdWItdmlzdWFsLWRlZmVjdC9zdWItdmlzdWFsLWRlZmVjdC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0lBQ25CLGNBQWM7SUFDZCxpQkFBaUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIjYnRHcmF5IHtcbiAgICBiYWNrZ3JvdW5kOiAjZDVkN2RhO1xuICAgIGNvbG9yOiAjNjI2NTZjO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 12207:
/*!**********************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/visual-defect-list/visual-defect-list.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VisualDefectListComponent": () => (/* binding */ VisualDefectListComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 68951);
/* harmony import */ var src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-selection */ 81295);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../main-visual-defect/main-visual-defect.component */ 26591);
/* harmony import */ var _sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../sub-visual-defect/sub-visual-defect.component */ 39481);
/* harmony import */ var _sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../sub-visual-defect-comments/sub-visual-defect-comments.component */ 97226);
/* harmony import */ var _popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../popup-defect/popup-defect.component */ 92961);









function VisualDefectListComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "div", 4)(2, "div", 5)(3, "a", 6)(4, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5, " Defects ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "div", 8)(9, "div", 9)(10, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](11, "app-popup-defect");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵstyleProp"]("pointer-events", (ctx_r0.prevSavedDefects == null ? null : ctx_r0.prevSavedDefects.length) + (ctx_r0.selectedDefectsPrevList == null ? null : ctx_r0.selectedDefectsPrevList.length) == 0 ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", (ctx_r0.prevSavedDefects == null ? null : ctx_r0.prevSavedDefects.length) + (ctx_r0.selectedDefectsPrevList == null ? null : ctx_r0.selectedDefectsPrevList.length), " ");
  }
}
function VisualDefectListComponent_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "main-visual-defect", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("isOkComments", function VisualDefectListComponent_ng_container_4_Template_main_visual_defect_isOkComments_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r5.setSelectedOnlyComments());
    })("selectedDefect", function VisualDefectListComponent_ng_container_4_Template_main_visual_defect_selectedDefect_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r6);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r7.setSelecetdMainDefect($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
}
function VisualDefectListComponent_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "sub-visual-defect", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("selectedDefect", function VisualDefectListComponent_ng_container_5_Template_sub_visual_defect_selectedDefect_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r8.setSelecetdSubDefect($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("selectedMainDefect", ctx_r2.selectedMainDefect);
  }
}
function VisualDefectListComponent_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "sub-visual-defect-comments", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("changeCategory", function VisualDefectListComponent_ng_container_6_Template_sub_visual_defect_comments_changeCategory_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r10.clearAllSelectedDefects());
    })("openModalEvent", function VisualDefectListComponent_ng_container_6_Template_sub_visual_defect_comments_openModalEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r11);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r12.openModal());
    })("changeSubCategory", function VisualDefectListComponent_ng_container_6_Template_sub_visual_defect_comments_changeSubCategory_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r11);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r13.clearSubSelectedDefects());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("isOkComments", ctx_r3.isOkComments)("selectedMainDefect", ctx_r3.selectedMainDefect)("selectedSubDefect", ctx_r3.selectedSubDefect);
  }
}
function VisualDefectListComponent_a_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "a", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function VisualDefectListComponent_a_7_Template_a_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r15);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r14.scrollUp());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "i", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
class VisualDefectListComponent {
  constructor(el, renderer, sharedData) {
    this.el = el;
    this.renderer = renderer;
    this.sharedData = sharedData;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Main;
    this.defectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode;
    this.isOkComments = false;
    this.prevSavedDefects = [];
    this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    this.showScrollButton = false;
    console.log("test const");
  }
  onWindowScroll() {
    this.showScrollButton = window.pageYOffset > 100; // Show button after scrolling down 100px
  }

  ngOnInit() {
    console.log("test visual main");
    (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.sharedData.selectedDefectsPrevList$, this.sharedData.defectCommentList$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$)).subscribe(([selectedDefectsPrevList, defectCommentList]) => {
      this.selectedDefectsPrevList = selectedDefectsPrevList;
      this.prevSavedDefects = defectCommentList;
      const defectCount = this.selectedDefectsPrevList.length + this.prevSavedDefects?.length;
      console.log('Defect count:', defectCount);
      // Perform any actions based on the defect count here
    });
    // this.sharedData.backMainDefects$.subscribe(
    //   (back) => {
    //     if (back) {
    //       this.clearAllSelectedDefects();
    //     }
    //   }
    // )
  }

  openModalFromChild() {
    // You can add any logic here if needed before opening the modal
    this.openModal();
  }
  openModal() {
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    console.log(carImagePopModal);
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
  }
  setSelecetdMainDefect(mainDefect) {
    this.selectedMainDefect = mainDefect;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Sub;
  }
  setSelecetdSubDefect(subDefect) {
    //If user click back , hide sub section and show the main section:
    if (subDefect == undefined) {
      this.selectedMainDefect = undefined;
      this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Main;
    } else {
      this.selectedSubDefect = subDefect;
      this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Comments;
    }
  }
  setSelectedOnlyComments() {
    this.isOkComments = true;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Comments;
  }
  clearAllSelectedDefects() {
    this.isOkComments = false;
    this.selectedMainDefect = undefined;
    this.selectedSubDefect = undefined;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Main;
  }
  clearSubSelectedDefects() {
    // if (this.selectedDefectSelectionMode != DefectSelectionMode.Comments) {
    this.isOkComments = false;
    this.selectedSubDefect = undefined;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Sub;
    // }
  }

  scrollUp() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }
  scrollDown() {
    window.scrollTo({
      top: document.body.scrollHeight - 20,
      behavior: 'smooth'
    });
  }
  static #_ = this.ɵfac = function VisualDefectListComponent_Factory(t) {
    return new (t || VisualDefectListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: VisualDefectListComponent,
    selectors: [["visual-defect-list"]],
    hostBindings: function VisualDefectListComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("scroll", function VisualDefectListComponent_scroll_HostBindingHandler() {
          return ctx.onWindowScroll();
        }, false, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresolveWindow"]);
      }
    },
    decls: 8,
    vars: 5,
    consts: [[4, "ngIf"], [3, "click"], [1, "bi", "bi-arrow-down", "down"], [3, "click", 4, "ngIf"], ["id", "counterDef", 1, "col-lg-6"], [1, "df-counter"], ["data-bs-toggle", "modal", "data-bs-target", "#CarImagePop"], [1, "counter-btn"], ["data-bs-priority", "2000", "data-bs-backdrop", "static", "id", "CarImagePop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-xl", "Car-dialog"], [1, "modal-content"], [3, "isOkComments", "selectedDefect"], [3, "selectedMainDefect", "selectedDefect"], [3, "isOkComments", "selectedMainDefect", "selectedSubDefect", "changeCategory", "openModalEvent", "changeSubCategory"], [1, "bi", "bi-arrow-up", "up"]],
    template: function VisualDefectListComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](0, VisualDefectListComponent_ng_container_0_Template, 12, 3, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function VisualDefectListComponent_Template_a_click_2_listener() {
          return ctx.scrollDown();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, VisualDefectListComponent_ng_container_4_Template, 2, 0, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, VisualDefectListComponent_ng_container_5_Template, 2, 1, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, VisualDefectListComponent_ng_container_6_Template, 2, 3, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](7, VisualDefectListComponent_a_7_Template, 2, 0, "a", 3);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Main || ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Sub);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Main);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Sub);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Comments);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.showScrollButton);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_2__.MainVisualDefectComponent, _sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_3__.SubVisualDefectComponent, _sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_4__.SubVisualDefectCommentsComponent, _popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_5__.PopupDefectComponent],
    styles: ["#counterDef[_ngcontent-%COMP%] {\n    float: right;\n}\n\n.bi[_ngcontent-%COMP%] {\n    float: right;\n    color: #F89828;\n    background-color: #ffff;\n    font-weight: bold;\n    border-radius: 30px;\n    text-align: center;\n    border: 1px solid #F89828;\n}\n\ni.bi[_ngcontent-%COMP%]:hover {\n    color: #ffff;\n    background-color: #F89828;\n}\n\n.up[_ngcontent-%COMP%] {\n    position: fixed;\n    bottom: 100px;\n    right: 20px;\n    width: 25px;\n    z-index: 200;\n}\n\n.down[_ngcontent-%COMP%] {\n    position: absolute;\n    top: 210px;\n    right: 20px;\n    width: 25px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC92aXN1YWwtZGVmZWN0LWxpc3QvdmlzdWFsLWRlZmVjdC1saXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksWUFBWTtJQUNaLGNBQWM7SUFDZCx1QkFBdUI7SUFDdkIsaUJBQWlCO0lBQ2pCLG1CQUFtQjtJQUNuQixrQkFBa0I7SUFDbEIseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0ksWUFBWTtJQUNaLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLGVBQWU7SUFDZixhQUFhO0lBQ2IsV0FBVztJQUNYLFdBQVc7SUFDWCxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixXQUFXO0lBQ1gsV0FBVztBQUNmIiwic291cmNlc0NvbnRlbnQiOlsiI2NvdW50ZXJEZWYge1xuICAgIGZsb2F0OiByaWdodDtcbn1cblxuLmJpIHtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgY29sb3I6ICNGODk4Mjg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmY7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI0Y4OTgyODtcbn1cblxuaS5iaTpob3ZlciB7XG4gICAgY29sb3I6ICNmZmZmO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XG59XG5cbi51cCB7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogMTAwcHg7XG4gICAgcmlnaHQ6IDIwcHg7XG4gICAgd2lkdGg6IDI1cHg7XG4gICAgei1pbmRleDogMjAwO1xufVxuXG4uZG93biB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMjEwcHg7XG4gICAgcmlnaHQ6IDIwcHg7XG4gICAgd2lkdGg6IDI1cHg7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 52381:
/*!*********************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-badge.mjs ***!
  \*********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Badge": () => (/* binding */ Badge),
/* harmony export */   "BadgeDirective": () => (/* binding */ BadgeDirective),
/* harmony export */   "BadgeModule": () => (/* binding */ BadgeModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 14356);
/* harmony import */ var primeng_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/dom */ 71420);
/* harmony import */ var primeng_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/utils */ 68549);







function Badge_span_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r0.styleClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.containerClass())("ngStyle", ctx_r0.style);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.value);
  }
}
class BadgeDirective {
  constructor(document, el, renderer) {
    this.document = document;
    this.el = el;
    this.renderer = renderer;
    this.iconPos = 'left';
    this._disabled = false;
  }
  get disabled() {
    return this._disabled;
  }
  set disabled(val) {
    this._disabled = val;
  }
  get size() {
    return this._size;
  }
  set size(val) {
    this._size = val;
    if (this.initialized) {
      this.setSizeClasses();
    }
  }
  ngAfterViewInit() {
    this.id = (0,primeng_utils__WEBPACK_IMPORTED_MODULE_1__.UniqueComponentId)() + '_badge';
    let el = this.el.nativeElement.nodeName.indexOf('-') != -1 ? this.el.nativeElement.firstChild : this.el.nativeElement;
    if (this._disabled) {
      return null;
    }
    let badge = this.document.createElement('span');
    badge.id = this.id;
    badge.className = 'p-badge p-component';
    if (this.severity) {
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-' + this.severity);
    }
    this.setSizeClasses(badge);
    if (this.value != null) {
      this.renderer.appendChild(badge, this.document.createTextNode(this.value));
      if (String(this.value).length === 1) {
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-no-gutter');
      }
    } else {
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-dot');
    }
    primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(el, 'p-overlay-badge');
    this.renderer.appendChild(el, badge);
    this.initialized = true;
  }
  get value() {
    return this._value;
  }
  set value(val) {
    if (val !== this._value) {
      this._value = val;
      if (this.initialized) {
        let badge = document.getElementById(this.id);
        if (this._value) {
          if (primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.hasClass(badge, 'p-badge-dot')) primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-dot');
          if (String(this._value).length === 1) {
            primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-no-gutter');
          } else {
            primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-no-gutter');
          }
        } else if (!this._value && !primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.hasClass(badge, 'p-badge-dot')) {
          primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-dot');
        }
        badge.innerHTML = '';
        this.renderer.appendChild(badge, document.createTextNode(this._value));
      }
    }
  }
  setSizeClasses(element) {
    const badge = element ?? this.document.getElementById(this.id);
    if (!badge) {
      return;
    }
    if (this._size) {
      if (this._size === 'large') {
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-lg');
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-xl');
      }
      if (this._size === 'xlarge') {
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-xl');
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-lg');
      }
    } else {
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-lg');
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-xl');
    }
  }
  ngOnDestroy() {
    this.initialized = false;
  }
}
BadgeDirective.ɵfac = function BadgeDirective_Factory(t) {
  return new (t || BadgeDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2));
};
BadgeDirective.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: BadgeDirective,
  selectors: [["", "pBadge", ""]],
  hostAttrs: [1, "p-element"],
  inputs: {
    iconPos: "iconPos",
    disabled: ["badgeDisabled", "disabled"],
    size: "size",
    value: "value",
    severity: "severity"
  }
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BadgeDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[pBadge]',
      host: {
        class: 'p-element'
      }
    }]
  }], function () {
    return [{
      type: Document,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2
    }];
  }, {
    iconPos: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    disabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
      args: ['badgeDisabled']
    }],
    size: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    severity: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class Badge {
  constructor() {
    this.badgeDisabled = false;
  }
  containerClass() {
    return {
      'p-badge p-component': true,
      'p-badge-no-gutter': this.value != undefined && String(this.value).length === 1,
      'p-badge-lg': this.size === 'large',
      'p-badge-xl': this.size === 'xlarge',
      'p-badge-info': this.severity === 'info',
      'p-badge-success': this.severity === 'success',
      'p-badge-warning': this.severity === 'warning',
      'p-badge-danger': this.severity === 'danger'
    };
  }
}
Badge.ɵfac = function Badge_Factory(t) {
  return new (t || Badge)();
};
Badge.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: Badge,
  selectors: [["p-badge"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    styleClass: "styleClass",
    style: "style",
    size: "size",
    severity: "severity",
    value: "value",
    badgeDisabled: "badgeDisabled"
  },
  decls: 1,
  vars: 1,
  consts: [[3, "ngClass", "class", "ngStyle", 4, "ngIf"], [3, "ngClass", "ngStyle"]],
  template: function Badge_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, Badge_span_0_Template, 2, 5, "span", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.badgeDisabled);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgStyle],
  styles: [".p-badge{display:inline-block;border-radius:10px;text-align:center;padding:0 .5rem}.p-overlay-badge{position:relative}.p-overlay-badge .p-badge{position:absolute;top:0;right:0;transform:translate(50%,-50%);transform-origin:100% 0;margin:0}.p-badge-dot{width:.5rem;min-width:.5rem;height:.5rem;border-radius:50%;padding:0}.p-badge-no-gutter{padding:0;border-radius:50%}\n"],
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Badge, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-badge',
      template: ` <span *ngIf="!badgeDisabled" [ngClass]="containerClass()" [class]="styleClass" [ngStyle]="style">{{ value }}</span> `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-badge{display:inline-block;border-radius:10px;text-align:center;padding:0 .5rem}.p-overlay-badge{position:relative}.p-overlay-badge .p-badge{position:absolute;top:0;right:0;transform:translate(50%,-50%);transform-origin:100% 0;margin:0}.p-badge-dot{width:.5rem;min-width:.5rem;height:.5rem;border-radius:50%;padding:0}.p-badge-no-gutter{padding:0;border-radius:50%}\n"]
    }]
  }], null, {
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    size: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    severity: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    badgeDisabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class BadgeModule {}
BadgeModule.ɵfac = function BadgeModule_Factory(t) {
  return new (t || BadgeModule)();
};
BadgeModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: BadgeModule
});
BadgeModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BadgeModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
      exports: [Badge, BadgeDirective, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule],
      declarations: [Badge, BadgeDirective]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-badge.mjs.map

/***/ }),

/***/ 82919:
/*!****************************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-confirmpopup.mjs ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfirmPopup": () => (/* binding */ ConfirmPopup),
/* harmony export */   "ConfirmPopupModule": () => (/* binding */ ConfirmPopupModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/api */ 14356);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/button */ 76328);
/* harmony import */ var primeng_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/utils */ 68549);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/animations */ 24851);
/* harmony import */ var primeng_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/dom */ 71420);











function ConfirmPopup_div_0_i_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "i", 8);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r2.confirmation.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "p-confirm-popup-icon");
  }
}
function ConfirmPopup_div_0_button_7_i_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "i");
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r5.confirmation.rejectIcon);
  }
}
function ConfirmPopup_div_0_button_7_2_ng_template_0_Template(rf, ctx) {}
function ConfirmPopup_div_0_button_7_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, ConfirmPopup_div_0_button_7_2_ng_template_0_Template, 0, 0, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
  }
}
function ConfirmPopup_div_0_button_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConfirmPopup_div_0_button_7_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r9.reject());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ConfirmPopup_div_0_button_7_i_1_Template, 1, 2, "i", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ConfirmPopup_div_0_button_7_2_Template, 2, 0, null, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r3.confirmation.rejectButtonStyleClass || "p-button-text");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("label", ctx_r3.rejectButtonLabel)("ngClass", "p-confirm-popup-reject p-button-sm");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-label", ctx_r3.rejectButtonLabel);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r3.confirmation.rejectIcon)("ngIfElse", ctx_r3.rejecticon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r3.rejectIconTemplate);
  }
}
function ConfirmPopup_div_0_button_8_i_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "i");
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r11.confirmation.acceptIcon);
  }
}
function ConfirmPopup_div_0_button_8_2_ng_template_0_Template(rf, ctx) {}
function ConfirmPopup_div_0_button_8_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, ConfirmPopup_div_0_button_8_2_ng_template_0_Template, 0, 0, "ng-template", null, 13, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
  }
}
function ConfirmPopup_div_0_button_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConfirmPopup_div_0_button_8_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r16);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r15.accept());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ConfirmPopup_div_0_button_8_i_1_Template, 1, 2, "i", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ConfirmPopup_div_0_button_8_2_Template, 2, 0, null, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r4.confirmation.acceptButtonStyleClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("label", ctx_r4.acceptButtonLabel)("ngClass", "p-confirm-popup-accept p-button-sm");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-label", ctx_r4.acceptButtonLabel);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r4.confirmation.acceptIcon)("ngIfElse", ctx_r4.accepticon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r4.acceptIconTemplate);
  }
}
const _c0 = function (a0, a1) {
  return {
    showTransitionParams: a0,
    hideTransitionParams: a1
  };
};
const _c1 = function (a1) {
  return {
    value: "open",
    params: a1
  };
};
function ConfirmPopup_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ConfirmPopup_div_0_Template_div_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r17.onOverlayClick($event));
    })("@animation.start", function ConfirmPopup_div_0_Template_div_animation_animation_start_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r18);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r19.onAnimationStart($event));
    })("@animation.done", function ConfirmPopup_div_0_Template_div_animation_animation_done_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r18);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r20.onAnimationEnd($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 2, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ConfirmPopup_div_0_i_3_Template, 1, 3, "i", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, ConfirmPopup_div_0_button_7_Template, 3, 8, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, ConfirmPopup_div_0_button_8_Template, 3, 8, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r0.styleClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "p-confirm-popup p-component")("ngStyle", ctx_r0.style)("@animation", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](12, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](9, _c0, ctx_r0.showTransitionOptions, ctx_r0.hideTransitionOptions)));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.confirmation.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.confirmation.message);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.confirmation.rejectVisible !== false);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.confirmation.acceptVisible !== false);
  }
}
class ConfirmPopup {
  constructor(el, confirmationService, renderer, cd, config, overlayService, document) {
    this.el = el;
    this.confirmationService = confirmationService;
    this.renderer = renderer;
    this.cd = cd;
    this.config = config;
    this.overlayService = overlayService;
    this.document = document;
    this.defaultFocus = 'accept';
    this.showTransitionOptions = '.12s cubic-bezier(0, 0, 0.2, 1)';
    this.hideTransitionOptions = '.1s linear';
    this.autoZIndex = true;
    this.baseZIndex = 0;
    this.window = this.document.defaultView;
    this.subscription = this.confirmationService.requireConfirmation$.subscribe(confirmation => {
      if (!confirmation) {
        this.hide();
        return;
      }
      if (confirmation.key === this.key) {
        this.confirmation = confirmation;
        if (this.confirmation.accept) {
          this.confirmation.acceptEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
          this.confirmation.acceptEvent.subscribe(this.confirmation.accept);
        }
        if (this.confirmation.reject) {
          this.confirmation.rejectEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
          this.confirmation.rejectEvent.subscribe(this.confirmation.reject);
        }
        this.visible = true;
      }
    });
  }
  get visible() {
    return this._visible;
  }
  set visible(value) {
    this._visible = value;
    this.cd.markForCheck();
  }
  ngAfterContentInit() {
    this.templates.forEach(item => {
      switch (item.getType()) {
        case 'rejecticon':
          this.rejectIconTemplate = item.template;
          break;
        case 'accepticon':
          this.acceptIconTemplate = item.template;
          break;
      }
    });
  }
  onAnimationStart(event) {
    if (event.toState === 'open') {
      this.container = event.element;
      this.renderer.appendChild(this.document.body, this.container);
      this.align();
      this.bindListeners();
      const element = this.getElementToFocus();
      if (element) {
        element.focus();
      }
    }
  }
  onAnimationEnd(event) {
    switch (event.toState) {
      case 'void':
        this.onContainerDestroy();
        break;
    }
  }
  getElementToFocus() {
    switch (this.defaultFocus) {
      case 'accept':
        return primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.findSingle(this.container, '.p-confirm-popup-accept');
      case 'reject':
        return primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.findSingle(this.container, '.p-confirm-popup-reject');
      case 'none':
        return null;
    }
  }
  align() {
    if (this.autoZIndex) {
      primeng_utils__WEBPACK_IMPORTED_MODULE_2__.ZIndexUtils.set('overlay', this.container, this.config.zIndex.overlay);
    }
    primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.absolutePosition(this.container, this.confirmation.target);
    const containerOffset = primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.getOffset(this.container);
    const targetOffset = primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.getOffset(this.confirmation.target);
    let arrowLeft = 0;
    if (containerOffset.left < targetOffset.left) {
      arrowLeft = targetOffset.left - containerOffset.left;
    }
    this.container.style.setProperty('--overlayArrowLeft', `${arrowLeft}px`);
    if (containerOffset.top < targetOffset.top) {
      primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.addClass(this.container, 'p-confirm-popup-flipped');
    }
  }
  hide() {
    this.visible = false;
  }
  accept() {
    if (this.confirmation.acceptEvent) {
      this.confirmation.acceptEvent.emit();
    }
    this.hide();
  }
  reject() {
    if (this.confirmation.rejectEvent) {
      this.confirmation.rejectEvent.emit();
    }
    this.hide();
  }
  onOverlayClick(event) {
    this.overlayService.add({
      originalEvent: event,
      target: this.el.nativeElement
    });
  }
  bindListeners() {
    /*
     * Called inside `setTimeout` to avoid listening to the click event that appears when `confirm` is first called(bubbling).
     * Need wait when bubbling event up and hang the handler on the next tick.
     * This is the case when eventTarget and confirmation.target do not match when the `confirm` method is called.
     */
    setTimeout(() => {
      this.bindDocumentClickListener();
      this.bindDocumentResizeListener();
      this.bindScrollListener();
    });
  }
  unbindListeners() {
    this.unbindDocumentClickListener();
    this.unbindDocumentResizeListener();
    this.unbindScrollListener();
  }
  bindDocumentClickListener() {
    if (!this.documentClickListener) {
      let documentEvent = primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.isIOS() ? 'touchstart' : 'click';
      const documentTarget = this.el ? this.el.nativeElement.ownerDocument : this.document;
      this.documentClickListener = this.renderer.listen(documentTarget, documentEvent, event => {
        let targetElement = this.confirmation.target;
        if (this.container !== event.target && !this.container.contains(event.target) && targetElement !== event.target && !targetElement.contains(event.target)) {
          this.hide();
        }
      });
    }
  }
  unbindDocumentClickListener() {
    if (this.documentClickListener) {
      this.documentClickListener();
      this.documentClickListener = null;
    }
  }
  onWindowResize() {
    if (this.visible && !primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.isTouchDevice()) {
      this.hide();
    }
  }
  bindDocumentResizeListener() {
    if (!this.documentResizeListener) {
      this.documentResizeListener = this.renderer.listen(this.window, 'resize', this.onWindowResize.bind(this));
    }
  }
  unbindDocumentResizeListener() {
    if (this.documentResizeListener) {
      this.documentResizeListener();
      this.documentResizeListener = null;
    }
  }
  bindScrollListener() {
    if (!this.scrollHandler) {
      this.scrollHandler = new primeng_dom__WEBPACK_IMPORTED_MODULE_1__.ConnectedOverlayScrollHandler(this.confirmation.target, () => {
        if (this.visible) {
          this.hide();
        }
      });
    }
    this.scrollHandler.bindScrollListener();
  }
  unbindScrollListener() {
    if (this.scrollHandler) {
      this.scrollHandler.unbindScrollListener();
    }
  }
  unsubscribeConfirmationSubscriptions() {
    if (this.confirmation) {
      if (this.confirmation.acceptEvent) {
        this.confirmation.acceptEvent.unsubscribe();
      }
      if (this.confirmation.rejectEvent) {
        this.confirmation.rejectEvent.unsubscribe();
      }
    }
  }
  onContainerDestroy() {
    this.unbindListeners();
    this.unsubscribeConfirmationSubscriptions();
    if (this.autoZIndex) {
      primeng_utils__WEBPACK_IMPORTED_MODULE_2__.ZIndexUtils.clear(this.container);
    }
    this.confirmation = null;
    this.container = null;
  }
  restoreAppend() {
    if (this.container) {
      this.renderer.removeChild(this.document.body, this.container);
    }
    this.onContainerDestroy();
  }
  get acceptButtonLabel() {
    return this.confirmation.acceptLabel || this.config.getTranslation(primeng_api__WEBPACK_IMPORTED_MODULE_3__.TranslationKeys.ACCEPT);
  }
  get rejectButtonLabel() {
    return this.confirmation.rejectLabel || this.config.getTranslation(primeng_api__WEBPACK_IMPORTED_MODULE_3__.TranslationKeys.REJECT);
  }
  ngOnDestroy() {
    this.restoreAppend();
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
ConfirmPopup.ɵfac = function ConfirmPopup_Factory(t) {
  return new (t || ConfirmPopup)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_3__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_3__.PrimeNGConfig), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_3__.OverlayService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_4__.DOCUMENT));
};
ConfirmPopup.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: ConfirmPopup,
  selectors: [["p-confirmPopup"]],
  contentQueries: function ConfirmPopup_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, primeng_api__WEBPACK_IMPORTED_MODULE_3__.PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.templates = _t);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    key: "key",
    defaultFocus: "defaultFocus",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions",
    autoZIndex: "autoZIndex",
    baseZIndex: "baseZIndex",
    style: "style",
    styleClass: "styleClass",
    visible: "visible"
  },
  decls: 1,
  vars: 1,
  consts: [[3, "ngClass", "ngStyle", "class", "click", 4, "ngIf"], [3, "ngClass", "ngStyle", "click"], [1, "p-confirm-popup-content"], ["content", ""], [3, "ngClass", "class", 4, "ngIf"], [1, "p-confirm-popup-message"], [1, "p-confirm-popup-footer"], ["type", "button", "pButton", "", 3, "label", "ngClass", "class", "click", 4, "ngIf"], [3, "ngClass"], ["type", "button", "pButton", "", 3, "label", "ngClass", "click"], [3, "class", 4, "ngIf", "ngIfElse"], [4, "ngTemplateOutlet"], ["rejecticon", ""], ["accepticon", ""]],
  template: function ConfirmPopup_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, ConfirmPopup_div_0_Template, 9, 14, "div", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.visible);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgStyle, primeng_button__WEBPACK_IMPORTED_MODULE_5__.ButtonDirective],
  styles: [".p-confirm-popup{position:absolute;margin-top:10px;top:0;left:0}.p-confirm-popup-flipped{margin-top:0;margin-bottom:10px}.p-confirm-popup:after,.p-confirm-popup:before{bottom:100%;left:calc(var(--overlayArrowLeft, 0) + 1.25rem);content:\" \";height:0;width:0;position:absolute;pointer-events:none}.p-confirm-popup:after{border-width:8px;margin-left:-8px}.p-confirm-popup:before{border-width:10px;margin-left:-10px}.p-confirm-popup-flipped:after,.p-confirm-popup-flipped:before{bottom:auto;top:100%}.p-confirm-popup.p-confirm-popup-flipped:after{border-bottom-color:transparent}.p-confirm-popup.p-confirm-popup-flipped:before{border-bottom-color:transparent}.p-confirm-popup .p-confirm-popup-content{display:flex;align-items:center}\n"],
  encapsulation: 2,
  data: {
    animation: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.trigger)('animation', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.state)('void', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.style)({
      transform: 'scaleY(0.8)',
      opacity: 0
    })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.state)('open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.style)({
      transform: 'translateY(0)',
      opacity: 1
    })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.transition)('void => open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.animate)('{{showTransitionParams}}')), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.transition)('open => void', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.animate)('{{hideTransitionParams}}'))])]
  },
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ConfirmPopup, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-confirmPopup',
      template: `
        <div
            *ngIf="visible"
            [ngClass]="'p-confirm-popup p-component'"
            [ngStyle]="style"
            [class]="styleClass"
            (click)="onOverlayClick($event)"
            [@animation]="{ value: 'open', params: { showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions } }"
            (@animation.start)="onAnimationStart($event)"
            (@animation.done)="onAnimationEnd($event)"
        >
            <div #content class="p-confirm-popup-content">
                <i [ngClass]="'p-confirm-popup-icon'" [class]="confirmation.icon" *ngIf="confirmation.icon"></i>
                <span class="p-confirm-popup-message">{{ confirmation.message }}</span>
            </div>
            <div class="p-confirm-popup-footer">
                <button
                    type="button"
                    pButton
                    [label]="rejectButtonLabel"
                    (click)="reject()"
                    [ngClass]="'p-confirm-popup-reject p-button-sm'"
                    [class]="confirmation.rejectButtonStyleClass || 'p-button-text'"
                    *ngIf="confirmation.rejectVisible !== false"
                    [attr.aria-label]="rejectButtonLabel"
                >
                    <i [class]="confirmation.rejectIcon" *ngIf="confirmation.rejectIcon; else rejecticon"></i>
                    <ng-template #rejecticon *ngTemplateOutlet="rejectIconTemplate"></ng-template>
                </button>
                <button
                    type="button"
                    pButton
                    [label]="acceptButtonLabel"
                    (click)="accept()"
                    [ngClass]="'p-confirm-popup-accept p-button-sm'"
                    [class]="confirmation.acceptButtonStyleClass"
                    *ngIf="confirmation.acceptVisible !== false"
                    [attr.aria-label]="acceptButtonLabel"
                >
                    <i [class]="confirmation.acceptIcon" *ngIf="confirmation.acceptIcon; else accepticon"></i>
                    <ng-template #accepticon *ngTemplateOutlet="acceptIconTemplate"></ng-template>
                </button>
            </div>
        </div>
    `,
      animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.trigger)('animation', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.state)('void', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.style)({
        transform: 'scaleY(0.8)',
        opacity: 0
      })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.state)('open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.style)({
        transform: 'translateY(0)',
        opacity: 1
      })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.transition)('void => open', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.animate)('{{showTransitionParams}}')), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.transition)('open => void', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_6__.animate)('{{hideTransitionParams}}'))])],
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-confirm-popup{position:absolute;margin-top:10px;top:0;left:0}.p-confirm-popup-flipped{margin-top:0;margin-bottom:10px}.p-confirm-popup:after,.p-confirm-popup:before{bottom:100%;left:calc(var(--overlayArrowLeft, 0) + 1.25rem);content:\" \";height:0;width:0;position:absolute;pointer-events:none}.p-confirm-popup:after{border-width:8px;margin-left:-8px}.p-confirm-popup:before{border-width:10px;margin-left:-10px}.p-confirm-popup-flipped:after,.p-confirm-popup-flipped:before{bottom:auto;top:100%}.p-confirm-popup.p-confirm-popup-flipped:after{border-bottom-color:transparent}.p-confirm-popup.p-confirm-popup-flipped:before{border-bottom-color:transparent}.p-confirm-popup .p-confirm-popup-content{display:flex;align-items:center}\n"]
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: primeng_api__WEBPACK_IMPORTED_MODULE_3__.ConfirmationService
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }, {
      type: primeng_api__WEBPACK_IMPORTED_MODULE_3__.PrimeNGConfig
    }, {
      type: primeng_api__WEBPACK_IMPORTED_MODULE_3__.OverlayService
    }, {
      type: Document,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.DOCUMENT]
      }]
    }];
  }, {
    key: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    defaultFocus: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    hideTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    autoZIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    baseZIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [primeng_api__WEBPACK_IMPORTED_MODULE_3__.PrimeTemplate]
    }],
    visible: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class ConfirmPopupModule {}
ConfirmPopupModule.ɵfac = function ConfirmPopupModule_Factory(t) {
  return new (t || ConfirmPopupModule)();
};
ConfirmPopupModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: ConfirmPopupModule
});
ConfirmPopupModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, primeng_button__WEBPACK_IMPORTED_MODULE_5__.ButtonModule, primeng_api__WEBPACK_IMPORTED_MODULE_3__.SharedModule, primeng_api__WEBPACK_IMPORTED_MODULE_3__.SharedModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ConfirmPopupModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, primeng_button__WEBPACK_IMPORTED_MODULE_5__.ButtonModule, primeng_api__WEBPACK_IMPORTED_MODULE_3__.SharedModule],
      exports: [ConfirmPopup, primeng_api__WEBPACK_IMPORTED_MODULE_3__.SharedModule],
      declarations: [ConfirmPopup]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-confirmpopup.mjs.map

/***/ }),

/***/ 81938:
/*!*****************************************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-icons-exclamationtriangle.mjs ***!
  \*****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExclamationTriangleIcon": () => (/* binding */ ExclamationTriangleIcon)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! primeng/baseicon */ 98095);



class ExclamationTriangleIcon extends primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__.BaseIcon {}
ExclamationTriangleIcon.ɵfac = /* @__PURE__ */function () {
  let ɵExclamationTriangleIcon_BaseFactory;
  return function ExclamationTriangleIcon_Factory(t) {
    return (ɵExclamationTriangleIcon_BaseFactory || (ɵExclamationTriangleIcon_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](ExclamationTriangleIcon)))(t || ExclamationTriangleIcon);
  };
}();
ExclamationTriangleIcon.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: ExclamationTriangleIcon,
  selectors: [["ExclamationTriangleIcon"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵStandaloneFeature"]],
  decls: 8,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["clip-path", "url(#clip0_323_12417)"], ["d", "M13.4018 13.1893H0.598161C0.49329 13.189 0.390283 13.1615 0.299143 13.1097C0.208003 13.0578 0.131826 12.9832 0.0780112 12.8932C0.0268539 12.8015 0 12.6982 0 12.5931C0 12.4881 0.0268539 12.3848 0.0780112 12.293L6.47985 1.08982C6.53679 1.00399 6.61408 0.933574 6.70484 0.884867C6.7956 0.836159 6.897 0.810669 7 0.810669C7.103 0.810669 7.2044 0.836159 7.29516 0.884867C7.38592 0.933574 7.46321 1.00399 7.52015 1.08982L13.922 12.293C13.9731 12.3848 14 12.4881 14 12.5931C14 12.6982 13.9731 12.8015 13.922 12.8932C13.8682 12.9832 13.792 13.0578 13.7009 13.1097C13.6097 13.1615 13.5067 13.189 13.4018 13.1893ZM1.63046 11.989H12.3695L7 2.59425L1.63046 11.989Z", "fill", "currentColor"], ["d", "M6.99996 8.78801C6.84143 8.78594 6.68997 8.72204 6.57787 8.60993C6.46576 8.49782 6.40186 8.34637 6.39979 8.18784V5.38703C6.39979 5.22786 6.46302 5.0752 6.57557 4.96265C6.68813 4.85009 6.84078 4.78686 6.99996 4.78686C7.15914 4.78686 7.31179 4.85009 7.42435 4.96265C7.5369 5.0752 7.60013 5.22786 7.60013 5.38703V8.18784C7.59806 8.34637 7.53416 8.49782 7.42205 8.60993C7.30995 8.72204 7.15849 8.78594 6.99996 8.78801Z", "fill", "currentColor"], ["d", "M6.99996 11.1887C6.84143 11.1866 6.68997 11.1227 6.57787 11.0106C6.46576 10.8985 6.40186 10.7471 6.39979 10.5885V10.1884C6.39979 10.0292 6.46302 9.87658 6.57557 9.76403C6.68813 9.65147 6.84078 9.58824 6.99996 9.58824C7.15914 9.58824 7.31179 9.65147 7.42435 9.76403C7.5369 9.87658 7.60013 10.0292 7.60013 10.1884V10.5885C7.59806 10.7471 7.53416 10.8985 7.42205 11.0106C7.30995 11.1227 7.15849 11.1866 6.99996 11.1887Z", "fill", "currentColor"], ["id", "clip0_323_12417"], ["width", "14", "height", "14", "fill", "white"]],
  template: function ExclamationTriangleIcon_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "svg", 0)(1, "g", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "path", 2)(3, "path", 3)(4, "path", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "defs")(6, "clipPath", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "rect", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.getClassNames());
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](ExclamationTriangleIcon, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Component,
    args: [{
      selector: 'ExclamationTriangleIcon',
      standalone: true,
      imports: [primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__.BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g clip-path="url(#clip0_323_12417)">
                <path
                    d="M13.4018 13.1893H0.598161C0.49329 13.189 0.390283 13.1615 0.299143 13.1097C0.208003 13.0578 0.131826 12.9832 0.0780112 12.8932C0.0268539 12.8015 0 12.6982 0 12.5931C0 12.4881 0.0268539 12.3848 0.0780112 12.293L6.47985 1.08982C6.53679 1.00399 6.61408 0.933574 6.70484 0.884867C6.7956 0.836159 6.897 0.810669 7 0.810669C7.103 0.810669 7.2044 0.836159 7.29516 0.884867C7.38592 0.933574 7.46321 1.00399 7.52015 1.08982L13.922 12.293C13.9731 12.3848 14 12.4881 14 12.5931C14 12.6982 13.9731 12.8015 13.922 12.8932C13.8682 12.9832 13.792 13.0578 13.7009 13.1097C13.6097 13.1615 13.5067 13.189 13.4018 13.1893ZM1.63046 11.989H12.3695L7 2.59425L1.63046 11.989Z"
                    fill="currentColor"
                />
                <path
                    d="M6.99996 8.78801C6.84143 8.78594 6.68997 8.72204 6.57787 8.60993C6.46576 8.49782 6.40186 8.34637 6.39979 8.18784V5.38703C6.39979 5.22786 6.46302 5.0752 6.57557 4.96265C6.68813 4.85009 6.84078 4.78686 6.99996 4.78686C7.15914 4.78686 7.31179 4.85009 7.42435 4.96265C7.5369 5.0752 7.60013 5.22786 7.60013 5.38703V8.18784C7.59806 8.34637 7.53416 8.49782 7.42205 8.60993C7.30995 8.72204 7.15849 8.78594 6.99996 8.78801Z"
                    fill="currentColor"
                />
                <path
                    d="M6.99996 11.1887C6.84143 11.1866 6.68997 11.1227 6.57787 11.0106C6.46576 10.8985 6.40186 10.7471 6.39979 10.5885V10.1884C6.39979 10.0292 6.46302 9.87658 6.57557 9.76403C6.68813 9.65147 6.84078 9.58824 6.99996 9.58824C7.15914 9.58824 7.31179 9.65147 7.42435 9.76403C7.5369 9.87658 7.60013 10.0292 7.60013 10.1884V10.5885C7.59806 10.7471 7.53416 10.8985 7.42205 11.0106C7.30995 11.1227 7.15849 11.1866 6.99996 11.1887Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath id="clip0_323_12417">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-icons-exclamationtriangle.mjs.map

/***/ }),

/***/ 86194:
/*!********************************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-icons-infocircle.mjs ***!
  \********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InfoCircleIcon": () => (/* binding */ InfoCircleIcon)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! primeng/baseicon */ 98095);



class InfoCircleIcon extends primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__.BaseIcon {}
InfoCircleIcon.ɵfac = /* @__PURE__ */function () {
  let ɵInfoCircleIcon_BaseFactory;
  return function InfoCircleIcon_Factory(t) {
    return (ɵInfoCircleIcon_BaseFactory || (ɵInfoCircleIcon_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](InfoCircleIcon)))(t || InfoCircleIcon);
  };
}();
InfoCircleIcon.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: InfoCircleIcon,
  selectors: [["InfoCircleIcon"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵStandaloneFeature"]],
  decls: 6,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["clip-path", "url(#clip0_408_21102)"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M3.11101 12.8203C4.26215 13.5895 5.61553 14 7 14C8.85652 14 10.637 13.2625 11.9497 11.9497C13.2625 10.637 14 8.85652 14 7C14 5.61553 13.5895 4.26215 12.8203 3.11101C12.0511 1.95987 10.9579 1.06266 9.67879 0.532846C8.3997 0.00303296 6.99224 -0.13559 5.63437 0.134506C4.2765 0.404603 3.02922 1.07129 2.05026 2.05026C1.07129 3.02922 0.404603 4.2765 0.134506 5.63437C-0.13559 6.99224 0.00303296 8.3997 0.532846 9.67879C1.06266 10.9579 1.95987 12.0511 3.11101 12.8203ZM3.75918 2.14976C4.71846 1.50879 5.84628 1.16667 7 1.16667C8.5471 1.16667 10.0308 1.78125 11.1248 2.87521C12.2188 3.96918 12.8333 5.45291 12.8333 7C12.8333 8.15373 12.4912 9.28154 11.8502 10.2408C11.2093 11.2001 10.2982 11.9478 9.23232 12.3893C8.16642 12.8308 6.99353 12.9463 5.86198 12.7212C4.73042 12.4962 3.69102 11.9406 2.87521 11.1248C2.05941 10.309 1.50384 9.26958 1.27876 8.13803C1.05367 7.00647 1.16919 5.83358 1.61071 4.76768C2.05222 3.70178 2.79989 2.79074 3.75918 2.14976ZM7.00002 4.8611C6.84594 4.85908 6.69873 4.79698 6.58977 4.68801C6.48081 4.57905 6.4187 4.43185 6.41669 4.27776V3.88888C6.41669 3.73417 6.47815 3.58579 6.58754 3.4764C6.69694 3.367 6.84531 3.30554 7.00002 3.30554C7.15473 3.30554 7.3031 3.367 7.4125 3.4764C7.52189 3.58579 7.58335 3.73417 7.58335 3.88888V4.27776C7.58134 4.43185 7.51923 4.57905 7.41027 4.68801C7.30131 4.79698 7.1541 4.85908 7.00002 4.8611ZM7.00002 10.6945C6.84594 10.6925 6.69873 10.6304 6.58977 10.5214C6.48081 10.4124 6.4187 10.2652 6.41669 10.1111V6.22225C6.41669 6.06754 6.47815 5.91917 6.58754 5.80977C6.69694 5.70037 6.84531 5.63892 7.00002 5.63892C7.15473 5.63892 7.3031 5.70037 7.4125 5.80977C7.52189 5.91917 7.58335 6.06754 7.58335 6.22225V10.1111C7.58134 10.2652 7.51923 10.4124 7.41027 10.5214C7.30131 10.6304 7.1541 10.6925 7.00002 10.6945Z", "fill", "currentColor"], ["id", "clip0_408_21102"], ["width", "14", "height", "14", "fill", "white"]],
  template: function InfoCircleIcon_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "svg", 0)(1, "g", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "path", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "defs")(4, "clipPath", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "rect", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.getClassNames());
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](InfoCircleIcon, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Component,
    args: [{
      selector: 'InfoCircleIcon',
      standalone: true,
      imports: [primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__.BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g clip-path="url(#clip0_408_21102)">
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M3.11101 12.8203C4.26215 13.5895 5.61553 14 7 14C8.85652 14 10.637 13.2625 11.9497 11.9497C13.2625 10.637 14 8.85652 14 7C14 5.61553 13.5895 4.26215 12.8203 3.11101C12.0511 1.95987 10.9579 1.06266 9.67879 0.532846C8.3997 0.00303296 6.99224 -0.13559 5.63437 0.134506C4.2765 0.404603 3.02922 1.07129 2.05026 2.05026C1.07129 3.02922 0.404603 4.2765 0.134506 5.63437C-0.13559 6.99224 0.00303296 8.3997 0.532846 9.67879C1.06266 10.9579 1.95987 12.0511 3.11101 12.8203ZM3.75918 2.14976C4.71846 1.50879 5.84628 1.16667 7 1.16667C8.5471 1.16667 10.0308 1.78125 11.1248 2.87521C12.2188 3.96918 12.8333 5.45291 12.8333 7C12.8333 8.15373 12.4912 9.28154 11.8502 10.2408C11.2093 11.2001 10.2982 11.9478 9.23232 12.3893C8.16642 12.8308 6.99353 12.9463 5.86198 12.7212C4.73042 12.4962 3.69102 11.9406 2.87521 11.1248C2.05941 10.309 1.50384 9.26958 1.27876 8.13803C1.05367 7.00647 1.16919 5.83358 1.61071 4.76768C2.05222 3.70178 2.79989 2.79074 3.75918 2.14976ZM7.00002 4.8611C6.84594 4.85908 6.69873 4.79698 6.58977 4.68801C6.48081 4.57905 6.4187 4.43185 6.41669 4.27776V3.88888C6.41669 3.73417 6.47815 3.58579 6.58754 3.4764C6.69694 3.367 6.84531 3.30554 7.00002 3.30554C7.15473 3.30554 7.3031 3.367 7.4125 3.4764C7.52189 3.58579 7.58335 3.73417 7.58335 3.88888V4.27776C7.58134 4.43185 7.51923 4.57905 7.41027 4.68801C7.30131 4.79698 7.1541 4.85908 7.00002 4.8611ZM7.00002 10.6945C6.84594 10.6925 6.69873 10.6304 6.58977 10.5214C6.48081 10.4124 6.4187 10.2652 6.41669 10.1111V6.22225C6.41669 6.06754 6.47815 5.91917 6.58754 5.80977C6.69694 5.70037 6.84531 5.63892 7.00002 5.63892C7.15473 5.63892 7.3031 5.70037 7.4125 5.80977C7.52189 5.91917 7.58335 6.06754 7.58335 6.22225V10.1111C7.58134 10.2652 7.51923 10.4124 7.41027 10.5214C7.30131 10.6304 7.1541 10.6925 7.00002 10.6945Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath id="clip0_408_21102">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-icons-infocircle.mjs.map

/***/ }),

/***/ 66195:
/*!*********************************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-icons-timescircle.mjs ***!
  \*********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimesCircleIcon": () => (/* binding */ TimesCircleIcon)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! primeng/baseicon */ 98095);



class TimesCircleIcon extends primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__.BaseIcon {}
TimesCircleIcon.ɵfac = /* @__PURE__ */function () {
  let ɵTimesCircleIcon_BaseFactory;
  return function TimesCircleIcon_Factory(t) {
    return (ɵTimesCircleIcon_BaseFactory || (ɵTimesCircleIcon_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](TimesCircleIcon)))(t || TimesCircleIcon);
  };
}();
TimesCircleIcon.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: TimesCircleIcon,
  selectors: [["TimesCircleIcon"]],
  standalone: true,
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵStandaloneFeature"]],
  decls: 6,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["clip-path", "url(#clip0_334_13179)"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M7 14C5.61553 14 4.26215 13.5895 3.11101 12.8203C1.95987 12.0511 1.06266 10.9579 0.532846 9.67879C0.00303296 8.3997 -0.13559 6.99224 0.134506 5.63437C0.404603 4.2765 1.07129 3.02922 2.05026 2.05026C3.02922 1.07129 4.2765 0.404603 5.63437 0.134506C6.99224 -0.13559 8.3997 0.00303296 9.67879 0.532846C10.9579 1.06266 12.0511 1.95987 12.8203 3.11101C13.5895 4.26215 14 5.61553 14 7C14 8.85652 13.2625 10.637 11.9497 11.9497C10.637 13.2625 8.85652 14 7 14ZM7 1.16667C5.84628 1.16667 4.71846 1.50879 3.75918 2.14976C2.79989 2.79074 2.05222 3.70178 1.61071 4.76768C1.16919 5.83358 1.05367 7.00647 1.27876 8.13803C1.50384 9.26958 2.05941 10.309 2.87521 11.1248C3.69102 11.9406 4.73042 12.4962 5.86198 12.7212C6.99353 12.9463 8.16642 12.8308 9.23232 12.3893C10.2982 11.9478 11.2093 11.2001 11.8502 10.2408C12.4912 9.28154 12.8333 8.15373 12.8333 7C12.8333 5.45291 12.2188 3.96918 11.1248 2.87521C10.0308 1.78125 8.5471 1.16667 7 1.16667ZM4.66662 9.91668C4.58998 9.91704 4.51404 9.90209 4.44325 9.87271C4.37246 9.84333 4.30826 9.8001 4.2544 9.74557C4.14516 9.6362 4.0838 9.48793 4.0838 9.33335C4.0838 9.17876 4.14516 9.0305 4.2544 8.92113L6.17553 7L4.25443 5.07891C4.15139 4.96832 4.09529 4.82207 4.09796 4.67094C4.10063 4.51982 4.16185 4.37563 4.26872 4.26876C4.3756 4.16188 4.51979 4.10066 4.67091 4.09799C4.82204 4.09532 4.96829 4.15142 5.07887 4.25446L6.99997 6.17556L8.92106 4.25446C9.03164 4.15142 9.1779 4.09532 9.32903 4.09799C9.48015 4.10066 9.62434 4.16188 9.73121 4.26876C9.83809 4.37563 9.89931 4.51982 9.90198 4.67094C9.90464 4.82207 9.84855 4.96832 9.74551 5.07891L7.82441 7L9.74554 8.92113C9.85478 9.0305 9.91614 9.17876 9.91614 9.33335C9.91614 9.48793 9.85478 9.6362 9.74554 9.74557C9.69168 9.8001 9.62748 9.84333 9.55669 9.87271C9.4859 9.90209 9.40996 9.91704 9.33332 9.91668C9.25668 9.91704 9.18073 9.90209 9.10995 9.87271C9.03916 9.84333 8.97495 9.8001 8.9211 9.74557L6.99997 7.82444L5.07884 9.74557C5.02499 9.8001 4.96078 9.84333 4.88999 9.87271C4.81921 9.90209 4.74326 9.91704 4.66662 9.91668Z", "fill", "currentColor"], ["id", "clip0_334_13179"], ["width", "14", "height", "14", "fill", "white"]],
  template: function TimesCircleIcon_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "svg", 0)(1, "g", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "path", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "defs")(4, "clipPath", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "rect", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassMap"](ctx.getClassNames());
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](TimesCircleIcon, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Component,
    args: [{
      selector: 'TimesCircleIcon',
      standalone: true,
      imports: [primeng_baseicon__WEBPACK_IMPORTED_MODULE_0__.BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g clip-path="url(#clip0_334_13179)">
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M7 14C5.61553 14 4.26215 13.5895 3.11101 12.8203C1.95987 12.0511 1.06266 10.9579 0.532846 9.67879C0.00303296 8.3997 -0.13559 6.99224 0.134506 5.63437C0.404603 4.2765 1.07129 3.02922 2.05026 2.05026C3.02922 1.07129 4.2765 0.404603 5.63437 0.134506C6.99224 -0.13559 8.3997 0.00303296 9.67879 0.532846C10.9579 1.06266 12.0511 1.95987 12.8203 3.11101C13.5895 4.26215 14 5.61553 14 7C14 8.85652 13.2625 10.637 11.9497 11.9497C10.637 13.2625 8.85652 14 7 14ZM7 1.16667C5.84628 1.16667 4.71846 1.50879 3.75918 2.14976C2.79989 2.79074 2.05222 3.70178 1.61071 4.76768C1.16919 5.83358 1.05367 7.00647 1.27876 8.13803C1.50384 9.26958 2.05941 10.309 2.87521 11.1248C3.69102 11.9406 4.73042 12.4962 5.86198 12.7212C6.99353 12.9463 8.16642 12.8308 9.23232 12.3893C10.2982 11.9478 11.2093 11.2001 11.8502 10.2408C12.4912 9.28154 12.8333 8.15373 12.8333 7C12.8333 5.45291 12.2188 3.96918 11.1248 2.87521C10.0308 1.78125 8.5471 1.16667 7 1.16667ZM4.66662 9.91668C4.58998 9.91704 4.51404 9.90209 4.44325 9.87271C4.37246 9.84333 4.30826 9.8001 4.2544 9.74557C4.14516 9.6362 4.0838 9.48793 4.0838 9.33335C4.0838 9.17876 4.14516 9.0305 4.2544 8.92113L6.17553 7L4.25443 5.07891C4.15139 4.96832 4.09529 4.82207 4.09796 4.67094C4.10063 4.51982 4.16185 4.37563 4.26872 4.26876C4.3756 4.16188 4.51979 4.10066 4.67091 4.09799C4.82204 4.09532 4.96829 4.15142 5.07887 4.25446L6.99997 6.17556L8.92106 4.25446C9.03164 4.15142 9.1779 4.09532 9.32903 4.09799C9.48015 4.10066 9.62434 4.16188 9.73121 4.26876C9.83809 4.37563 9.89931 4.51982 9.90198 4.67094C9.90464 4.82207 9.84855 4.96832 9.74551 5.07891L7.82441 7L9.74554 8.92113C9.85478 9.0305 9.91614 9.17876 9.91614 9.33335C9.91614 9.48793 9.85478 9.6362 9.74554 9.74557C9.69168 9.8001 9.62748 9.84333 9.55669 9.87271C9.4859 9.90209 9.40996 9.91704 9.33332 9.91668C9.25668 9.91704 9.18073 9.90209 9.10995 9.87271C9.03916 9.84333 8.97495 9.8001 8.9211 9.74557L6.99997 7.82444L5.07884 9.74557C5.02499 9.8001 4.96078 9.84333 4.88999 9.87271C4.81921 9.90209 4.74326 9.91704 4.66662 9.91668Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath id="clip0_334_13179">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-icons-timescircle.mjs.map

/***/ }),

/***/ 88395:
/*!***************************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-progressbar.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgressBar": () => (/* binding */ ProgressBar),
/* harmony export */   "ProgressBarModule": () => (/* binding */ ProgressBarModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);




function ProgressBar_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", ctx_r2.value != null && ctx_r2.value !== 0 ? "flex" : "none");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", ctx_r2.value, "", ctx_r2.unit, "");
  }
}
function ProgressBar_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ProgressBar_div_1_div_1_Template, 2, 4, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx_r0.value + "%")("background", ctx_r0.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.showValue);
  }
}
function ProgressBar_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("background", ctx_r1.color);
  }
}
const _c0 = function (a1, a2) {
  return {
    "p-progressbar p-component": true,
    "p-progressbar-determinate": a1,
    "p-progressbar-indeterminate": a2
  };
};
class ProgressBar {
  constructor() {
    this.showValue = true;
    this.unit = '%';
    this.mode = 'determinate';
  }
}
ProgressBar.ɵfac = function ProgressBar_Factory(t) {
  return new (t || ProgressBar)();
};
ProgressBar.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: ProgressBar,
  selectors: [["p-progressBar"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    value: "value",
    showValue: "showValue",
    style: "style",
    styleClass: "styleClass",
    unit: "unit",
    mode: "mode",
    color: "color"
  },
  decls: 3,
  vars: 10,
  consts: [["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", 3, "ngStyle", "ngClass"], ["class", "p-progressbar-value p-progressbar-value-animate", "style", "display:flex", 3, "width", "background", 4, "ngIf"], ["class", "p-progressbar-indeterminate-container", 4, "ngIf"], [1, "p-progressbar-value", "p-progressbar-value-animate", 2, "display", "flex"], ["class", "p-progressbar-label", 3, "display", 4, "ngIf"], [1, "p-progressbar-label"], [1, "p-progressbar-indeterminate-container"], [1, "p-progressbar-value", "p-progressbar-value-animate"]],
  template: function ProgressBar_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ProgressBar_div_1_Template, 2, 5, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ProgressBar_div_2_Template, 2, 2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.styleClass);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", ctx.style)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c0, ctx.mode === "determinate", ctx.mode === "indeterminate"));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-valuenow", ctx.value);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.mode === "determinate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.mode === "indeterminate");
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgStyle],
  styles: [".p-progressbar{position:relative;overflow:hidden}.p-progressbar-determinate .p-progressbar-value{height:100%;width:0%;position:absolute;display:none;border:0 none;display:flex;align-items:center;justify-content:center;overflow:hidden}.p-progressbar-determinate .p-progressbar-label{display:inline-flex}.p-progressbar-determinate .p-progressbar-value-animate{transition:width 1s ease-in-out}.p-progressbar-indeterminate .p-progressbar-value:before{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim 2.1s cubic-bezier(.65,.815,.735,.395) infinite}.p-progressbar-indeterminate .p-progressbar-value:after{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(.165,.84,.44,1) infinite;animation-delay:1.15s}@keyframes p-progressbar-indeterminate-anim{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}@keyframes p-progressbar-indeterminate-anim-short{0%{left:-200%;right:100%}60%{left:107%;right:-8%}to{left:107%;right:-8%}}\n"],
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ProgressBar, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-progressBar',
      template: `
        <div
            [class]="styleClass"
            [ngStyle]="style"
            role="progressbar"
            aria-valuemin="0"
            [attr.aria-valuenow]="value"
            aria-valuemax="100"
            [ngClass]="{ 'p-progressbar p-component': true, 'p-progressbar-determinate': mode === 'determinate', 'p-progressbar-indeterminate': mode === 'indeterminate' }"
        >
            <div *ngIf="mode === 'determinate'" class="p-progressbar-value p-progressbar-value-animate" [style.width]="value + '%'" style="display:flex" [style.background]="color">
                <div *ngIf="showValue" class="p-progressbar-label" [style.display]="value != null && value !== 0 ? 'flex' : 'none'">{{ value }}{{ unit }}</div>
            </div>
            <div *ngIf="mode === 'indeterminate'" class="p-progressbar-indeterminate-container">
                <div class="p-progressbar-value p-progressbar-value-animate" [style.background]="color"></div>
            </div>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-progressbar{position:relative;overflow:hidden}.p-progressbar-determinate .p-progressbar-value{height:100%;width:0%;position:absolute;display:none;border:0 none;display:flex;align-items:center;justify-content:center;overflow:hidden}.p-progressbar-determinate .p-progressbar-label{display:inline-flex}.p-progressbar-determinate .p-progressbar-value-animate{transition:width 1s ease-in-out}.p-progressbar-indeterminate .p-progressbar-value:before{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim 2.1s cubic-bezier(.65,.815,.735,.395) infinite}.p-progressbar-indeterminate .p-progressbar-value:after{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(.165,.84,.44,1) infinite;animation-delay:1.15s}@keyframes p-progressbar-indeterminate-anim{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}@keyframes p-progressbar-indeterminate-anim-short{0%{left:-200%;right:100%}60%{left:107%;right:-8%}to{left:107%;right:-8%}}\n"]
    }]
  }], null, {
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showValue: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    unit: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    mode: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    color: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class ProgressBarModule {}
ProgressBarModule.ɵfac = function ProgressBarModule_Factory(t) {
  return new (t || ProgressBarModule)();
};
ProgressBarModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: ProgressBarModule
});
ProgressBarModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ProgressBarModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule],
      exports: [ProgressBar],
      declarations: [ProgressBar]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-progressbar.mjs.map

/***/ }),

/***/ 29129:
/*!*********************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-toast.mjs ***!
  \*********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Toast": () => (/* binding */ Toast),
/* harmony export */   "ToastItem": () => (/* binding */ ToastItem),
/* harmony export */   "ToastModule": () => (/* binding */ ToastModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/api */ 14356);
/* harmony import */ var primeng_utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/utils */ 68549);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/ripple */ 84538);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/animations */ 24851);
/* harmony import */ var primeng_icons_check__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/icons/check */ 80736);
/* harmony import */ var primeng_icons_infocircle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/icons/infocircle */ 86194);
/* harmony import */ var primeng_icons_timescircle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/icons/timescircle */ 66195);
/* harmony import */ var primeng_icons_exclamationtriangle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/icons/exclamationtriangle */ 81938);
/* harmony import */ var primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/icons/times */ 59696);















const _c0 = ["container"];
function ToastItem_ng_container_3_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span");
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"]("p-toast-message-icon pi " + ctx_r4.message.icon);
  }
}
function ToastItem_ng_container_3_span_2_CheckIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "CheckIcon");
  }
}
function ToastItem_ng_container_3_span_2_InfoCircleIcon_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "InfoCircleIcon");
  }
}
function ToastItem_ng_container_3_span_2_TimesCircleIcon_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "TimesCircleIcon");
  }
}
function ToastItem_ng_container_3_span_2_ExclamationTriangleIcon_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ExclamationTriangleIcon");
  }
}
function ToastItem_ng_container_3_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ToastItem_ng_container_3_span_2_CheckIcon_2_Template, 1, 0, "CheckIcon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ToastItem_ng_container_3_span_2_InfoCircleIcon_3_Template, 1, 0, "InfoCircleIcon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, ToastItem_ng_container_3_span_2_TimesCircleIcon_4_Template, 1, 0, "TimesCircleIcon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, ToastItem_ng_container_3_span_2_ExclamationTriangleIcon_5_Template, 1, 0, "ExclamationTriangleIcon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.message.severity === "success");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.message.severity === "info");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.message.severity === "error");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r5.message.severity === "warn");
  }
}
function ToastItem_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ToastItem_ng_container_3_span_1_Template, 1, 2, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ToastItem_ng_container_3_span_2_Template, 6, 4, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 8)(4, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r1.message.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r1.message.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r1.message.summary);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r1.message.detail);
  }
}
function ToastItem_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function ToastItem_button_5_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span");
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"]("p-toast-message-icon pi " + ctx_r10.message.closeIcon);
  }
}
function ToastItem_button_5_TimesIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "TimesIcon", 14);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("styleClass", "p-toast-icon-close-icon");
  }
}
function ToastItem_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ToastItem_button_5_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r12.onCloseIconClick($event));
    })("keydown.enter", function ToastItem_button_5_Template_button_keydown_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r14.onCloseIconClick($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ToastItem_button_5_span_1_Template, 1, 2, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ToastItem_button_5_TimesIcon_2_Template, 1, 1, "TimesIcon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r3.message.closeIcon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r3.message.closeIcon);
  }
}
const _c1 = function (a0) {
  return [a0, "p-toast-message"];
};
const _c2 = function (a0, a1, a2, a3) {
  return {
    showTransformParams: a0,
    hideTransformParams: a1,
    showTransitionParams: a2,
    hideTransitionParams: a3
  };
};
const _c3 = function (a1) {
  return {
    value: "visible",
    params: a1
  };
};
const _c4 = function (a0) {
  return {
    $implicit: a0
  };
};
function Toast_p_toastItem_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p-toastItem", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("onClose", function Toast_p_toastItem_2_Template_p_toastItem_onClose_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r4.onMessageClose($event));
    })("@toastAnimation.start", function Toast_p_toastItem_2_Template_p_toastItem_animation_toastAnimation_start_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r6.onAnimationStart($event));
    })("@toastAnimation.done", function Toast_p_toastItem_2_Template_p_toastItem_animation_toastAnimation_done_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r7.onAnimationEnd($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const msg_r2 = ctx.$implicit;
    const i_r3 = ctx.index;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("message", msg_r2)("index", i_r3)("template", ctx_r1.template)("@toastAnimation", undefined)("showTransformOptions", ctx_r1.showTransformOptions)("hideTransformOptions", ctx_r1.hideTransformOptions)("showTransitionOptions", ctx_r1.showTransitionOptions)("hideTransitionOptions", ctx_r1.hideTransitionOptions);
  }
}
class ToastItem {
  constructor(zone) {
    this.zone = zone;
    this.onClose = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  ngAfterViewInit() {
    this.initTimeout();
  }
  initTimeout() {
    if (!this.message.sticky) {
      this.zone.runOutsideAngular(() => {
        this.timeout = setTimeout(() => {
          this.onClose.emit({
            index: this.index,
            message: this.message
          });
        }, this.message.life || 3000);
      });
    }
  }
  clearTimeout() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
  }
  onMouseEnter() {
    this.clearTimeout();
  }
  onMouseLeave() {
    this.initTimeout();
  }
  onCloseIconClick(event) {
    this.clearTimeout();
    this.onClose.emit({
      index: this.index,
      message: this.message
    });
    event.preventDefault();
  }
  ngOnDestroy() {
    this.clearTimeout();
  }
}
ToastItem.ɵfac = function ToastItem_Factory(t) {
  return new (t || ToastItem)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone));
};
ToastItem.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: ToastItem,
  selectors: [["p-toastItem"]],
  viewQuery: function ToastItem_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.containerViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    message: "message",
    index: "index",
    template: "template",
    showTransformOptions: "showTransformOptions",
    hideTransformOptions: "hideTransformOptions",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions"
  },
  outputs: {
    onClose: "onClose"
  },
  decls: 6,
  vars: 21,
  consts: [[3, "ngClass", "mouseenter", "mouseleave"], ["container", ""], ["role", "alert", "aria-live", "assertive", "aria-atomic", "true", 1, "p-toast-message-content", 3, "ngClass"], [4, "ngIf"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["type", "button", "class", "p-toast-icon-close p-link", "pRipple", "", 3, "click", "keydown.enter", 4, "ngIf"], [3, "class", 4, "ngIf"], ["class", "p-toast-message-icon", 4, "ngIf"], [1, "p-toast-message-text"], [1, "p-toast-summary"], [1, "p-toast-detail"], [1, "p-toast-message-icon"], ["type", "button", "pRipple", "", 1, "p-toast-icon-close", "p-link", 3, "click", "keydown.enter"], [3, "styleClass", 4, "ngIf"], [3, "styleClass"]],
  template: function ToastItem_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("mouseenter", function ToastItem_Template_div_mouseenter_0_listener() {
        return ctx.onMouseEnter();
      })("mouseleave", function ToastItem_Template_div_mouseleave_0_listener() {
        return ctx.onMouseLeave();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ToastItem_ng_container_3_Template, 8, 4, "ng-container", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, ToastItem_ng_container_4_Template, 1, 0, "ng-container", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, ToastItem_button_5_Template, 3, 2, "button", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.message.styleClass);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](10, _c1, "p-toast-message-" + ctx.message.severity))("@messageState", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](17, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction4"](12, _c2, ctx.showTransformOptions, ctx.hideTransformOptions, ctx.showTransitionOptions, ctx.hideTransitionOptions)));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("id", ctx.message.id);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx.message.contentStyleClass);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.template);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx.template)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](19, _c4, ctx.message));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.message.closable !== false);
    }
  },
  dependencies: function () {
    return [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgTemplateOutlet, primeng_ripple__WEBPACK_IMPORTED_MODULE_2__.Ripple, primeng_icons_check__WEBPACK_IMPORTED_MODULE_3__.CheckIcon, primeng_icons_infocircle__WEBPACK_IMPORTED_MODULE_4__.InfoCircleIcon, primeng_icons_timescircle__WEBPACK_IMPORTED_MODULE_5__.TimesCircleIcon, primeng_icons_exclamationtriangle__WEBPACK_IMPORTED_MODULE_6__.ExclamationTriangleIcon, primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__.TimesIcon];
  },
  encapsulation: 2,
  data: {
    animation: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.trigger)('messageState', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.state)('visible', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
      transform: 'translateY(0)',
      opacity: 1
    })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)('void => *', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
      transform: '{{showTransformParams}}',
      opacity: 0
    }), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animate)('{{showTransitionParams}}')]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)('* => void', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animate)('{{hideTransitionParams}}', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
      height: 0,
      opacity: 0,
      transform: '{{hideTransformParams}}'
    }))])])]
  },
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ToastItem, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-toastItem',
      template: `
        <div
            #container
            [attr.id]="message.id"
            [class]="message.styleClass"
            [ngClass]="['p-toast-message-' + message.severity, 'p-toast-message']"
            [@messageState]="{ value: 'visible', params: { showTransformParams: showTransformOptions, hideTransformParams: hideTransformOptions, showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions } }"
            (mouseenter)="onMouseEnter()"
            (mouseleave)="onMouseLeave()"
        >
            <div class="p-toast-message-content" role="alert" aria-live="assertive" aria-atomic="true" [ngClass]="message.contentStyleClass">
                <ng-container *ngIf="!template">
                    <span
                        *ngIf="message.icon"
                        [class]="'p-toast-message-icon pi ' + message.icon"
                    ></span>
                    <span class="p-toast-message-icon" *ngIf="!message.icon">
                        <ng-container>
                            <CheckIcon *ngIf="message.severity === 'success'"/>
                            <InfoCircleIcon *ngIf="message.severity === 'info'"/>
                            <TimesCircleIcon *ngIf="message.severity === 'error'"/>
                            <ExclamationTriangleIcon *ngIf="message.severity === 'warn'"/>
                        </ng-container>
                    </span>
                    <div class="p-toast-message-text">
                        <div class="p-toast-summary">{{ message.summary }}</div>
                        <div class="p-toast-detail">{{ message.detail }}</div>
                    </div>
                </ng-container>
                <ng-container *ngTemplateOutlet="template; context: { $implicit: message }"></ng-container>
                <button type="button" class="p-toast-icon-close p-link" (click)="onCloseIconClick($event)" (keydown.enter)="onCloseIconClick($event)" *ngIf="message.closable !== false" pRipple>
                    <span
                        *ngIf="message.closeIcon"
                        [class]="'p-toast-message-icon pi ' + message.closeIcon"
                    ></span>
                    <TimesIcon *ngIf="!message.closeIcon" [styleClass]="'p-toast-icon-close-icon'"/>
                </button>
            </div>
        </div>
    `,
      animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.trigger)('messageState', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.state)('visible', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
        transform: 'translateY(0)',
        opacity: 1
      })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)('void => *', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
        transform: '{{showTransformParams}}',
        opacity: 0
      }), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animate)('{{showTransitionParams}}')]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)('* => void', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animate)('{{hideTransitionParams}}', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.style)({
        height: 0,
        opacity: 0,
        transform: '{{hideTransformParams}}'
      }))])])],
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      host: {
        class: 'p-element'
      }
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone
    }];
  }, {
    message: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    index: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    template: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showTransformOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    hideTransformOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    hideTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    onClose: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    containerViewChild: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['container']
    }]
  });
})();
class Toast {
  constructor(document, renderer, messageService, cd, config) {
    this.document = document;
    this.renderer = renderer;
    this.messageService = messageService;
    this.cd = cd;
    this.config = config;
    this.autoZIndex = true;
    this.baseZIndex = 0;
    this.position = 'top-right';
    this.preventOpenDuplicates = false;
    this.preventDuplicates = false;
    this.showTransformOptions = 'translateY(100%)';
    this.hideTransformOptions = 'translateY(-100%)';
    this.showTransitionOptions = '300ms ease-out';
    this.hideTransitionOptions = '250ms ease-in';
    this.onClose = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.id = (0,primeng_utils__WEBPACK_IMPORTED_MODULE_9__.UniqueComponentId)();
  }
  ngOnInit() {
    this.messageSubscription = this.messageService.messageObserver.subscribe(messages => {
      if (messages) {
        if (Array.isArray(messages)) {
          const filteredMessages = messages.filter(m => this.canAdd(m));
          this.add(filteredMessages);
        } else if (this.canAdd(messages)) {
          this.add([messages]);
        }
      }
    });
    this.clearSubscription = this.messageService.clearObserver.subscribe(key => {
      if (key) {
        if (this.key === key) {
          this.messages = null;
        }
      } else {
        this.messages = null;
      }
      this.cd.markForCheck();
    });
  }
  ngAfterViewInit() {
    if (this.breakpoints) {
      this.createStyle();
    }
  }
  add(messages) {
    this.messages = this.messages ? [...this.messages, ...messages] : [...messages];
    if (this.preventDuplicates) {
      this.messagesArchieve = this.messagesArchieve ? [...this.messagesArchieve, ...messages] : [...messages];
    }
    this.cd.markForCheck();
  }
  canAdd(message) {
    let allow = this.key === message.key;
    if (allow && this.preventOpenDuplicates) {
      allow = !this.containsMessage(this.messages, message);
    }
    if (allow && this.preventDuplicates) {
      allow = !this.containsMessage(this.messagesArchieve, message);
    }
    return allow;
  }
  containsMessage(collection, message) {
    if (!collection) {
      return false;
    }
    return collection.find(m => {
      return m.summary === message.summary && m.detail == message.detail && m.severity === message.severity;
    }) != null;
  }
  ngAfterContentInit() {
    this.templates.forEach(item => {
      switch (item.getType()) {
        case 'message':
          this.template = item.template;
          break;
        default:
          this.template = item.template;
          break;
      }
    });
  }
  onMessageClose(event) {
    this.messages.splice(event.index, 1);
    this.onClose.emit({
      message: event.message
    });
    this.cd.detectChanges();
  }
  onAnimationStart(event) {
    if (event.fromState === 'void') {
      this.renderer.setAttribute(this.containerViewChild.nativeElement, this.id, '');
      if (this.autoZIndex && this.containerViewChild.nativeElement.style.zIndex === '') {
        primeng_utils__WEBPACK_IMPORTED_MODULE_9__.ZIndexUtils.set('modal', this.containerViewChild.nativeElement, this.baseZIndex || this.config.zIndex.modal);
      }
    }
  }
  onAnimationEnd(event) {
    if (event.toState === 'void') {
      if (this.autoZIndex && primeng_utils__WEBPACK_IMPORTED_MODULE_9__.ObjectUtils.isEmpty(this.messages)) {
        primeng_utils__WEBPACK_IMPORTED_MODULE_9__.ZIndexUtils.clear(this.containerViewChild.nativeElement);
      }
    }
  }
  createStyle() {
    if (!this.styleElement) {
      this.styleElement = this.renderer.createElement('style');
      this.styleElement.type = 'text/css';
      this.renderer.appendChild(this.document.head, this.styleElement);
      let innerHTML = '';
      for (let breakpoint in this.breakpoints) {
        let breakpointStyle = '';
        for (let styleProp in this.breakpoints[breakpoint]) {
          breakpointStyle += styleProp + ':' + this.breakpoints[breakpoint][styleProp] + ' !important;';
        }
        innerHTML += `
                    @media screen and (max-width: ${breakpoint}) {
                        .p-toast[${this.id}] {
                           ${breakpointStyle}
                        }
                    }
                `;
      }
      this.renderer.setProperty(this.styleElement, 'innerHTML', innerHTML);
    }
  }
  destroyStyle() {
    if (this.styleElement) {
      this.renderer.removeChild(this.document.head, this.styleElement);
      this.styleElement = null;
    }
  }
  ngOnDestroy() {
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
    if (this.containerViewChild && this.autoZIndex) {
      primeng_utils__WEBPACK_IMPORTED_MODULE_9__.ZIndexUtils.clear(this.containerViewChild.nativeElement);
    }
    if (this.clearSubscription) {
      this.clearSubscription.unsubscribe();
    }
    this.destroyStyle();
  }
}
Toast.ɵfac = function Toast_Factory(t) {
  return new (t || Toast)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_1__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_10__.PrimeNGConfig));
};
Toast.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: Toast,
  selectors: [["p-toast"]],
  contentQueries: function Toast_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, primeng_api__WEBPACK_IMPORTED_MODULE_10__.PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Toast_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.containerViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    key: "key",
    autoZIndex: "autoZIndex",
    baseZIndex: "baseZIndex",
    style: "style",
    styleClass: "styleClass",
    position: "position",
    preventOpenDuplicates: "preventOpenDuplicates",
    preventDuplicates: "preventDuplicates",
    showTransformOptions: "showTransformOptions",
    hideTransformOptions: "hideTransformOptions",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions",
    breakpoints: "breakpoints"
  },
  outputs: {
    onClose: "onClose"
  },
  decls: 3,
  vars: 5,
  consts: [[3, "ngClass", "ngStyle"], ["container", ""], [3, "message", "index", "template", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "onClose", 4, "ngFor", "ngForOf"], [3, "message", "index", "template", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "onClose"]],
  template: function Toast_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0, 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, Toast_p_toastItem_2_Template, 1, 8, "p-toastItem", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.styleClass);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "p-toast p-component p-toast-" + ctx.position)("ngStyle", ctx.style);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.messages);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgStyle, ToastItem],
  styles: [".p-toast{position:fixed;width:25rem}.p-toast-message{overflow:hidden}.p-toast-message-content{display:flex;align-items:flex-start}.p-toast-message-text{flex:1 1 auto}.p-toast-top-right{top:20px;right:20px}.p-toast-top-left{top:20px;left:20px}.p-toast-bottom-left{bottom:20px;left:20px}.p-toast-bottom-right{bottom:20px;right:20px}.p-toast-top-center{top:20px;left:50%;transform:translate(-50%)}.p-toast-bottom-center{bottom:20px;left:50%;transform:translate(-50%)}.p-toast-center{left:50%;top:50%;min-width:20vw;transform:translate(-50%,-50%)}.p-toast-icon-close{display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative}.p-toast-icon-close.p-link{cursor:pointer}\n"],
  encapsulation: 2,
  data: {
    animation: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.trigger)('toastAnimation', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)(':enter, :leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.query)('@*', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animateChild)())])])]
  },
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Toast, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-toast',
      template: `
        <div #container [ngClass]="'p-toast p-component p-toast-' + position" [ngStyle]="style" [class]="styleClass">
            <p-toastItem
                *ngFor="let msg of messages; let i = index"
                [message]="msg"
                [index]="i"
                (onClose)="onMessageClose($event)"
                [template]="template"
                @toastAnimation
                (@toastAnimation.start)="onAnimationStart($event)"
                (@toastAnimation.done)="onAnimationEnd($event)"
                [showTransformOptions]="showTransformOptions"
                [hideTransformOptions]="hideTransformOptions"
                [showTransitionOptions]="showTransitionOptions"
                [hideTransitionOptions]="hideTransitionOptions"
            ></p-toastItem>
        </div>
    `,
      animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.trigger)('toastAnimation', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.transition)(':enter, :leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.query)('@*', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_8__.animateChild)())])])],
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-toast{position:fixed;width:25rem}.p-toast-message{overflow:hidden}.p-toast-message-content{display:flex;align-items:flex-start}.p-toast-message-text{flex:1 1 auto}.p-toast-top-right{top:20px;right:20px}.p-toast-top-left{top:20px;left:20px}.p-toast-bottom-left{bottom:20px;left:20px}.p-toast-bottom-right{bottom:20px;right:20px}.p-toast-top-center{top:20px;left:50%;transform:translate(-50%)}.p-toast-bottom-center{bottom:20px;left:50%;transform:translate(-50%)}.p-toast-center{left:50%;top:50%;min-width:20vw;transform:translate(-50%,-50%)}.p-toast-icon-close{display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative}.p-toast-icon-close.p-link{cursor:pointer}\n"]
    }]
  }], function () {
    return [{
      type: Document,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.DOCUMENT]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2
    }, {
      type: primeng_api__WEBPACK_IMPORTED_MODULE_10__.MessageService
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }, {
      type: primeng_api__WEBPACK_IMPORTED_MODULE_10__.PrimeNGConfig
    }];
  }, {
    key: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    autoZIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    baseZIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    position: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    preventOpenDuplicates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    preventDuplicates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showTransformOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    hideTransformOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    hideTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    breakpoints: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    onClose: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    containerViewChild: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['container']
    }],
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [primeng_api__WEBPACK_IMPORTED_MODULE_10__.PrimeTemplate]
    }]
  });
})();
class ToastModule {}
ToastModule.ɵfac = function ToastModule_Factory(t) {
  return new (t || ToastModule)();
};
ToastModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: ToastModule
});
ToastModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_2__.RippleModule, primeng_icons_check__WEBPACK_IMPORTED_MODULE_3__.CheckIcon, primeng_icons_infocircle__WEBPACK_IMPORTED_MODULE_4__.InfoCircleIcon, primeng_icons_timescircle__WEBPACK_IMPORTED_MODULE_5__.TimesCircleIcon, primeng_icons_exclamationtriangle__WEBPACK_IMPORTED_MODULE_6__.ExclamationTriangleIcon, primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__.TimesIcon, primeng_api__WEBPACK_IMPORTED_MODULE_10__.SharedModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ToastModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_2__.RippleModule, primeng_icons_check__WEBPACK_IMPORTED_MODULE_3__.CheckIcon, primeng_icons_infocircle__WEBPACK_IMPORTED_MODULE_4__.InfoCircleIcon, primeng_icons_timescircle__WEBPACK_IMPORTED_MODULE_5__.TimesCircleIcon, primeng_icons_exclamationtriangle__WEBPACK_IMPORTED_MODULE_6__.ExclamationTriangleIcon, primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__.TimesIcon],
      exports: [Toast, primeng_api__WEBPACK_IMPORTED_MODULE_10__.SharedModule],
      declarations: [Toast, ToastItem]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-toast.mjs.map

/***/ })

}]);
//# sourceMappingURL=473.dbf3892ae2a250f5.js.map