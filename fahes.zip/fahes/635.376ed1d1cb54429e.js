"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[635],{

/***/ 73874:
/*!****************************************************!*\
  !*** ./src/app/core/models/add-vehicle-details.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddVehicleDetails": () => (/* binding */ AddVehicleDetails)
/* harmony export */ });
class AddVehicleDetails {
  constructor(vehicledetails, phone, area, location, vcategory, cost) {
    this.vdetails = vehicledetails;
    this.phone = phone;
    this.area = area;
    this.location = location;
    this.vCategoryText = vcategory;
    this.cost = cost;
  }
}

/***/ }),

/***/ 69537:
/*!*********************************************************!*\
  !*** ./src/app/core/models/insert-vehicle-equipment.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InsertExternalEquipment": () => (/* binding */ InsertExternalEquipment)
/* harmony export */ });
class InsertExternalEquipment {
  constructor(details) {
    Object.assign(this, details);
  }
}

/***/ }),

/***/ 83439:
/*!*****************************************!*\
  !*** ./src/app/core/models/location.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Locations": () => (/* binding */ Locations)
/* harmony export */ });
class Locations {
  constructor(locId, locName, areaId) {
    this.locationId = locId;
    this.locationName = locName;
    this.areaId = areaId;
  }
}

/***/ }),

/***/ 43347:
/*!************************************************!*\
  !*** ./src/app/core/models/vehicle-details.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleDetails": () => (/* binding */ VehicleDetails)
/* harmony export */ });
class VehicleDetails {
  constructor(PlateNo, PlateType, VINNo, ColorId, SubColorId, CategoryId, VehicleModelId, ManufacturerId, ManufacturerYear, MOIRegistrationDate, Cylinders, Weight, PayloadWeight, ShapeCode, NoOfSeat, OwnerPID, OwnerName, LicenseExpiryDate, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, ModelEname, ManufacturersEname, IsValidStation, IsStaffVehicle, IsWaqodVehicle, IsReinspection, noOfReinspections) {
    this.plateNo = PlateNo;
    this.plateType = PlateType;
    this.vinNo = VINNo;
    this.colorId = ColorId;
    this.subColorId = SubColorId;
    this.categoryId = CategoryId;
    this.vehicleModelId = VehicleModelId;
    this.manufacturerId = ManufacturerId;
    this.manufacturerYear = ManufacturerYear;
    this.moiRegistrationDate = MOIRegistrationDate;
    this.cylinders = Cylinders;
    this.weight = Weight;
    this.payloadWeight = PayloadWeight;
    this.shapeCode = ShapeCode;
    this.noOfSeat = NoOfSeat;
    this.ownerPID = OwnerPID;
    this.ownerName = OwnerName;
    this.licenseExpiryDate = LicenseExpiryDate;
    this.createdBy = CreatedBy;
    this.createdDate = CreatedDate;
    this.updatedBy = UpdatedBy;
    this.updatedDate = UpdatedDate;
    this.modelEname = ModelEname;
    this.manufacturersEname = ManufacturersEname;
    this.isValidStation = IsValidStation;
    this.isStaffVehicle = IsStaffVehicle;
    this.isWaqodVehicle = IsWaqodVehicle;
    this.isReinspection = IsReinspection;
    this.noOfReinspections = noOfReinspections;
  }
}

/***/ }),

/***/ 59212:
/*!*******************************************************!*\
  !*** ./src/app/core/services/registration.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistrationService": () => (/* binding */ RegistrationService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 58987);



class RegistrationService {
  constructor(http) {
    this.http = http;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Registration/v1';
  }
  createServiceRequest(serviceRequest) {
    return this.http.post(`${this.baseUrl}/${this.apiUrl}/insertServiceRequest`, serviceRequest);
  }
  submitMobileBooking(mobileBookingRequest) {
    return this.http.post(`${this.baseUrl}/${this.apiUrl}/submitMobileBooking`, mobileBookingRequest);
  }
  getInspectionServiceTypes(classificationId) {
    return this.http.post(`${this.baseUrl}/${this.apiUrl}/getInspectionServiceTypes`, {
      classificationId: classificationId
    });
  }
  static #_ = this.ɵfac = function RegistrationService_Factory(t) {
    return new (t || RegistrationService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: RegistrationService,
    factory: RegistrationService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 46949:
/*!*************************************************************************************!*\
  !*** ./src/app/core/utilities/enums/inspection-service-type-classification.rnum.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceTypeClassifications": () => (/* binding */ ServiceTypeClassifications)
/* harmony export */ });
var ServiceTypeClassifications;
(function (ServiceTypeClassifications) {
  ServiceTypeClassifications[ServiceTypeClassifications["Internal"] = 1] = "Internal";
  ServiceTypeClassifications[ServiceTypeClassifications["External"] = 2] = "External";
})(ServiceTypeClassifications || (ServiceTypeClassifications = {}));

/***/ }),

/***/ 32169:
/*!************************************************************!*\
  !*** ./src/app/modules/backoffice/backoffice.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackofficeComponent": () => (/* binding */ BackofficeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 60124);



class BackofficeComponent {
  constructor(sideNav) {
    this.sideNav = sideNav;
  }
  ngOnInit() {
    this.sideNav.setHeaderValue(false, true);
  }
  static #_ = this.ɵfac = function BackofficeComponent_Factory(t) {
    return new (t || BackofficeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_0__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: BackofficeComponent,
    selectors: [["app-backoffice"]],
    decls: 1,
    vars: 0,
    template: function BackofficeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterOutlet],
    styles: [".custom-select[_ngcontent-%COMP%] {\n    background-color: #448b23;\n    border: 1px solid rgb(54, 52, 52);\n}\n\n[_nghost-%COMP%]     ng-select.ng-select.custom-dp .ng-dropdown-panel .ng-dropdown-panel-items {\n    border: 0.2px solid rgb(54, 52, 52);\n    background-color: white;\n    padding-left: 15px;\n}\n\n.custom-option[_ngcontent-%COMP%] {\n    color: #333;\n    cursor: pointer;\n    background-color: white;\n    padding-top: 5px;\n}\n\n.custom-option[_ngcontent-%COMP%]:hover {\n    background-color: rgb(195, 203, 210);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2JhY2tvZmZpY2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHlCQUF5QjtJQUN6QixpQ0FBaUM7QUFDckM7O0FBRUE7SUFDSSxtQ0FBbUM7SUFDbkMsdUJBQXVCO0lBQ3ZCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLFdBQVc7SUFDWCxlQUFlO0lBQ2YsdUJBQXVCO0lBQ3ZCLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLG9DQUFvQztBQUN4QyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tc2VsZWN0IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDQ4YjIzO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYig1NCwgNTIsIDUyKTtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIG5nLXNlbGVjdC5uZy1zZWxlY3QuY3VzdG9tLWRwIC5uZy1kcm9wZG93bi1wYW5lbCAubmctZHJvcGRvd24tcGFuZWwtaXRlbXMge1xuICAgIGJvcmRlcjogMC4ycHggc29saWQgcmdiKDU0LCA1MiwgNTIpO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgIHBhZGRpbmctbGVmdDogMTVweDtcbn1cblxuLmN1c3RvbS1vcHRpb24ge1xuICAgIGNvbG9yOiAjMzMzO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xufVxuXG4uY3VzdG9tLW9wdGlvbjpob3ZlciB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE5NSwgMjAzLCAyMTApO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 28635:
/*!*********************************************************!*\
  !*** ./src/app/modules/backoffice/backoffice.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackofficeModule": () => (/* binding */ BackofficeModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _components_exempted_exempted_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/exempted/exempted.component */ 83452);
/* harmony import */ var _backoffice_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./backoffice.component */ 32169);
/* harmony import */ var _components_external_registration_external_registration_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/external-registration/external-registration.component */ 97186);
/* harmony import */ var _components_landing_landing_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/landing/landing.component */ 67961);
/* harmony import */ var _components_mobile_booking_mobile_booking_mobile_booking_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/mobile-booking/mobile-booking/mobile-booking.component */ 25414);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);
/* harmony import */ var _components_inspection_results_reports_InspectionResultsReportsComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/inspection-results-reports/InspectionResultsReportsComponent */ 4722);
/* harmony import */ var _components_receipt_backoffice_receipt_backoffice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/receipt-backoffice/receipt-backoffice.component */ 25753);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);














const routes = [{
  path: '',
  redirectTo: 'external-registration',
  pathMatch: 'full'
}, {
  path: '',
  component: _backoffice_component__WEBPACK_IMPORTED_MODULE_2__.BackofficeComponent,
  children: [{
    path: 'external-registration',
    component: _components_external_registration_external_registration_component__WEBPACK_IMPORTED_MODULE_3__.ExternalRegistrationComponent
  }, {
    path: 'landing',
    component: _components_landing_landing_component__WEBPACK_IMPORTED_MODULE_4__.LandingComponent
  }, {
    path: 'exempted',
    component: _components_exempted_exempted_component__WEBPACK_IMPORTED_MODULE_1__.ExemptedComponent
  }, {
    path: 'mobile-booking',
    component: _components_mobile_booking_mobile_booking_mobile_booking_component__WEBPACK_IMPORTED_MODULE_5__.MobileBookingComponent
  }]
}, {
  path: 'Inspection-result-reports',
  component: _components_inspection_results_reports_InspectionResultsReportsComponent__WEBPACK_IMPORTED_MODULE_6__.InspectionResultsReportsComponent
}, {
  path: 'receipt-backoffice',
  component: _components_receipt_backoffice_receipt_backoffice_component__WEBPACK_IMPORTED_MODULE_7__.ReceiptBackofficeComponent
}];
class BackofficeModule {
  static #_ = this.ɵfac = function BackofficeModule_Factory(t) {
    return new (t || BackofficeModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
    type: BackofficeModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule.forChild(routes), _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__.NgSelectModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](BackofficeModule, {
    declarations: [_components_external_registration_external_registration_component__WEBPACK_IMPORTED_MODULE_3__.ExternalRegistrationComponent, _components_landing_landing_component__WEBPACK_IMPORTED_MODULE_4__.LandingComponent, _backoffice_component__WEBPACK_IMPORTED_MODULE_2__.BackofficeComponent, _components_exempted_exempted_component__WEBPACK_IMPORTED_MODULE_1__.ExemptedComponent, _components_mobile_booking_mobile_booking_mobile_booking_component__WEBPACK_IMPORTED_MODULE_5__.MobileBookingComponent, _components_inspection_results_reports_InspectionResultsReportsComponent__WEBPACK_IMPORTED_MODULE_6__.InspectionResultsReportsComponent, _components_receipt_backoffice_receipt_backoffice_component__WEBPACK_IMPORTED_MODULE_7__.ReceiptBackofficeComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__.NgSelectModule]
  });
})();

/***/ }),

/***/ 83452:
/*!******************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/exempted/exempted.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExemptedComponent": () => (/* binding */ ExemptedComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/register-vehicle */ 54611);
/* harmony import */ var src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/service-request */ 84908);
/* harmony import */ var src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/vehicle-details */ 43347);
/* harmony import */ var src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utilities/enums/inspectionServiceTypes */ 43327);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/file.service */ 75349);
/* harmony import */ var src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/purchase.service */ 87010);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../shared/file-uploads/file-uploads.component */ 19465);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);






























function ExemptedComponent_div_15_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * This Vehicle is Not Registered in MOI ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", ctx_r12.errorMessage, " ");
  }
}
function ExemptedComponent_div_15_option_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r61 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", pt_r61.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", pt_r61.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_select_19_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vc_r63 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", vc_r63.categoryId);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", vc_r63.descriptionEn, " ");
  }
}
function ExemptedComponent_div_15_select_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r65 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "select", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("ngModelChange", function ExemptedComponent_div_15_select_19_Template_select_ngModelChange_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r65);
      const ctx_r64 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r64.checkVehicleServices());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_19_option_1_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r15.exmpReg.get("vehicleCategories").value);
  }
}
function ExemptedComponent_div_15_input_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 81);
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("readonly", ctx_r16.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_select_24_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ot_r67 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ot_r67.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", ot_r67.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_select_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "select", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_24_option_1_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r17.exmpReg.get("ownerTypes").value);
  }
}
function ExemptedComponent_div_15_input_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 83);
  }
  if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("readonly", ctx_r18.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 84);
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r19.exmpReg.get("vdetails").value.ownerPID ? ctx_r19.exmpReg.get("vdetails").value.ownerPID : "")("readonly", ctx_r19.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 85);
  }
}
function ExemptedComponent_div_15_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r22.exmpReg.get("vdetails").value.ownerName ? ctx_r22.exmpReg.get("vdetails").value.ownerName : "");
  }
}
function ExemptedComponent_div_15_input_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 87);
  }
}
function ExemptedComponent_div_15_input_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 88);
  }
}
function ExemptedComponent_div_15_input_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 84);
  }
  if (rf & 2) {
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r25.exmpReg.get("vdetails").value.licenseExpiryDate ? ctx_r25.exmpReg.get("formatExpDate").value : "")("readonly", ctx_r25.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_div_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " Invalid date format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " Istimara Date must be valid at least 30 days from now ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r28.exmpReg.get("vdetails").value.vinNo ? ctx_r28.exmpReg.get("vdetails").value.vinNo : "");
  }
}
function ExemptedComponent_div_15_input_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 89);
  }
}
function ExemptedComponent_div_15_div_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_select_55_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r69 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", m_r69.manufacturersId);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", m_r69.manufacturersEname, " ");
  }
}
function ExemptedComponent_div_15_select_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "select", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("change", function ExemptedComponent_div_15_select_55_Template_select_change_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r71);
      const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r70.getModelTypes($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_55_option_1_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r31.exmpReg.get("manufacturerTypes").value);
  }
}
function ExemptedComponent_div_15_input_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 84);
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r32.exmpReg.get("vdetails").value.manufacturersEname ? ctx_r32.exmpReg.get("vdetails").value.manufacturersEname : "")("readonly", ctx_r32.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_select_60_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r73 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", m_r73.modelId);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", m_r73.modelEname, " ");
  }
}
function ExemptedComponent_div_15_select_60_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "select", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_60_option_1_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r33.exmpReg.get("modelTypes").value);
  }
}
function ExemptedComponent_div_15_input_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 84);
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r34.exmpReg.get("vdetails").value.modelEname ? ctx_r34.exmpReg.get("vdetails").value.modelEname : "")("readonly", ctx_r34.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r35.exmpReg.get("vdetails").value.manufacturerYear ? ctx_r35.exmpReg.get("vdetails").value.manufacturerYear : "");
  }
}
function ExemptedComponent_div_15_select_66_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const year_r75 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", year_r75);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](year_r75);
  }
}
function ExemptedComponent_div_15_select_66_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "select", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_66_option_1_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r36.getYearRange());
  }
}
function ExemptedComponent_div_15_div_67_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, "Enter a valid year");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_71_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r38.exmpReg.get("vdetails").value.cylinders ? ctx_r38.exmpReg.get("vdetails").value.cylinders : "");
  }
}
function ExemptedComponent_div_15_input_72_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 93);
  }
}
function ExemptedComponent_div_15_div_73_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, "Enter a valid vehicle cylinders ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r41.exmpReg.get("vdetails").value.weight ? ctx_r41.exmpReg.get("vdetails").value.weight : "");
  }
}
function ExemptedComponent_div_15_input_78_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 94);
  }
}
function ExemptedComponent_div_15_div_79_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, "Enter a valid weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r44.exmpReg.get("vdetails").value.payloadWeight ? ctx_r44.exmpReg.get("vdetails").value.payloadWeight : "");
  }
}
function ExemptedComponent_div_15_input_84_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 95);
  }
  if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("readonly", ctx_r45.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_div_85_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, "Enter a valid payload weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_select_89_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r77 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", color_r77.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", color_r77.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_select_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "select", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_89_option_1_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r47.exmpReg.get("colorList").value);
  }
}
function ExemptedComponent_div_15_input_90_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 97);
  }
  if (rf & 2) {
    const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("readonly", ctx_r48.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_select_94_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r79 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", color_r79.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", color_r79.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_select_94_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "select", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_94_option_1_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r49.exmpReg.get("colorList").value);
  }
}
function ExemptedComponent_div_15_input_95_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 84);
  }
  if (rf & 2) {
    const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r50.exmpReg.get("subclr").value)("readonly", ctx_r50.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_99_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r51.exmpReg.get("vdetails").value.noOfSeat ? ctx_r51.exmpReg.get("vdetails").value.noOfSeat : "");
  }
}
function ExemptedComponent_div_15_input_100_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "input", 99);
  }
}
function ExemptedComponent_div_15_div_101_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, "Enter a valid seat number");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_102_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 19)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](2, " Exempted Reason ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](3, "input", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r54.exmpReg.get("exmpReason").value);
  }
}
function ExemptedComponent_div_15_div_103_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 19)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](2, " Exempted Remarks ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](3, "input", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", ctx_r55.exmpReg.get("vdetails").value.remarks);
  }
}
function ExemptedComponent_div_15_div_104_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "div", 19);
  }
}
function ExemptedComponent_div_15_div_105_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "div", 19);
  }
}
function ExemptedComponent_div_15_div_107_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](1, "div", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3, " Woqod Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }
}
function ExemptedComponent_div_15_div_108_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 102)(1, "label", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](2, "input", 104)(3, "span", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](4, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](5, "Apply Staff Rate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵstyleProp"]("pointer-events", ctx_r59.disableStaffRate ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("checked", ctx_r59.exmpReg.get("isStaffRate").value);
  }
}
function ExemptedComponent_div_15_span_112_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "span", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", ctx_r60.fileName, " ");
  }
}
function ExemptedComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 45)(1, "div", 17)(2, "div", 18)(3, "div", 19)(4, "label", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](5, " License Plate No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](6, "input", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](7, ExemptedComponent_div_15_div_7_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](8, ExemptedComponent_div_15_div_8_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](9, ExemptedComponent_div_15_div_9_Template, 2, 1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](10, "div", 19)(11, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](12, " License Plate Type * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](13, "select", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](14, ExemptedComponent_div_15_option_14_Template, 2, 2, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](15, ExemptedComponent_div_15_div_15_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](16, "div", 19)(17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](18, "Vehicle Category");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](19, ExemptedComponent_div_15_select_19_Template, 2, 1, "select", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](20, ExemptedComponent_div_15_input_20_Template, 1, 1, "input", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](21, "div", 19)(22, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](23, "Owner PID Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](24, ExemptedComponent_div_15_select_24_Template, 2, 1, "select", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](25, ExemptedComponent_div_15_input_25_Template, 1, 1, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](26, "div", 19)(27, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](28, "Owner PID");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](29, ExemptedComponent_div_15_input_29_Template, 1, 2, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](30, ExemptedComponent_div_15_input_30_Template, 1, 0, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](31, ExemptedComponent_div_15_div_31_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](32, "div", 19)(33, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](34, "Owner Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](35, ExemptedComponent_div_15_input_35_Template, 1, 1, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](36, ExemptedComponent_div_15_input_36_Template, 1, 0, "input", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](37, "div", 19)(38, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](39, "Istimara Expiry Date");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](40, ExemptedComponent_div_15_input_40_Template, 1, 0, "input", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](41, ExemptedComponent_div_15_input_41_Template, 1, 2, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](42, ExemptedComponent_div_15_div_42_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](43, ExemptedComponent_div_15_div_43_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](44, "div", 59)(45, "div", 18)(46, "div", 19)(47, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](48, "VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](49, ExemptedComponent_div_15_input_49_Template, 1, 1, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](50, ExemptedComponent_div_15_input_50_Template, 1, 0, "input", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](51, ExemptedComponent_div_15_div_51_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](52, "div", 19)(53, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](54, "Manufacturer");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](55, ExemptedComponent_div_15_select_55_Template, 2, 1, "select", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](56, ExemptedComponent_div_15_input_56_Template, 1, 2, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](57, "div", 19)(58, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](59, "Model");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](60, ExemptedComponent_div_15_select_60_Template, 2, 1, "select", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](61, ExemptedComponent_div_15_input_61_Template, 1, 2, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](62, "div", 19)(63, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](64, "Manufacturing Year");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](65, ExemptedComponent_div_15_input_65_Template, 1, 1, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](66, ExemptedComponent_div_15_select_66_Template, 2, 1, "select", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](67, ExemptedComponent_div_15_div_67_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](68, "div", 19)(69, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](70, "Cylinders");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](71, ExemptedComponent_div_15_input_71_Template, 1, 1, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](72, ExemptedComponent_div_15_input_72_Template, 1, 0, "input", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](73, ExemptedComponent_div_15_div_73_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](74, "div", 19)(75, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](76, "Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](77, ExemptedComponent_div_15_input_77_Template, 1, 1, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](78, ExemptedComponent_div_15_input_78_Template, 1, 0, "input", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](79, ExemptedComponent_div_15_div_79_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](80, "div", 19)(81, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](82, "Payload Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](83, ExemptedComponent_div_15_input_83_Template, 1, 1, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](84, ExemptedComponent_div_15_input_84_Template, 1, 1, "input", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](85, ExemptedComponent_div_15_div_85_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](86, "div", 19)(87, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](88, "Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](89, ExemptedComponent_div_15_select_89_Template, 2, 1, "select", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](90, ExemptedComponent_div_15_input_90_Template, 1, 1, "input", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](91, "div", 19)(92, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](93, "Sub Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](94, ExemptedComponent_div_15_select_94_Template, 2, 1, "select", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](95, ExemptedComponent_div_15_input_95_Template, 1, 2, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](96, "div", 19)(97, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](98, "Seats");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](99, ExemptedComponent_div_15_input_99_Template, 1, 1, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](100, ExemptedComponent_div_15_input_100_Template, 1, 0, "input", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](101, ExemptedComponent_div_15_div_101_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](102, ExemptedComponent_div_15_div_102_Template, 4, 1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](103, ExemptedComponent_div_15_div_103_Template, 4, 1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](104, ExemptedComponent_div_15_div_104_Template, 1, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](105, ExemptedComponent_div_15_div_105_Template, 1, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](106, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](107, ExemptedComponent_div_15_div_107_Template, 4, 0, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](108, ExemptedComponent_div_15_div_108_Template, 6, 3, "div", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](109, "button", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](110, "span", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](111, " Attachement ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](112, ExemptedComponent_div_15_span_112_Template, 2, 1, "span", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputPlateNo").invalid && ctx_r0.exmpReg.get("inputPlateNo").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("showMoiError").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.errorMessage);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r0.exmpReg.get("plateTypes").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputPlateType").invalid && ctx_r0.exmpReg.get("inputPlateType").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value || ctx_r0.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value && !ctx_r0.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value && ctx_r0.exmpReg.get("inputPid").invalid && ctx_r0.exmpReg.get("inputPid").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("expDate").hasError("invalidDate") && ctx_r0.exmpReg.get("expDate").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("expDate").hasError("futureDate"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value && ctx_r0.exmpReg.get("inputVinNo").invalid && ctx_r0.exmpReg.get("inputVinNo").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputManfYear").touched && (ctx_r0.exmpReg.get("inputManfYear").hasError("pattern") || ctx_r0.exmpReg.get("inputManfYear").hasError("invalidYear")));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputCylinders").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value && !ctx_r0.isWeightZero);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value || ctx_r0.isWeightZero);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputWeight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputPayloadweight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputNbSeats").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.isWoqodVehicle);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("isStaffRateValue").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.fileName);
  }
}
function ExemptedComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Enter a valid mobile number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " * Enter a valid PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, "Enter a valid email address");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_46_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" Inspection Services Fees: ", ctx_r80.inspectionFees, " QAR ");
  }
}
function ExemptedComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 2)(1, "div", 4)(2, "div", 12)(3, "div", 6)(4, "div", 107)(5, "div", 8)(6, "h2", 108)(7, "button", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](8, " Service Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](9, "div", 110)(10, "div", 17)(11, "div", 18)(12, "div", 19)(13, "div", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](14, "input", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](15, "label", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](16, "img", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](17, " Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](18, "div", 2)(19, "div", 4)(20, "label", 115);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](21, "Inspection Service Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](22, "div", 4)(23, "div", 116)(24, "input", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("ngModelChange", function ExemptedComponent_div_46_Template_input_ngModelChange_24_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r82);
      const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r81.onSelectServiceSubType(1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](25, "label", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](26, " Normal Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](27, ExemptedComponent_div_46_div_27_Template, 2, 1, "div", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](27);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r6.inspectionFees);
  }
}
function ExemptedComponent_button_51_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "button", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function ExemptedComponent_button_51_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r83.submitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, "Payment");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("disabled", !ctx_r7.exmpReg.get("isFormValid").value || !ctx_r7.exmpReg.valid);
  }
}
function ExemptedComponent_button_52_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "button", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function ExemptedComponent_button_52_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r86);
      const ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r85.continueReceipt());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](1, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_54_div_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 116)(1, "input", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("ngModelChange", function ExemptedComponent_div_54_div_6_div_2_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r92);
      const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r91.onSelectPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](2, "label", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const pt_r90 = ctx.$implicit;
    const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("id", "pt" + pt_r90.lkCodeValue)("value", pt_r90.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵattribute"]("disabled", !ctx_r89.enableCashMethodSetting && pt_r90.lkCodeValue == 1 ? true : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("for", "pt" + pt_r90.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", pt_r90.lkValueEname, " ");
  }
}
function ExemptedComponent_div_54_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 132)(1, "div", 133);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](2, ExemptedComponent_div_54_div_6_div_2_Template, 4, 5, "div", 134);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r87.exmpReg.get("paymentTypes").value);
  }
}
function ExemptedComponent_div_54_div_8_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ng-option", 143)(1, "div", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r94 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", c_r94.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", c_r94.customerName, " ");
  }
}
function ExemptedComponent_div_54_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r96 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 137)(1, "div", 138)(2, "label", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](4, "ng-select", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("change", function ExemptedComponent_div_54_div_8_Template_ng_select_change_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r96);
      const ctx_r95 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r95.isPaymentValid = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerStart"](5, 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](6, "ng-option", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](7, ExemptedComponent_div_54_div_8_ng_option_7_Template, 3, 2, "ng-option", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r88 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r88.creditCustomerList);
  }
}
function ExemptedComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r98 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 33)(1, "div", 34)(2, "div", 35)(3, "h1", 123);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](4, "Payment Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](5, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](6, ExemptedComponent_div_54_div_6_Template, 3, 1, "div", 124);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](7, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](8, ExemptedComponent_div_54_div_8_Template, 8, 4, "div", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](9, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](10, "div", 126)(11, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](12, "Summary Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](13, "div", 2)(14, "div", 127)(15, "table", 128)(16, "thead")(17, "tr")(18, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](19, "Service");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](20, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](21, "Fees");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](22, "tbody")(23, "tr")(24, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](25, " Normal Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](26, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](27);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](28, "tfoot")(29, "tr")(30, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](31, "Total");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](32, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](34, "div", 129)(35, "button", 130);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function ExemptedComponent_div_54_Template_button_click_35_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r98);
      const ctx_r97 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r97.cancelPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](36, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](37, "button", 131);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function ExemptedComponent_div_54_Template_button_click_37_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r98);
      const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx_r99.submitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](38, "Submit");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r9.noPaymentRequired);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r9.exmpReg.get("showCredit").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", ctx_r9.exmpReg.get("feesIns").value, " QAR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", ctx_r9.exmpReg.get("amount").value, " QAR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("disabled", !ctx_r9.isPaymentValid);
  }
}
class ExemptedComponent {
  constructor(lookupServ, vehicleService, fileService, render, fb, location, purchase, sharedDataService, sharedLookup, sideNav, paymentService, ssrsPrintServ, globalServ, thousandSeparator, sysAdminService) {
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.fileService = fileService;
    this.render = render;
    this.fb = fb;
    this.location = location;
    this.purchase = purchase;
    this.sharedDataService = sharedDataService;
    this.sharedLookup = sharedLookup;
    this.sideNav = sideNav;
    this.paymentService = paymentService;
    this.ssrsPrintServ = ssrsPrintServ;
    this.globalServ = globalServ;
    this.thousandSeparator = thousandSeparator;
    this.sysAdminService = sysAdminService;
    this.selectedFiles = [];
    this.serviceFlags = {};
    this.creditCustomerList = [];
    this.isExem = false;
    this.paymentName = 'Card';
    this.displayPaymentDetails = 'none';
    this.selectedMainService = [];
    this.printReceiptDirectly = false;
    this.feesDetails = [];
    this.enableCashMethodSetting = true;
    this.isPaymentValid = true;
    this.feesInsChecked = false;
    this.isPaymentStarted = false;
    this.disableStaffRate = true;
    this.vehicleServices = {
      inspectionServices: [],
      vinStampingServices: [],
      tankerCertServices: []
    };
    this.exmpReg = this.fb.group({
      inputPlateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.required],
      inputPlateNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.required],
      selectedPayment: [],
      selectedOwnerType: [' ', _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.required],
      selectedServType: [''],
      selectedCust: [''],
      selectedServName: [''],
      selectedManufacturer: [],
      selectedModel: [],
      selectedVehicleCategory: null,
      selectedColor: [''],
      selectedSubColor: [''],
      selectedArea: [''],
      selectedLocation: [''],
      selectedServIns: false,
      selectedServVin: false,
      selectedServTanker: false,
      selectedInsSubType: [],
      selectedServiceType: [],
      checkAllContact: [false],
      checkAllLocation: [false],
      nonEditable: [true],
      isStaffRate: [false],
      isStaffRateValue: [false],
      showCredit: [false],
      showErrorPopup: [true],
      showScreen: [true],
      vdetails: [{}],
      colorList: [[]],
      ownerTypes: [[]],
      plateTypes: [[]],
      manufacturerTypes: [[]],
      modelTypes: [[]],
      vehicleCategories: [[]],
      lookupValues: [{}],
      serviceTypeList: [[]],
      exemptedReason: [[]],
      exmpReason: [''],
      expDate: [''],
      pidValue: [''],
      colorValue: [''],
      subclr: [' '],
      vcategory: [''],
      feesIns: [0],
      amount: [0],
      feesDiscount: [],
      inputOwnerType: [''],
      inputPid: [' ', [_angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.required]],
      inputOwnerName: [''],
      inputVinNo: [' ', _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.required],
      inputManfYear: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern('^[0-9]*$')]],
      inputCylinders: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern('^[0-9]*$')],
      inputWeight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern('^[0-9]*$')],
      inputPayloadweight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern('^[0-9]*$')],
      inputNbSeats: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern('^[0-9]*$')],
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern(/^[34567]\d{7}$/)]],
      pid: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern(/^.{1,20}$/)]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.email, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.pattern(/^.{1,60}$/)]],
      displayServiceType: [false],
      vehicleCategoryValue: null,
      selectedVinStamping: [],
      selectedTanker: [],
      isFormValid: [false],
      vcategoryType: [],
      showNotExm: [false],
      paymentTypes: [[]],
      formatExpDate: [],
      showMoiError: [false]
    });
  }
  dateValidator(control) {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();
    const minDate = new Date(currentDate);
    minDate.setDate(currentDate.getDate() + 30);
    if (isNaN(selectedDate.getTime())) {
      return {
        invalidDate: true
      };
    }
    if (selectedDate < minDate) {
      return {
        futureDate: true
      };
    }
    return null;
  }
  validManfYear(control) {
    const year = control.value;
    const currentYear = new Date().getFullYear();
    const minYear = 1900; // min allowed vehicle year
    const maxYear = currentYear;
    if (year < minYear || year > maxYear) {
      return {
        'invalidYear': true
      };
    }
    return null;
  }
  getYearRange() {
    const startYear = 1900;
    const currentYear = new Date().getFullYear();
    const yearRange = [];
    for (let year = currentYear + 1; year >= startYear; year--) {
      yearRange.push(year);
    }
    return yearRange;
  }
  onKeydown(event) {
    if (event.target instanceof HTMLInputElement && event.target.type === 'number') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
      }
    }
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(2, 6);
    //  this.sharedDataService.userId$.subscribe((userId) => {
    //    this.userId = userId;
    // });
    this.userId = parseInt(localStorage.getItem('userId'));
    /* this.sharedDataService.stationId$.subscribe((res) => {
      this.stationId = res;
    }); */
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.sharedLookup.colorList$.subscribe(data => {
      this.exmpReg.get('colorList').setValue(data);
    });
    this.sharedLookup.ownerTypes$.subscribe(data => {
      this.exmpReg.get('ownerTypes').setValue(data);
    });
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.exmpReg.get('vehicleCategories').setValue(data);
    });
    this.sharedLookup.manufacturerTypes$.subscribe(data => {
      this.exmpReg.get('manufacturerTypes').setValue(data);
    });
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.exmpReg.get('plateTypes').setValue(data);
    });
    this.sharedLookup.serviceTypeList$.subscribe(data => {
      this.exmpReg.get('serviceTypeList').setValue(data);
    });
    this.sharedLookup.exemptedReasons$.subscribe(data => {
      this.exmpReg.get('exemptedReason').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.paymentMethods).subscribe(data => {
      this.exmpReg.get('paymentTypes').setValue(data.items);
      const firstPaymentType = data.items.find(item => item.lkValueAname === 'Card').lkCodeValue;
      this.exmpReg.get('selectedPayment').setValue(firstPaymentType);
    });
    this.subscription = this.barCodeSubscription = this.sharedDataService.textEx$.subscribe(text => {
      const plateType = parseInt(text.substring(0, 2));
      const plateNo = parseInt(text.substring(2));
      if (plateNo) {
        this.exmpReg.patchValue({
          inputPlateNo: plateNo,
          inputPlateType: plateType
        });
        this.getExemptedVehicleDetails();
      }
    });
    this.exmpReg.get('inputPlateNo').valueChanges.subscribe(value => {
      if (this.exmpReg.get('inputPlateNo').valueChanges) {
        this.exmpReg.get('inputPlateType').setValue('');
        this.resetInfo();
      }
    });
    this.exmpReg.get('inputPlateType').valueChanges.subscribe(value => {
      this.getExemptedVehicleDetails();
    });
    // check if cash is enabled
    this.sharedDataService.stationSetting$.subscribe(res => {
      const checkCashMethod = res.find(item => item.key === "EnableCashMethod" && item.value === "True");
      if (checkCashMethod != undefined) {
        this.enableCashMethodSetting = checkCashMethod;
      }
    });
  }
  onFileUploaded(fname) {
    this.fileName = fname;
  }
  checkValidRequiredFields() {
    if (this.exmpReg.get('phone').hasError('required') && this.exmpReg.get('inputPlateNo') && this.exmpReg.get('inputPlateNo')) {
      this.exmpReg.get('isFormValid').setValue(false);
    } else {
      this.exmpReg.get('isFormValid').setValue(true);
    }
  }
  getModelTypes(event) {
    this.vehicleService.getModelsByManufacturerId(this.exmpReg.get('selectedManufacturer').value).subscribe(data => {
      this.exmpReg.get('modelTypes').setValue(data.items);
    });
  }
  // call the API GetExemptedVehicle to return the fields if exempted
  getExemptedVehicleDetails() {
    this.exmpReg.get("showMoiError").setValue(false);
    this.errorMessage = '';
    if (this.exmpReg.get('inputPlateType').value) {
      const licenseDetails = {
        plateNo: this.exmpReg.get('inputPlateNo').value,
        plateType: this.exmpReg.get('inputPlateType').value
      };
      this.vehicleService.getExemptedVehicle(licenseDetails).subscribe(data => {
        if (data.items) {
          this.exmpReg.get('vdetails').setValue(data.items);
          if (this.exmpReg.get('vdetails').value) {
            this.exmpReg.get('inputVinNo').setValidators(null);
            this.exmpReg.get('inputManfYear').setValidators(null);
            this.exmpReg.get('inputCylinders').setValidators(null);
            this.exmpReg.get('inputNbSeats').setValidators(null);
            this.exmpReg.updateValueAndValidity();
            if (data.items.weight > 0) {
              this.isWeightZero = false;
            } else {
              this.isWeightZero = true;
            }
            this.isExem = true;
            const vehicleSer = {
              categoryId: this.exmpReg.get('vdetails').value.categoryId,
              stationId: this.stationId
            };
            this.vehicleService.getVehicleServices(vehicleSer).subscribe(response => {
              this.vehicleServices = response.items;
              this.getServiceTypes();
            });
            const color = this.exmpReg.get('colorList').value.find(color => color.lkCodeValue == this.exmpReg.get('vdetails').value.colorId);
            this.exmpReg.get('colorValue').setValue(color.lkValueEname);
            if (this.exmpReg.get('vdetails').value.categoryId) {
              this.exmpReg.get('vcategory').setValue(this.exmpReg.get('vehicleCategories').value.find(category => category.categoryId == this.exmpReg.get('vdetails').value.categoryId).descriptionEn);
              this.enableCategorySelection = false;
            } else {
              this.enableCategorySelection = true;
              // if the clerk will manually select the vehicle category it should be required field
              this.exmpReg.get('selectedVehicleCategory').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_24__.Validators.required);
              // Trigger re-validation
              this.exmpReg.get('selectedVehicleCategory').updateValueAndValidity();
            }
            this.exmpReg.get('isStaffRate').setValue(this.exmpReg.get('vdetails').value.isStaffVehicle);
            this.exmpReg.get('isStaffRateValue').setValue(this.exmpReg.get('vdetails').value.isStaffVehicle);
            if (this.exmpReg.get('vdetails').value.isStaffVehicle) {
              this.sysAdminService.getUserRoles({
                userId: this.userId
              }).subscribe(response => {
                for (let r of response.items) {
                  if (r.roleId == 2) {
                    this.disableStaffRate = false;
                  }
                }
              });
            }
            this.isWoqodVehicle = this.exmpReg.get('vdetails').value.isWaqodVehicle;
            this.exmpReg.get('nonEditable').setValue(true);
            this.exmpReg.get('displayServiceType').setValue(true);
            const isoDate = new Date(this.exmpReg.get('vdetails').value.licenseExpiryDate);
            const dateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_25__.DatePipe('en-US').transform(isoDate, 'dd-MM-yyyy');
            this.exmpReg.get('formatExpDate').setValue(dateFormat);
            this.exmpReg.get('showMoiError').setValue(false);
            this.exmpReg.get('phone').setValue(this.exmpReg.get('vdetails').value.contactPersonPhone);
            this.exmpReg.get('email').setValue(this.exmpReg.get('vdetails').value.contactPersonEmail);
            this.exmpReg.get('pid').setValue(this.exmpReg.get('vdetails').value.contactPersonPID);
            this.exmpReg.get('pidValue').setValue(this.exmpReg.get('ownerTypes').value.find(pid => pid.lkCodeValue == this.exmpReg.get('vdetails').value.ownerPidType).lkValueEname);
            this.exmpReg.get('exmpReason').setValue(this.exmpReg.get('exemptedReason').value.find(exm => exm.lkCodeValue == this.exmpReg.get('vdetails').value.exemptedReason).lkValueEname);
            let subColor = this.exmpReg.get('colorList').value.find(color => color.lkCodeValue == this.exmpReg.get('vdetails').value.subColorId);
            this.exmpReg.get('subclr').setValue(subColor ?? null);
            this.onSelectServiceSubType(1);
          }
        }
      }, error => {
        this.exmpReg.get('displayServiceType').setValue(false);
        if (error.error.ErrorMessage.includes("Time")) {
          this.errorMessage = "* Timeout error, please try again later";
        }
        if (error.error.ErrorMessage.includes("traffic")) {
          this.errorMessage = "* " + error.error.ErrorMessage;
        }
        if (error.error.ErrorMessage.includes("License")) {
          this.errorMessage = "* " + error.error.ErrorMessage;
        }
        if (error.error.ErrorMessage.includes("not found")) {
          this.exmpReg.get("showMoiError").setValue(true);
        }
      });
    }
    this.exmpReg.get('vdetails').setValue({});
    this.exmpReg.get('vcategory').setValue('');
    this.exmpReg.get('selectedVehicleCategory').setValue('');
    this.exmpReg.get('pidValue').setValue('');
    this.exmpReg.get('colorValue').setValue('');
    this.exmpReg.get('subclr').setValue('');
    this.exmpReg.get('isStaffRate').setValue(false);
    this.isExem = false;
  }
  checkVehicleServices() {
    const vehicleSer = {
      categoryId: this.exmpReg.get('selectedVehicleCategory').value,
      stationId: this.stationId
    };
    this.vehicleService.getVehicleServices(vehicleSer).subscribe(response => {
      this.vehicleServices = response.items;
      this.getServiceTypes();
    });
    this.exmpReg.get('displayServiceType').setValue(true);
  }
  getServiceTypes() {
    let counter = 1;
    for (const [index, key] of Object.keys(this.vehicleServices).entries()) {
      if (this.vehicleServices.hasOwnProperty(key)) {
        this.serviceFlags[index] = {
          value: this.vehicleServices[key].length > 0,
          id: counter++
        };
      }
    }
    //return this.vehicleServices ? Object.keys(this.vehicleServices) : [];
  }

  updateSelectedService(controlName) {
    this.exmpReg.get(controlName).setValue(true);
    const formControls = ['selectedServIns', 'selectedServVin', 'selectedServTanker'];
    formControls.forEach(control => {
      if (control !== controlName) {
        this.exmpReg.get(control).setValue(false);
      }
    });
  }
  onSelectServiceSubType(value) {
    if (value == 1) {
      this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('vehicleCategories').value.find(category => category.categoryId == this.exmpReg.get('vdetails').value.categoryId).categoryId);
      this.feesDetails.push({
        vinNo: this.exmpReg.get('vdetails').value.vinNo,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Inspection,
        serviceId: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__.InspectionServiceTypes.NormalInspection,
        vehicleCategoryId: this.exmpReg.get('vcategoryType').value,
        isStaffRate: this.exmpReg.get('isStaffRate').value ? true : false
      });
      this.exmpReg.get('selectedServIns').setValue(true);
      this.exmpReg.get('isFormValid').setValue(true);
      if (this.exmpReg.get('isStaffRate').value && value == src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__.InspectionServiceTypes.NormalInspection) {
        this.feesInsChecked = true;
        this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_26__.map)(data => data.items)).subscribe(items => {
          for (let fee of items) {
            if (fee.serviceTypeId == 1) {
              this.exmpReg.get("feesIns").setValue(fee.feesAmount);
              this.exmpReg.get("feesDiscount").setValue(fee.feesDiscount);
              if (fee.feesAmount != 0) {
                this.subInsId = false;
              } else {
                this.subInsId = true;
                this.exmpReg.get('selectedPayment').setValue(src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.Cash);
              }
            }
          }
          const totalAmount = this.exmpReg.get('feesIns').value || 0;
          this.amountTh = this.thousandSeparator.addThousandSeparator(totalAmount.toString());
          this.exmpReg.get("amount").setValue(totalAmount);
        });
      } else {
        this.vehicleService.getServiceFeesAmount(this.feesDetails).subscribe(response => {
          this.inspectionFees = response.items[0].feesAmount;
        });
      }
    }
  }
  clearServices(serviceType, serviceId) {
    this.exmpReg.get('isFormValid').setValue(false);
    this.exmpReg.get('selectedInsSubType').setValue(null);
    this.exmpReg.get('selectedServIns').setValue(false);
  }
  onSelectPayment() {
    if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.CreditCustomer) {
      this.exmpReg.get('showCredit').setValue(true);
      this.vehicleService.getCreditCustomer(this.exmpReg.get('selectedCust').value).subscribe(data => {
        this.creditCustomerList = data.items;
      });
      this.isPaymentValid = this.exmpReg.get('selectedCust').value ? true : false;
    } else {
      this.exmpReg.get('showCredit').setValue(false);
      this.isPaymentValid = true;
    }
    this.paymentName = this.exmpReg.get('paymentTypes').value.find(payId => payId.lkCodeValue == this.exmpReg.get('selectedPayment').value).lkValueEname;
  }
  continueReceipt() {
    this.submitForm();
    this.submitPayment();
    const modalElement = document.getElementById('PrintReceipt');
    setTimeout(() => {
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
      this.cancel();
    }, 3000);
  }
  cancel() {
    this.sharedDataService.setTextEx('');
    this.location.back();
    this.displayPaymentDetails = 'none';
    this.isPaymentStarted = false;
  }
  submitForm() {
    const date = new Date();
    this.currentDateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_25__.DatePipe('en-US').transform(date, 'dd MMM yyyy');
    this.currentTimeFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_25__.DatePipe('en-US').transform(date, 'h:mm a');
    this.globalServ.getStationPaymentMethods(1).subscribe(response => {
      this.exmpReg.get('paymentTypes').setValue(response.items);
    });
    if (this.exmpReg.get('isFormValid').value) {
      if (this.exmpReg.get('isStaffRate').value || this.exmpReg.get('vdetails').value.isWaqodVehicle) {
        //this.printReceiptDirectly = true;
      }
      const currentDate = new Date();
      if (!this.exmpReg.get('nonEditable').value) {
        // for manual entry to be updated or removed
        this.vehicleDetailsModel = new src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_2__.VehicleDetails(this.exmpReg.get('inputPlateNo').value, this.exmpReg.get('inputPlateType').value, this.exmpReg.get('inputVinNo').value, this.exmpReg.get('selectedColor').value, this.exmpReg.get('selectedSubColor').value, this.exmpReg.get('selectedVehicleCategory').value, this.exmpReg.get('selectedModel').value, this.exmpReg.get('selectedManufacturer').value, this.exmpReg.get('inputManfYear').value, currentDate, this.exmpReg.get('inputCylinders').value, this.exmpReg.get('inputWeight').value, this.exmpReg.get('inputPayloadWeight').value, '', this.exmpReg.get('inputNbSeats').value, this.exmpReg.get('inputPid').value, this.exmpReg.get('inputOwnerName').value, this.exmpReg.get('expDate').value, 0, currentDate, 0, currentDate, '', '', null, null, null, null);
        this.vehicleService.registerVehicle(this.vehicleDetailsModel).subscribe(response => {});
        this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('vehicleCategories').value.find(category => category.categoryId == this.exmpReg.get('selectedVehicleCategory')).categoryId);
      } else {
        if (this.enableCategorySelection) {
          this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('selectedVehicleCategory').value);
        } else {
          this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('vdetails').value.categoryId);
        }
      }
      this.selectedServTypeValue = this.exmpReg.get('selectedServIns').value ? 1 : this.exmpReg.get('selectedServVin').value ? 2 : 3;
      if (!this.feesInsChecked) {
        this.feesDetails.push({
          vinNo: this.exmpReg.get('vdetails').value.vinNo,
          serviceTypeId: 1,
          serviceId: 1,
          vehicleCategoryId: this.exmpReg.get('vcategoryType').value,
          isStaffRate: this.exmpReg.get('isStaffRate').value ? true : false
        });
        this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_26__.map)(data => data.items)).subscribe(items => {
          for (let fee of items) {
            if (fee.serviceTypeId == 1) {
              this.exmpReg.get("feesIns").setValue(fee.feesAmount);
              this.exmpReg.get("feesDiscount").setValue(fee.feesDiscount);
            }
          }
          const totalAmount = this.exmpReg.get('feesIns').value || 0;
          this.exmpReg.get("amount").setValue(totalAmount);
        });
      } else {}
    } else {
      this.markFormGroupTouched(this.exmpReg);
    }
  }
  markFormGroupTouched(formGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_24__.FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
  cancelPayment() {
    this.feesDetails = [];
    this.exmpReg.get("selectedCust").setValue('');
    this.exmpReg.get("amount").setValue(null);
  }
  submitPayment() {
    const currentDate = new Date();
    this.amountTh = this.thousandSeparator.addThousandSeparator(this.exmpReg.get('amount').value.toString());
    const exmpRegServiceRequestData = {
      stationId: this.stationId,
      serviceType: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Inspection,
      serviceID: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__.InspectionServiceTypes.NormalInspection,
      contactType: this.exmpReg.get('vdetails').value.ownerPidType,
      contactPersonName: '',
      contactPersonEmail: this.exmpReg.get('email').value,
      contactPersonPhone: this.exmpReg.get('phone').value.toString(),
      status: 1,
      registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.BackOffice,
      boothId: 1,
      posId: 1,
      remarks: '',
      requestRefId: 0,
      createdBy: this.userId,
      vinNo: this.exmpReg.get('vdetails').value.vinNo,
      plateType: parseInt(this.exmpReg.get('inputPlateType').value),
      plateNo: this.exmpReg.get('inputPlateNo').value
    };
    this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_1__.ServiceRequest(exmpRegServiceRequestData);
    this.vehicleService.insertServiceRequest(this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_26__.map)(data => data.items)).subscribe(items => {
      this.requestId = items;
      // upload attachments
      const fileInfoArray = this.fileService.getFileData();
      for (const fileInfo of fileInfoArray) {
        if (fileInfo) {
          const formData = new FormData();
          formData.append('requestId', this.requestId.toString());
          formData.append('sectionId', '');
          formData.append('defectId', '');
          formData.append('serviceTypeId', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Inspection.toString());
          formData.append('serviceId', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Exempted.toString());
          formData.append('mimeType', fileInfo.mimeType);
          formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.SupportDocuments.toString());
          formData.append('createdBy', this.userId.toString());
          formData.append('fileData', fileInfo.fileData, fileInfo.filename);
          this.globalServ.uploadAttachement(formData).subscribe(response => {}, error => {});
        }
      }
      // declare object values for RegisterVehicle
      const vehicleDetails = {
        requestId: this.requestId,
        plateNo: this.exmpReg.get('inputPlateNo').value,
        plateType: parseInt(this.exmpReg.get('inputPlateType').value),
        vinNo: this.exmpReg.get('vdetails').value.vinNo,
        colorId: this.exmpReg.get('vdetails').value.colorId,
        subColorId: this.exmpReg.get('vdetails').value.subColorId,
        categoryId: this.exmpReg.get('vcategoryType').value,
        vehicleModelId: this.exmpReg.get('vdetails').value.vehicleModelId,
        manufacturerId: this.exmpReg.get('vdetails').value.manufacturerId,
        manufacturerYear: this.exmpReg.get('vdetails').value.manufacturerYear,
        moiRegistrationDate: this.exmpReg.get('vdetails').value.moiRegistrationDate,
        cylinders: this.exmpReg.get('vdetails').value.cylinders,
        weight: this.isWeightZero ? this.exmpReg.get('inputWeight').value : this.exmpReg.get('vdetails').value.weight,
        payloadWeight: this.exmpReg.get('vdetails').value.payloadWeight,
        shapeCode: this.exmpReg.get('vdetails').value.shapeCode,
        descriptionEn: '',
        descriptionAr: '',
        noOfSeat: this.exmpReg.get('vdetails').value.noOfSeat,
        licenseExpiryDate: this.exmpReg.get('vdetails').value.licenseExpiryDate,
        ownerType: parseInt(this.exmpReg.get('vdetails').value.ownerPidType),
        contactPersonPid: this.exmpReg.get('pid').value,
        contactPersonEmail: this.exmpReg.get('email').value,
        contactPersonPhone: this.exmpReg.get('phone').value.toString(),
        ownerId: '0',
        ownerPid: this.exmpReg.get('vdetails').value.ownerPID,
        ownerPidType: parseInt(this.exmpReg.get('vdetails').value.ownerPidType),
        ownerName: this.exmpReg.get('vdetails').value.ownerName,
        departmentId: 0,
        createdBy: this.userId
      };
      // Create an instance of RegisterVehicle using vehicleDetails
      this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__.RegisterVehicle(vehicleDetails);
      this.vehicleService.registerVehicle(this.registerVehicle).subscribe(response => {});
      let payment = {
        paymentMethodId: this.exmpReg.get('selectedPayment').value,
        serviceRequestFeesDto: [{
          feesAmount: this.exmpReg.get('amount').value,
          requestId: this.requestId,
          serviceTypeId: this.selectedServTypeValue,
          customerId: this.exmpReg.get('selectedCust').value == undefined ? null : parseInt(this.exmpReg.get('selectedCust').value),
          subDiscount: this.exmpReg.get('feesDiscount').value
        }]
      };
      this.isPaymentStarted = true;
      if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.Card) {
        this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_27__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_28__.catchError)(error => {
          if (error.name === 'TimeoutError') {
            this.isNotReachable = true;
            this.displayPaymentDetails = 'block';
          }
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_29__.throwError)(error);
        })).subscribe(data => {
          const paymentResult = data;
          const isCaptured = paymentResult.items.isCaptured;
          const isCanceled = paymentResult.items.isCanceled;
          const isDeviceNotReachable = paymentResult.items.isDeviceNotReachable;
          const messageCode = paymentResult.messageCode;
          const errorMessage = paymentResult.errorMessage;
          if (data.items) {
            if (!paymentResult.items.isCaptured && !paymentResult.items.isDeviceNotReachable) {
              this.isSuccess = true;
              setTimeout(() => {
                this.isPaymentStarted = false;
                this.cancel();
              }, 3000);
            } else {
              if (paymentResult.items.isCaptured) {
                this.isSuccess = true;
              }
              if (paymentResult.items.isCanceled) {
                this.isPayCanceled = true;
              }
              if (paymentResult.items.isDeviceNotReachable) {
                this.isNotReachable = true;
              }
            }
          } else {
            if (paymentResult.items.isCaptured) {
              this.isSuccess = true;
            }
            if (paymentResult.items.isCanceled) {
              this.isPayCanceled = true;
            }
            if (paymentResult.items.isDeviceNotReachable) {
              this.isNotReachable = true;
            }
          }
          this.displayPaymentDetails = 'block';
        }, error => {
          console.error(error);
          this.isPaymentStarted = false;
        });
      }
      if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.Cash) {
        this.paymentService.submitPayment(payment).subscribe(data => {
          if (data.items) {
            this.isSuccess = true;
            this.isNotReachable = false;
            this.isPayCanceled = false;
            setTimeout(() => {
              this.isPaymentStarted = false;
              this.cancel();
            }, 3000);
          } else {
            this.isNotReachable = true;
            this.isPayCanceled = false;
            this.isSuccess = false;
          }
        }, error => {
          this.isSuccess = false;
          this.displayPaymentDetails = 'block';
        });
      }
      if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.CreditCustomer) {
        this.paymentService.submitPayment(payment).subscribe(data => {
          if (data.items) {
            this.isSuccess = true;
            this.isPayCanceled = false;
            this.isNotReachable = false;
            this.amountTh = '';
            setTimeout(() => {
              this.isPaymentStarted = false;
              this.cancel();
            }, 3000);
          } else {
            this.isNotReachable = true;
            this.isSuccess = false;
            this.isPayCanceled = false;
          }
          this.displayPaymentDetails = 'block';
        }, error => {
          this.isSuccess = false;
          this.displayPaymentDetails = 'block';
        });
      }
    });
  }
  sendPayment() {}
  downloadPayment() {
    this.ssrsPrintServ.downloadCustomerReport(this.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.save, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_4__.ModuleSourceEnum.exempted);
  }
  resetInfo() {
    this.exmpReg.get('displayServiceType').setValue(false);
    this.exmpReg.get('phone').setValue('');
    this.exmpReg.get('pid').setValue('');
    this.exmpReg.get('email').setValue('');
    this.enableCategorySelection = false;
  }
  ngOnDestroy() {
    this.sharedDataService.setTextEx('');
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function ExemptedComponent_Factory(t) {
    return new (t || ExemptedComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_9__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_10__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_11__.FileService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_23__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_24__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_25__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_12__.PurchaseService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_13__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_14__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_15__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_16__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_17__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_19__.ThousandSeparatorService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_20__.SystemAdminService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdefineComponent"]({
    type: ExemptedComponent,
    selectors: [["app-exempted"]],
    hostBindings: function ExemptedComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("keydown", function ExemptedComponent_keydown_HostBindingHandler($event) {
          return ctx.onKeydown($event);
        });
      }
    },
    decls: 80,
    vars: 21,
    consts: [[3, "formGroup"], [1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "class", "accordion-collapse collapse show", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 4, "ngIf"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", "formControlName", "phone", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "pid", 1, "form-control"], ["type", "text", "formControlName", "email", 1, "form-control"], ["class", "row", 4, "ngIf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 3, "disabled", "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 3, "click", 4, "ngIf"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["class", "modal-dialog modal-dialog-centered", 4, "ngIf"], [3, "isPaymentStarted", "email", "isSuccess", "isPayCanceled", "isNotReachable", "requestRefId", "currentDateFormat", "currentTimeFormat", "totalAmountTh", "paymentName", "onCancelEvent", "onCancelFailedEvent", "onDownloadPaymentEvent"], ["id", "errorPopup", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], [1, "modal-body"], [1, "pt-lab"], ["data-bs-backdrop", "static", "id", "PrintReceipt", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-content", "modal-content-rec"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close", 3, "click"], ["data-bs-backdrop", "static", "id", "fileUploadModal", "tabindex", "-1", "aria-labelledby", "fileUploadModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [3, "fileUploaded"], ["id", "act-search2", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], ["for", "myInput"], ["type", "number", "id", "myInput", "name", "plateNo", "formControlName", "inputPlateNo", 1, "form-control"], ["formControlName", "inputPlateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "form-control", "formControlName", "selectedVehicleCategory", 3, "ngModelChange", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "vcategory", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedOwnerType", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "pidValue", 3, "readonly", 4, "ngIf"], ["type", "text", "class", "form-control", 3, "value", "readonly", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPid", 4, "ngIf"], ["type", "text", "class", "form-control", "readonly", "", 3, "value", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputOwnerName", 4, "ngIf"], ["type", "date", "class", "form-control", "formControlName", "expDate", 4, "ngIf"], [1, "accordion-body", "border-top"], ["type", "text", "class", "form-control", "formControlName", "inputVinNo", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedManufacturer", 3, "change", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedModel", 4, "ngIf"], ["class", "form-control", "formControlName", "inputManfYear", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputCylinders", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputWeight", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPayloadweight", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedColor", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "colorValue", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedSubColor", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputNbSeats", 4, "ngIf"], ["class", "col-md-6 col-lg-3", 4, "ngIf"], [1, "col-lg-6", "sr-vc"], ["class", "woqod", 4, "ngIf"], ["class", "staff-rate", 3, "pointer-events", 4, "ngIf"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal", "id", "attachExm", 1, "btn", "btn-vci"], [1, "bi", "bi-paperclip"], ["id", "fn", 4, "ngIf"], [1, "error-message"], [3, "value"], ["formControlName", "selectedVehicleCategory", 1, "form-control", 3, "ngModelChange"], ["type", "text", "formControlName", "vcategory", 1, "form-control", 3, "readonly"], ["formControlName", "selectedOwnerType", 1, "form-control"], ["type", "text", "formControlName", "pidValue", 1, "form-control", 3, "readonly"], ["type", "text", 1, "form-control", 3, "value", "readonly"], ["type", "number", "formControlName", "inputPid", 1, "form-control"], ["type", "text", "readonly", "", 1, "form-control", 3, "value"], ["type", "text", "formControlName", "inputOwnerName", 1, "form-control"], ["type", "date", "formControlName", "expDate", 1, "form-control"], ["type", "text", "formControlName", "inputVinNo", 1, "form-control"], ["formControlName", "selectedManufacturer", 1, "form-control", 3, "change"], ["formControlName", "selectedModel", 1, "form-control"], ["formControlName", "inputManfYear", 1, "form-control"], ["type", "number", "formControlName", "inputCylinders", 1, "form-control"], ["type", "number", "formControlName", "inputWeight", 1, "form-control"], ["type", "number", "formControlName", "inputPayloadweight", 1, "form-control", 3, "readonly"], ["formControlName", "selectedColor", 1, "form-control"], ["type", "text", "formControlName", "colorValue", 1, "form-control", 3, "readonly"], ["formControlName", "selectedSubColor", 1, "form-control"], ["type", "number", "formControlName", "inputNbSeats", 1, "form-control"], [1, "woqod"], [1, "warn", "warning-green"], [1, "staff-rate"], [1, "switch"], ["type", "checkbox", "formControlName", "isStaffRate", 3, "checked"], [1, "slider", "round"], ["id", "fn"], ["id", "accordionExample3", 1, "accordion", "section-accordian"], ["id", "headingThree", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingThree", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [1, "outline-radio"], ["type", "radio", "id", "ins1", "checked", ""], ["for", "ins1"], ["src", "./assets/img/st-img-1.svg"], [1, "st-label"], [1, "btn-radio"], ["type", "radio", "id", "ns1", "name", "selectedInsSubType", "value", "1", "formControlName", "selectedInsSubType", 3, "ngModelChange"], ["for", "ns1"], ["class", "service-fees", 4, "ngIf"], [1, "service-fees"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "disabled", "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 1, "btn", "btn-orange", 3, "click"], ["id", "exampleModalLabel", 1, "modal-title"], ["class", "payment-info", 4, "ngIf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop2", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "payment-info"], [1, "payment-type"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["type", "radio", "formControlName", "selectedPayment", 3, "id", "value", "ngModelChange"], [3, "for"], [1, "col-md-6", "col-lg-6"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "formControlName", "selectedCust", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "clearSearchOnAdd", "minTermLength", "change"], [1, "dropdown-container"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"]],
    template: function ExemptedComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](1, "body")(2, "form", 0)(3, "section", 1)(4, "div", 2)(5, "div", 3)(6, "div", 2)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "div", 8)(12, "h2", 9)(13, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](14, " Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](15, ExemptedComponent_div_15_Template, 113, 51, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](16, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](17, "div", 2)(18, "div", 4)(19, "div", 12)(20, "div", 6)(21, "div", 13)(22, "div", 8)(23, "h2", 14)(24, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](25, " Contact Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](26, "div", 16)(27, "div", 17)(28, "div", 18)(29, "div", 19)(30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](31, "Phone No * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](32, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](33, ExemptedComponent_div_33_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](34, ExemptedComponent_div_34_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](35, "div", 19)(36, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](37, "PID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](38, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](39, ExemptedComponent_div_39_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](40, ExemptedComponent_div_40_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](41, "div", 19)(42, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](43, "Email ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](44, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](45, ExemptedComponent_div_45_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](46, ExemptedComponent_div_46_Template, 28, 1, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](47, "div", 2)(48, "div", 25)(49, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function ExemptedComponent_Template_button_click_49_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](50, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](51, ExemptedComponent_button_51_Template, 2, 1, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](52, ExemptedComponent_button_52_Template, 2, 0, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](53, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](54, ExemptedComponent_div_54_Template, 39, 5, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](55, "payment-transaction-status-modal", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("onCancelEvent", function ExemptedComponent_Template_payment_transaction_status_modal_onCancelEvent_55_listener() {
          return ctx.cancel();
        })("onCancelFailedEvent", function ExemptedComponent_Template_payment_transaction_status_modal_onCancelFailedEvent_55_listener() {
          return ctx.cancel();
        })("onDownloadPaymentEvent", function ExemptedComponent_Template_payment_transaction_status_modal_onDownloadPaymentEvent_55_listener() {
          return ctx.downloadPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](56, "div", 32)(57, "div", 33)(58, "div", 34)(59, "div", 35)(60, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](61, "Error");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](62, "div", 37)(63, "label", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](64, " Kindly, fill all the required fields ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](65, "div", 39)(66, "div", 33)(67, "div", 40)(68, "div", 35)(69, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](70, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](71, " Receipt ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](72, "button", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function ExemptedComponent_Template_button_click_72_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](73, "div", 37)(74, "label", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](75, " Printing Receipt... ");
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](76, "div", 43)(77, "div", 33)(78, "div", 34)(79, "app-file-uploads", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("fileUploaded", function ExemptedComponent_Template_app_file_uploads_fileUploaded_79_listener($event) {
          return ctx.onFileUploaded($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("formGroup", ctx.exmpReg);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("phone").hasError("required") && ctx.exmpReg.get("phone").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("phone").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("pid").hasError("required") && ctx.exmpReg.get("pid").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("pid").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("email").hasError("email") || ctx.exmpReg.get("email").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !(ctx.isWoqodVehicle || ctx.exmpReg.get("isStaffRate").value && ctx.subInsId));
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.isWoqodVehicle || ctx.exmpReg.get("isStaffRate").value && ctx.subInsId);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx.printReceiptDirectly);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("isPaymentStarted", ctx.isPaymentStarted)("email", ctx.exmpReg.get("email").value)("isSuccess", ctx.isSuccess)("isPayCanceled", ctx.isPayCanceled)("isNotReachable", ctx.isNotReachable)("requestRefId", ctx.requestId)("currentDateFormat", ctx.currentDateFormat)("currentTimeFormat", ctx.currentTimeFormat)("totalAmountTh", ctx.amountTh)("paymentName", ctx.paymentName);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_25__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_24__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_24__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_24__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.FormControlName, _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_21__.FileUploadsComponent, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_22__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_30__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_30__.NgOptionComponent],
    styles: [".row[_ngcontent-%COMP%] {\n    width: 100%;\n    margin-left: 0px;\n    flex-grow: 1;\n}\n\n.section[_ngcontent-%COMP%] {\n    flex-grow: 1;\n}\n\n.error-message[_ngcontent-%COMP%] {\n    color: red;\n    font-style: italic;\n}\n\n.btn-orange[_ngcontent-%COMP%]:disabled {\n    background-color: #ef9c3d;\n    color: #ffff;\n}\n\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\n    appearance: none;\n    margin: 0;\n}\n\n.mr-2[_ngcontent-%COMP%] {\n    white-space: nowrap;\n    padding: 10px;\n}\n\n.remove-service[_ngcontent-%COMP%] {\n    position: absolute;\n    right: 0;\n    top: 0;\n    cursor: pointer;\n    font-weight: bold;\n    color: white;\n    font-size: 20px;\n    text-align: center;\n    width: 100%;\n    height: 100%;\n    display: inline-block;\n}\n\n.btn-radio[_ngcontent-%COMP%] {\n    display: inline-block;\n    vertical-align: middle;\n    position: relative;\n}\n\n#fn[_ngcontent-%COMP%] {\n    font-size: 13px;\n    font-style: italic;\n}\n\n.warn[_ngcontent-%COMP%] {\n    font-size: 20px;\n    color: transparent;\n}\n\n.warn.warning-green[_ngcontent-%COMP%] {\n    display: inline-block;\n\n    top: 0.225em;\n\n    width: 1.15em;\n    height: 1.15em;\n\n    overflow: hidden;\n    border: none;\n    background-color: transparent;\n    border-radius: 0.625em;\n}\n\n.warn.warning-green[_ngcontent-%COMP%]::before {\n    content: \"\";\n    display: block;\n    top: -0.08em;\n    left: 0.0em;\n    position: absolute;\n    border: transparent 0.6em solid;\n    border-bottom-color: #448b23;\n    border-bottom-width: 1em;\n    border-top-width: 0;\n    box-shadow: #448b23 0 1px 1px;\n}\n\n.warn.warning-green[_ngcontent-%COMP%]::after {\n    display: block;\n    position: absolute;\n    top: 0.3em;\n    left: 0;\n    width: 100%;\n    padding: 0 1px;\n    text-align: center;\n    font-family: \"Garamond\";\n    content: \"!\";\n    font-size: 0.65em;\n    font-weight: bold;\n    color: white;\n}\n\n.woqod[_ngcontent-%COMP%] {\n    background-color: white;\n    box-shadow: #448b23 0 0.5px 0.5px;\n}\n\n.service-fees[_ngcontent-%COMP%] {\n    float: right;\n    margin-top: 20px;\n}\n\n.modal[_ngcontent-%COMP%]   .modal-content-rec[_ngcontent-%COMP%] {\n    width: 300px;\n    margin-left: 200px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvZXhlbXB0ZWQvZXhlbXB0ZWQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxVQUFVO0lBQ1Ysa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7O0lBR0ksZ0JBQWdCO0lBQ2hCLFNBQVM7QUFDYjs7QUFFQTtJQUNJLG1CQUFtQjtJQUNuQixhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFFBQVE7SUFDUixNQUFNO0lBQ04sZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixZQUFZO0lBQ1osZUFBZTtJQUNmLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsWUFBWTtJQUNaLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLHFCQUFxQjtJQUNyQixzQkFBc0I7SUFDdEIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGVBQWU7SUFDZixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxxQkFBcUI7O0lBRXJCLFlBQVk7O0lBRVosYUFBYTtJQUNiLGNBQWM7O0lBRWQsZ0JBQWdCO0lBQ2hCLFlBQVk7SUFDWiw2QkFBNkI7SUFDN0Isc0JBQXNCO0FBQzFCOztBQUVBO0lBQ0ksV0FBVztJQUNYLGNBQWM7SUFDZCxZQUFZO0lBQ1osV0FBVztJQUNYLGtCQUFrQjtJQUNsQiwrQkFBK0I7SUFDL0IsNEJBQTRCO0lBQzVCLHdCQUF3QjtJQUN4QixtQkFBbUI7SUFDbkIsNkJBQTZCO0FBQ2pDOztBQUVBO0lBQ0ksY0FBYztJQUNkLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVc7SUFDWCxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksdUJBQXVCO0lBQ3ZCLGlDQUFpQztBQUNyQzs7QUFFQTtJQUNJLFlBQVk7SUFDWixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxZQUFZO0lBQ1osa0JBQWtCO0FBQ3RCIiwic291cmNlc0NvbnRlbnQiOlsiLnJvdyB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgbWFyZ2luLWxlZnQ6IDBweDtcbiAgICBmbGV4LWdyb3c6IDE7XG59XG5cbi5zZWN0aW9uIHtcbiAgICBmbGV4LWdyb3c6IDE7XG59XG5cbi5lcnJvci1tZXNzYWdlIHtcbiAgICBjb2xvcjogcmVkO1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbn1cblxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XG4gICAgY29sb3I6ICNmZmZmO1xufVxuXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLFxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XG4gICAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuICAgIGFwcGVhcmFuY2U6IG5vbmU7XG4gICAgbWFyZ2luOiAwO1xufVxuXG4ubXItMiB7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBwYWRkaW5nOiAxMHB4O1xufVxuXG4ucmVtb3ZlLXNlcnZpY2Uge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMDtcbiAgICB0b3A6IDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi5idG4tcmFkaW8ge1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuI2ZuIHtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xufVxuXG4ud2FybiB7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGNvbG9yOiB0cmFuc3BhcmVudDtcbn1cblxuLndhcm4ud2FybmluZy1ncmVlbiB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXG4gICAgdG9wOiAwLjIyNWVtO1xuXG4gICAgd2lkdGg6IDEuMTVlbTtcbiAgICBoZWlnaHQ6IDEuMTVlbTtcblxuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIGJvcmRlci1yYWRpdXM6IDAuNjI1ZW07XG59XG5cbi53YXJuLndhcm5pbmctZ3JlZW46OmJlZm9yZSB7XG4gICAgY29udGVudDogXCJcIjtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB0b3A6IC0wLjA4ZW07XG4gICAgbGVmdDogMC4wZW07XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvcmRlcjogdHJhbnNwYXJlbnQgMC42ZW0gc29saWQ7XG4gICAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzQ0OGIyMztcbiAgICBib3JkZXItYm90dG9tLXdpZHRoOiAxZW07XG4gICAgYm9yZGVyLXRvcC13aWR0aDogMDtcbiAgICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMXB4IDFweDtcbn1cblxuLndhcm4ud2FybmluZy1ncmVlbjo6YWZ0ZXIge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDAuM2VtO1xuICAgIGxlZnQ6IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcGFkZGluZzogMCAxcHg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGZvbnQtZmFtaWx5OiBcIkdhcmFtb25kXCI7XG4gICAgY29udGVudDogXCIhXCI7XG4gICAgZm9udC1zaXplOiAwLjY1ZW07XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG4ud29xb2Qge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICAgIGJveC1zaGFkb3c6ICM0NDhiMjMgMCAwLjVweCAwLjVweDtcbn1cblxuLnNlcnZpY2UtZmVlcyB7XG4gICAgZmxvYXQ6IHJpZ2h0O1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbi5tb2RhbCAubW9kYWwtY29udGVudC1yZWMge1xuICAgIHdpZHRoOiAzMDBweDtcbiAgICBtYXJnaW4tbGVmdDogMjAwcHg7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 97186:
/*!********************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/external-registration/external-registration.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExternalRegistrationComponent": () => (/* binding */ ExternalRegistrationComponent)
/* harmony export */ });
/* harmony import */ var _Users_os_Desktop_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! rxjs */ 68917);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! rxjs */ 56074);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! rxjs */ 63853);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! rxjs */ 91640);
/* harmony import */ var src_app_core_models_add_vehicle_details__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/add-vehicle-details */ 73874);
/* harmony import */ var src_app_core_models_insert_vehicle_equipment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/insert-vehicle-equipment */ 69537);
/* harmony import */ var src_app_core_models_location__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/location */ 83439);
/* harmony import */ var src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/models/register-vehicle */ 54611);
/* harmony import */ var src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/models/service-request */ 84908);
/* harmony import */ var src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/models/vehicle-details */ 43347);
/* harmony import */ var src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/inspectionServiceTypes */ 43327);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/utilities/enums/report-type.enum */ 76622);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/file.service */ 75349);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/purchase.service */ 87010);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../../shared/file-uploads/file-uploads.component */ 19465);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);




































const _c0 = ["fileInput"];
function ExternalRegistrationComponent_h2_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "h2", 45)(1, "button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](2, " Vehicle Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
}
function ExternalRegistrationComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 47)(1, "span", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](2, " Vehicle Summary ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const v_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]().$implicit;
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r16.mapToArea(v_r14.area), " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r17.externalRegForm.get("selectedAreaName").value, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const i_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]().index;
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r18.saveSelectedLocation[i_r15].locationName, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r19.externalRegForm.get("selectedLocationName").value, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const v_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", v_r14.phone, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r21.externalRegForm.get("phone").value, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](9, ExternalRegistrationComponent_div_15_tr_24_td_9_Template, 2, 1, "td", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](10, ExternalRegistrationComponent_div_15_tr_24_td_10_Template, 2, 1, "td", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](11, ExternalRegistrationComponent_div_15_tr_24_td_11_Template, 2, 1, "td", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](12, ExternalRegistrationComponent_div_15_tr_24_td_12_Template, 2, 1, "td", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](13, ExternalRegistrationComponent_div_15_tr_24_td_13_Template, 2, 1, "td", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](14, ExternalRegistrationComponent_div_15_tr_24_td_14_Template, 2, 1, "td", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](17, "td")(18, "button", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_div_15_tr_24_Template_button_click_18_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r26);
      const i_r15 = restoredCtx.index;
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r25.deleteVehicle(i_r15));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](19, "i", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const v_r14 = ctx.$implicit;
    const i_r15 = ctx.index;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", v_r14.vdetails.vinNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", v_r14.vdetails.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r13.mapToPlateName(v_r14.vdetails.plateType), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", v_r14.vCategoryText, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r13.externalRegForm.get("checkAllContact").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r13.externalRegForm.get("checkAllContact").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r13.feesArray[i_r15], " QAR ");
  }
}
function ExternalRegistrationComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 49)(1, "div", 50)(2, "div", 51)(3, "table", 52)(4, "thead")(5, "tr", 53)(6, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](7, " VIN Number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](8, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](9, " Plate Number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](10, "th", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](11, " License Plate Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](12, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](13, " Vehicle Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](14, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](15, " Area ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](16, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](17, " Location ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](18, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](19, " Contact Number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](20, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](21, " Cost ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](22, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](23, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](24, ExternalRegistrationComponent_div_15_tr_24_Template, 20, 11, "tr", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](25, "tr")(26, "td", 57)(27, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](28, " Total Cost ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](29, "td", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](30);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r2.vehicles);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r2.amountTh, " QAR ");
  }
}
function ExternalRegistrationComponent_div_16_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Please, click Enter to proceed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * This Vehicle is Not Registered in MOI ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Vehicle Already Added ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r32.errorMessage, " ");
  }
}
function ExternalRegistrationComponent_div_16_div_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r33.extError, " ");
  }
}
function ExternalRegistrationComponent_div_16_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r34.woqodErrorMsg, " ");
  }
}
function ExternalRegistrationComponent_div_16_option_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r80 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", pt_r80.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", pt_r80.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_select_30_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vc_r82 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", vc_r82.categoryId);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", vc_r82.descriptionEn, "");
  }
}
function ExternalRegistrationComponent_div_16_select_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 108);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("ngModelChange", function ExternalRegistrationComponent_div_16_select_30_Template_select_ngModelChange_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r83.onSelectCategory());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_30_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r37.externalRegForm.get("vehicleCategories").value);
  }
}
function ExternalRegistrationComponent_div_16_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Not an External Vehicle Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 109);
  }
  if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("readonly", ctx_r39.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_select_36_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ot_r86 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ot_r86.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ot_r86.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_36_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r40.externalRegForm.get("ownerTypes").value);
  }
}
function ExternalRegistrationComponent_div_16_input_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("readonly", ctx_r41.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_input_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r42.externalRegForm.get("vdetails").value.ownerPID ? ctx_r42.externalRegForm.get("vdetails").value.ownerPID : "");
  }
}
function ExternalRegistrationComponent_div_16_input_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 113);
  }
}
function ExternalRegistrationComponent_div_16_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r45.externalRegForm.get("vdetails").value.ownerName ? ctx_r45.externalRegForm.get("vdetails").value.ownerName : "");
  }
}
function ExternalRegistrationComponent_div_16_input_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 114);
  }
}
function ExternalRegistrationComponent_div_16_input_52_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 115);
  }
}
function ExternalRegistrationComponent_div_16_input_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 116);
  }
  if (rf & 2) {
    const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r48.externalRegForm.get("vdetails").value.licenseExpiryDate ? ctx_r48.externalRegForm.get("formatExpDate").value : "")("readonly", ctx_r48.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_div_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Invalid date format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_55_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Istimara Date must be valid at least 30 days from now ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r51.externalRegForm.get("vdetails").value.vinNo ? ctx_r51.externalRegForm.get("vdetails").value.vinNo : "");
  }
}
function ExternalRegistrationComponent_div_16_input_62_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 117);
  }
}
function ExternalRegistrationComponent_div_16_select_66_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r88 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", m_r88.manufacturersId);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", m_r88.manufacturersEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r90 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_16_select_66_Template_select_change_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r90);
      const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r89.getModelTypes($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_66_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r53.externalRegForm.get("manufacturerTypes").value);
  }
}
function ExternalRegistrationComponent_div_16_input_67_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 116);
  }
  if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r54.externalRegForm.get("vdetails").value.manufacturersEname ? ctx_r54.externalRegForm.get("vdetails").value.manufacturersEname : "")("readonly", ctx_r54.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_select_71_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r92 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", m_r92.modelId);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", m_r92.modelEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_71_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_71_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r55.externalRegForm.get("modelTypes").value);
  }
}
function ExternalRegistrationComponent_div_16_input_72_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 116);
  }
  if (rf & 2) {
    const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r56.externalRegForm.get("vdetails").value.modelEname ? ctx_r56.externalRegForm.get("vdetails").value.modelEname : "")("readonly", ctx_r56.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_input_76_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r57.externalRegForm.get("vdetails").value.manufacturerYear ? ctx_r57.externalRegForm.get("vdetails").value.manufacturerYear : "");
  }
}
function ExternalRegistrationComponent_div_16_select_77_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const year_r94 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", year_r94);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate"](year_r94);
  }
}
function ExternalRegistrationComponent_div_16_select_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_77_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r58.getYearRange());
  }
}
function ExternalRegistrationComponent_div_16_input_81_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r59.externalRegForm.get("vdetails").value.cylinders ? ctx_r59.externalRegForm.get("vdetails").value.cylinders : "");
  }
}
function ExternalRegistrationComponent_div_16_input_82_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 121);
  }
}
function ExternalRegistrationComponent_div_16_div_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, "Enter a valid vehicle cylinders");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_87_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r62.externalRegForm.get("vdetails").value.weight ? ctx_r62.externalRegForm.get("vdetails").value.weight : "");
  }
}
function ExternalRegistrationComponent_div_16_input_88_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 122);
  }
}
function ExternalRegistrationComponent_div_16_div_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, "Enter a valid weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_93_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r65.externalRegForm.get("vdetails").value.payloadWeight ? ctx_r65.externalRegForm.get("vdetails").value.payloadWeight : "");
  }
}
function ExternalRegistrationComponent_div_16_input_94_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 123);
  }
  if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("readonly", ctx_r66.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_div_95_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, "Enter a valid payload weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_select_99_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r96 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", color_r96.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", color_r96.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_99_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 124);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_99_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r68.externalRegForm.get("colorList").value);
  }
}
function ExternalRegistrationComponent_div_16_input_100_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 125);
  }
  if (rf & 2) {
    const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("readonly", ctx_r69.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_select_104_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r98 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", color_r98.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", color_r98.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_104_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_104_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r70.externalRegForm.get("colorList").value);
  }
}
function ExternalRegistrationComponent_div_16_input_105_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 116);
  }
  if (rf & 2) {
    const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r71.externalRegForm.get("subclr").value)("readonly", ctx_r71.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_input_109_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r72.externalRegForm.get("vdetails").value.noOfSeat ? ctx_r72.externalRegForm.get("vdetails").value.noOfSeat : "");
  }
}
function ExternalRegistrationComponent_div_16_input_110_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 127);
  }
}
function ExternalRegistrationComponent_div_16_div_111_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, "Enter a valid seat number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_113_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" Reinspection ", ctx_r99.externalRegForm.get("noOfReinspections").value, "");
  }
}
function ExternalRegistrationComponent_div_16_div_113_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 128);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](1, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](2, ExternalRegistrationComponent_div_16_div_113_span_2_Template, 2, 1, "span", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r75.isReinspectionExt);
  }
}
function ExternalRegistrationComponent_div_16_div_114_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 130);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](1, "div", 131);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](3, " Woqod Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
}
function ExternalRegistrationComponent_div_16_div_115_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 132)(1, "label", 133);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](2, "input", 134)(3, "span", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](4, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](5, "Apply Staff Rate");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵstyleProp"]("pointer-events", ctx_r77.disableStaffRate ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("checked", ctx_r77.externalRegForm.get("isStaffRate").value);
  }
}
function ExternalRegistrationComponent_div_16_span_122_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "span", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r79.fileName, " ");
  }
}
function ExternalRegistrationComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r101 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 62)(1, "div", 50)(2, "div", 63)(3, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](4, "img", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](5, "div", 66)(6, "input", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("keyup.enter", function ExternalRegistrationComponent_div_16_Template_input_keyup_enter_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r101);
      const ctx_r100 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r100.barCodeScanner());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](7, ExternalRegistrationComponent_div_16_div_7_Template, 2, 0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](8, ExternalRegistrationComponent_div_16_div_8_Template, 2, 0, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](9, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](10, "div", 63)(11, "div", 64)(12, "label", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](13, " License Plate No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](14, "input", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("ngModelChange", function ExternalRegistrationComponent_div_16_Template_input_ngModelChange_14_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r101);
      const ctx_r102 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r102.savePlateNo = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](15, ExternalRegistrationComponent_div_16_div_15_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_16_div_16_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](17, ExternalRegistrationComponent_div_16_div_17_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](18, ExternalRegistrationComponent_div_16_div_18_Template, 2, 1, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](19, ExternalRegistrationComponent_div_16_div_19_Template, 2, 1, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](20, ExternalRegistrationComponent_div_16_div_20_Template, 2, 1, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](21, "div", 64)(22, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](23, " License Plate Type * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](24, "select", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](25, ExternalRegistrationComponent_div_16_option_25_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](26, ExternalRegistrationComponent_div_16_div_26_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](27, "div", 64)(28, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](29, "Vehicle Category");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](30, ExternalRegistrationComponent_div_16_select_30_Template, 2, 1, "select", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](31, ExternalRegistrationComponent_div_16_div_31_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](32, ExternalRegistrationComponent_div_16_input_32_Template, 1, 1, "input", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](33, "div", 64)(34, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](35, "Owner PID Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](36, ExternalRegistrationComponent_div_16_select_36_Template, 2, 1, "select", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](37, ExternalRegistrationComponent_div_16_input_37_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](38, "div", 64)(39, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](40, "Owner PID");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](41, ExternalRegistrationComponent_div_16_input_41_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](42, ExternalRegistrationComponent_div_16_input_42_Template, 1, 0, "input", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](43, ExternalRegistrationComponent_div_16_div_43_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](44, "div", 64)(45, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](46, "Owner Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](47, ExternalRegistrationComponent_div_16_input_47_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](48, ExternalRegistrationComponent_div_16_input_48_Template, 1, 0, "input", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](49, "div", 64)(50, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](51, "Istimara Expiry Date");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](52, ExternalRegistrationComponent_div_16_input_52_Template, 1, 0, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](53, ExternalRegistrationComponent_div_16_input_53_Template, 1, 2, "input", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](54, ExternalRegistrationComponent_div_16_div_54_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](55, ExternalRegistrationComponent_div_16_div_55_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](56, "div", 84)(57, "div", 63)(58, "div", 64)(59, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](60, "VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](61, ExternalRegistrationComponent_div_16_input_61_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](62, ExternalRegistrationComponent_div_16_input_62_Template, 1, 0, "input", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](63, "div", 64)(64, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](65, "Manufacturer");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](66, ExternalRegistrationComponent_div_16_select_66_Template, 2, 1, "select", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](67, ExternalRegistrationComponent_div_16_input_67_Template, 1, 2, "input", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](68, "div", 64)(69, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](70, "Model");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](71, ExternalRegistrationComponent_div_16_select_71_Template, 2, 1, "select", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](72, ExternalRegistrationComponent_div_16_input_72_Template, 1, 2, "input", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](73, "div", 64)(74, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](75, "Manufacturing Year");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](76, ExternalRegistrationComponent_div_16_input_76_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](77, ExternalRegistrationComponent_div_16_select_77_Template, 2, 1, "select", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](78, "div", 64)(79, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](80, "Cylinders");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](81, ExternalRegistrationComponent_div_16_input_81_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](82, ExternalRegistrationComponent_div_16_input_82_Template, 1, 0, "input", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](83, ExternalRegistrationComponent_div_16_div_83_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](84, "div", 64)(85, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](86, "Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](87, ExternalRegistrationComponent_div_16_input_87_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](88, ExternalRegistrationComponent_div_16_input_88_Template, 1, 0, "input", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](89, ExternalRegistrationComponent_div_16_div_89_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](90, "div", 64)(91, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](92, "Payload Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](93, ExternalRegistrationComponent_div_16_input_93_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](94, ExternalRegistrationComponent_div_16_input_94_Template, 1, 1, "input", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](95, ExternalRegistrationComponent_div_16_div_95_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](96, "div", 64)(97, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](98, "Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](99, ExternalRegistrationComponent_div_16_select_99_Template, 2, 1, "select", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](100, ExternalRegistrationComponent_div_16_input_100_Template, 1, 1, "input", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](101, "div", 64)(102, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](103, "Sub Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](104, ExternalRegistrationComponent_div_16_select_104_Template, 2, 1, "select", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](105, ExternalRegistrationComponent_div_16_input_105_Template, 1, 2, "input", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](106, "div", 64)(107, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](108, "Seats");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](109, ExternalRegistrationComponent_div_16_input_109_Template, 1, 1, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](110, ExternalRegistrationComponent_div_16_input_110_Template, 1, 0, "input", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](111, ExternalRegistrationComponent_div_16_div_111_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](112, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](113, ExternalRegistrationComponent_div_16_div_113_Template, 3, 1, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](114, ExternalRegistrationComponent_div_16_div_114_Template, 4, 0, "div", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](115, ExternalRegistrationComponent_div_16_div_115_Template, 6, 3, "div", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](116, "div", 96)(117, "input", 100, 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_16_Template_input_change_117_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r101);
      const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r103.handleFile($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](119, "button", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](120, "span", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](121, " Attachement ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](122, ExternalRegistrationComponent_div_16_span_122_Template, 2, 1, "span", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("barCode").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("barCode").value && !ctx_r3.externalRegForm.get("barCode").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngModel", ctx_r3.savePlateNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPlateNo").invalid && ctx_r3.externalRegForm.get("inputPlateNo").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("showMoiError").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.duplicateError);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.errorMessage);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.isExt);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.isWoqodAdded != ctx_r3.isWoqod);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r3.externalRegForm.get("plateTypes").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPlateType").invalid && ctx_r3.externalRegForm.get("inputPlateType").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value || ctx_r3.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.vehicleCategError);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value && !ctx_r3.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPid").invalid && ctx_r3.externalRegForm.get("inputPid").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("expDate").hasError("invalidDate") && ctx_r3.externalRegForm.get("expDate").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("expDate").hasError("futureDate"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputCylinders").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value && !ctx_r3.isWeightZero);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value || ctx_r3.isWeightZero);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputWeight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPayloadweight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputNbSeats").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.isReinspectionExt);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.isWoqod);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("isStaffRateValue").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r3.fileName);
  }
}
function ExternalRegistrationComponent_div_18_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Enter a valid mobile number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " * Enter a valid PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, "Enter a valid email address");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 2)(1, "div", 4)(2, "div", 137)(3, "div", 6)(4, "div", 138)(5, "div", 8)(6, "h2", 47)(7, "button", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](8, " Contact Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](9, "div", 140)(10, "div", 50)(11, "div", 63)(12, "div", 64)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](14, "Phone No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](15, "input", 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_18_div_16_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](17, ExternalRegistrationComponent_div_18_div_17_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](18, "div", 64)(19, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](20, "PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](21, "input", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](22, ExternalRegistrationComponent_div_18_div_22_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](23, "div", 64)(24, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](25, " Email ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](26, "input", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](27, ExternalRegistrationComponent_div_18_div_27_Template, 2, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("readonly", ctx_r4.externalRegForm.get("checkAllContact").value && ctx_r4.isInputReadOnly.phone);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("phone").hasError("required") && ctx_r4.externalRegForm.get("phone").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("phone").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("readonly", ctx_r4.externalRegForm.get("checkAllContact").value && ctx_r4.isInputReadOnly.pid);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("pid").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("readonly", ctx_r4.externalRegForm.get("checkAllContact").value && ctx_r4.isInputReadOnly.email);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("email").hasError("email"));
  }
}
function ExternalRegistrationComponent_div_19_select_15_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const area_r113 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", area_r113.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate"](area_r113.labelEname);
  }
}
function ExternalRegistrationComponent_div_19_select_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r115 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 155);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_19_select_15_Template_select_change_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r115);
      const ctx_r114 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r114.getLocationArea());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_19_select_15_option_1_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r108.areaList);
  }
}
function ExternalRegistrationComponent_div_19_input_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 156);
  }
  if (rf & 2) {
    const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r109.externalRegForm.get("selectedAreaName").value);
  }
}
function ExternalRegistrationComponent_div_19_select_20_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const location_r117 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", location_r117.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"]("", location_r117.labelEname, " ");
  }
}
function ExternalRegistrationComponent_div_19_select_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r119 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "select", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_19_select_20_Template_select_change_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r119);
      const ctx_r118 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r118.onSelectLocation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](1, "option");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](2, ExternalRegistrationComponent_div_19_select_20_option_2_Template, 2, 2, "option", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r110 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵclassProp"]("readonly", ctx_r110.externalRegForm.get("checkAllLocation").value && ctx_r110.externalRegForm.get("selectedLocation").value != "");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r110.locationList);
  }
}
function ExternalRegistrationComponent_div_19_input_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](0, "input", 156);
  }
  if (rf & 2) {
    const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", ctx_r111.externalRegForm.get("selectedLocationName").value);
  }
}
function ExternalRegistrationComponent_div_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 2)(1, "div", 4)(2, "div", 137)(3, "div", 6)(4, "div", 144)(5, "div", 8)(6, "h2", 47)(7, "button", 145);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](8, " Area - Location ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](9, "div", 146)(10, "div", 50)(11, "div", 63)(12, "div", 64)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](14, " Area * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](15, ExternalRegistrationComponent_div_19_select_15_Template, 2, 1, "select", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_19_input_16_Template, 1, 1, "input", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](17, "div", 64)(18, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](19, " Location * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](20, ExternalRegistrationComponent_div_19_select_20_Template, 3, 3, "select", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](21, ExternalRegistrationComponent_div_19_input_21_Template, 1, 1, "input", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](22, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](23, "div", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](24, "input", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](25, "label", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](26, " Apply this contact to all vehicles ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](27, "div", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](28, "input", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](29, "label", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](30, " Apply this location to all vehicles ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r5.externalRegForm.get("checkAllLocation").value || ctx_r5.externalRegForm.get("selectedArea").value == "" || !ctx_r5.isInputReadOnly.loc);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r5.externalRegForm.get("checkAllLocation").value && ctx_r5.isInputReadOnly.loc);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx_r5.externalRegForm.get("checkAllLocation").value || ctx_r5.externalRegForm.get("selectedLocation").value == "" || !ctx_r5.isInputReadOnly.loc);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r5.externalRegForm.get("checkAllLocation").value && ctx_r5.isInputReadOnly.loc);
  }
}
function ExternalRegistrationComponent_button_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r121 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "button", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_24_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r121);
      const ctx_r120 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r120.backToScreen());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Add New Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_button_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r123 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "button", 159);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_25_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r123);
      const ctx_r122 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r122.addVehicle());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Add Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("disabled", !ctx_r7.externalRegForm.valid || !ctx_r7.isValidInput || ctx_r7.vehicleCategError);
  }
}
function ExternalRegistrationComponent_button_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r125 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "button", 160);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_26_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r125);
      const ctx_r124 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r124.viewAddedVehicles());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " View Added Vehicles ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_button_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "button", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Confirm & Pay ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("disabled", ctx_r9.inserted || ctx_r9.vehicles.length == 0);
  }
}
function ExternalRegistrationComponent_button_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r127 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "button", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_44_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r127);
      const ctx_r126 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r126.continueInsertPay());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](1, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 35)(1, "div", 22)(2, "div", 37)(3, "h1", 163);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](4, " Payment ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](5, "div", 41)(6, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](7, " The vehicle is registered for a Staff or as Woqod vehicle");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()();
  }
}
function ExternalRegistrationComponent_div_47_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r133 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 174)(1, "input", 175);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("ngModelChange", function ExternalRegistrationComponent_div_47_div_8_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r133);
      const ctx_r132 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r132.onSelectPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](2, "label", 176);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const pt_r131 = ctx.$implicit;
    const ctx_r128 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("id", "pt" + pt_r131.lkCodeValue)("value", pt_r131.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵattribute"]("disabled", !ctx_r128.enableCashMethodSetting && pt_r131.lkCodeValue == 1 ? true : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("for", "pt" + pt_r131.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", pt_r131.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_47_div_10_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "ng-option", 183)(1, "div", 184);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r135 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", c_r135.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", c_r135.customerName, " ");
  }
}
function ExternalRegistrationComponent_div_47_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r137 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 177)(1, "div", 178)(2, "label", 179);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](4, "ng-select", 180);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_47_div_10_Template_ng_select_change_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r137);
      const ctx_r136 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r136.isPaymentValid = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementContainerStart"](5, 181);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](6, "ng-option", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](7, ExternalRegistrationComponent_div_47_div_10_ng_option_7_Template, 3, 2, "ng-option", 182);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r129 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r129.creditCustomerList);
  }
}
function ExternalRegistrationComponent_div_47_tr_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const e_r138 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", e_r138.vinNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", e_r138.amount, " QAR ");
  }
}
function ExternalRegistrationComponent_div_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r140 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "div", 35)(1, "div", 22)(2, "div", 37)(3, "h1", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](4, "Payment Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](5, "div", 41)(6, "div", 164)(7, "div", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](8, ExternalRegistrationComponent_div_47_div_8_Template, 4, 5, "div", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](9, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](10, ExternalRegistrationComponent_div_47_div_10_Template, 8, 4, "div", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](11, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](12, "div", 168)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](14, "Summary Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](15, "div", 2)(16, "div", 169)(17, "table", 170)(18, "thead")(19, "tr")(20, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](21, "Vehicle VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](22, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](23, "Fees");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](24, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](25, ExternalRegistrationComponent_div_47_tr_25_Template, 5, 2, "tr", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](26, "tfoot")(27, "tr")(28, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](29, "Total");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](30, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](32, "div", 171)(33, "button", 172);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_div_47_Template_button_click_33_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r140);
      const ctx_r139 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r139.closePayPop());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](34, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](35, "button", 173);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_div_47_Template_button_click_35_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵrestoreView"](_r140);
      const ctx_r141 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵresetView"](ctx_r141.submitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](36, "Submit");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r12.externalRegForm.get("paymentTypes").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx_r12.externalRegForm.get("showCredit").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngForOf", ctx_r12.listVehicle);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtextInterpolate1"](" ", ctx_r12.amountTh, " QAR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("disabled", !ctx_r12.isPaymentValid);
  }
}
class ExternalRegistrationComponent {
  constructor(fb, render, fileService, lookupServ, vehicleService, purchase, router, sharedLookup, sideNav, paymentService, ssrsPrintServ, sharedDataService, globalServ, el, thousandSeparator, sysAdminService) {
    this.fb = fb;
    this.render = render;
    this.fileService = fileService;
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.purchase = purchase;
    this.router = router;
    this.sharedLookup = sharedLookup;
    this.sideNav = sideNav;
    this.paymentService = paymentService;
    this.ssrsPrintServ = ssrsPrintServ;
    this.sharedDataService = sharedDataService;
    this.globalServ = globalServ;
    this.el = el;
    this.thousandSeparator = thousandSeparator;
    this.sysAdminService = sysAdminService;
    this.isPaymentStarted = false;
    this.printReceiptDirectly = false;
    //vehicleDetailsModel: VehicleDetails;
    this.vehicles = [];
    this.equipments = [];
    this.creditCustomerList = [];
    this.inputPlateTypeTouched = false;
    this.inserted = false;
    this.paymentName = 'Card';
    this.listVehicle = [];
    this.saveSelectedLocation = [];
    this.isWoqod = false;
    this.isWoqodAdded = false;
    this.isInputReadOnly = {
      phone: false,
      email: false,
      pid: false,
      loc: false
    };
    this.displayPaymentDetails = 'none';
    this.enableCategorySelection = false;
    this.vehicleCategError = false;
    this.feesDetails = [];
    this.enableCashMethodSetting = true;
    this.isPaymentValid = true;
    this.feesArray = [];
    this.disableStaffRate = true;
    this.areaList = [];
    this.locationList = [];
    this.externalRegForm = this.fb.group({
      inputPlateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required],
      inputPlateNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required],
      selectedPayment: ['Card'],
      selectedOwnerType: [''],
      selectedServType: [1],
      selectedServName: [''],
      selectedManufacturer: [],
      selectedModel: [],
      selectedVehicleCategory: null,
      selectedColor: [''],
      selectedSubColor: [''],
      selectedArea: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required],
      selectedLocation: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required],
      selectedAreaName: [''],
      selectedLocationName: [''],
      selectedCust: [],
      checkAllContact: [false],
      checkAllLocation: [false],
      nonEditable: [true],
      isStaffRate: [false],
      isStaffRateValue: [false],
      showCredit: [false],
      showErrorPopup: [true],
      showScreen: [true],
      vdetails: [{}],
      colorList: [[]],
      ownerTypes: [[]],
      plateTypes: [[]],
      manufacturerTypes: [[]],
      modelTypes: [[]],
      vehicleCategories: [[]],
      lookupValues: [{}],
      expDate: [''],
      pidValue: [''],
      colorValue: [''],
      subclr: [' '],
      vcategory: [''],
      fees: [],
      feesDiscount: [],
      amount: [],
      inputOwnerType: [''],
      inputPid: [' ', [_angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required]],
      inputOwnerName: [''],
      inputVinNo: [' ', _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required],
      inputManfYear: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern('^[0-9]*$')],
      inputCylinders: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern('^[0-9]*$')],
      inputWeight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern('^[0-9]*$')],
      inputPayloadweight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern('^[0-9]*$')],
      inputNbSeats: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern('^[0-9]*$')],
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern(/^[34567]\d{7}$/)]],
      pid: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern(/^.{1,20}$/)]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.email, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern(/^.{1,60}$/)]],
      cost: [],
      totalCost: [0],
      canPay: [false],
      isAddVehicle: [false],
      paymentTypes: [[]],
      formatExpDate: [],
      showMoiError: [],
      barCode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.pattern(/^.{3,8}$/)],
      noOfReinspections: [null]
    });
  }
  onKeydown(event) {
    if (event.target instanceof HTMLInputElement && event.target.type === 'number') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
      }
    }
  }
  dateValidator(control) {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();
    const minDate = new Date(currentDate);
    minDate.setDate(currentDate.getDate() + 30);
    if (isNaN(selectedDate.getTime())) {
      return {
        invalidDate: true
      };
    }
    if (selectedDate < minDate) {
      return {
        futureDate: true
      };
    }
    return null;
  }
  getYearRange() {
    const startYear = 1900;
    const currentYear = new Date().getFullYear();
    const yearRange = [];
    for (let year = currentYear + 1; year >= startYear; year--) {
      yearRange.push(year);
    }
    return yearRange;
  }
  qatarPhoneNumberValidator() {
    return control => {
      const phoneNumber = control.value;
      if (!phoneNumber) {
        return null; // If the control is empty, consider it valid.
      }
      // Remove any non-digit characters and spaces
      const cleanedPhoneNumber = phoneNumber.replace(/[^0-9]/g, '');
      // Check if the cleaned phone number matches the Qatar format
      if (/^(974)?[56789]\d{7}$/.test(cleanedPhoneNumber)) {
        // Format the phone number in the desired format
        const formattedPhoneNumber = `+974 ${cleanedPhoneNumber.substring(1, 4)} ${cleanedPhoneNumber.substring(4)}`;
        // Update the control's value with the formatted phone number
        control.setValue(formattedPhoneNumber);
        return null; // Validation passed
      } else {
        return {
          qatarPhoneNumber: true
        }; // Validation failed
      }
    };
  }

  ngOnInit() {
    this.sideNav.setActiveEnt(2, 4);
    /* this.sharedDataService.userId$.subscribe((userId) => {
       this.userId = userId;
     });*/
    /* this.sharedDataService.stationId$.subscribe((res) => {
       this.stationId = res;
     }); */
    this.userId = parseInt(localStorage.getItem('userId'));
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.extData = this.externalRegForm.value;
    this.sharedLookup.colorList$.subscribe(data => {
      this.externalRegForm.get('colorList').setValue(data);
    });
    this.sharedLookup.ownerTypes$.subscribe(data => {
      this.externalRegForm.get('ownerTypes').setValue(data);
    });
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.externalRegForm.get('vehicleCategories').setValue(data);
    });
    this.sharedLookup.manufacturerTypes$.subscribe(data => {
      this.externalRegForm.get('manufacturerTypes').setValue(data);
    });
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.externalRegForm.get('plateTypes').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_12__.SystemLookupCodes.paymentMethods).subscribe(data => {
      this.externalRegForm.get('paymentTypes').setValue(data.items);
      const firstPaymentType = data.items.find(item => item.lkValueAname === 'Card').lkCodeValue;
      this.externalRegForm.get('selectedPayment').setValue(firstPaymentType);
    });
    this.vehicleService.getAreas().subscribe(data => {
      this.areaList = data.items;
    });
    this.externalRegForm.get('inputPlateNo').valueChanges.subscribe(value => {
      if (this.externalRegForm.get('inputPlateNo').valueChanges) {
        this.externalRegForm.get('barCode').value ? null : this.externalRegForm.get('inputPlateType').setValue('');
        this.enableCategorySelection = false;
        this.vehicleCategError = false;
        this.woqodErrorMsg = '';
        this.extError = '';
        this.duplicateError = false;
        this.isWoqod = false;
      }
    });
    this.externalRegForm.get('inputPlateType').valueChanges.subscribe(value => {
      if (!this.externalRegForm.get('barCode').value) {
        this.savePlateNo = parseInt(this.externalRegForm.get('inputPlateNo').value);
        this.savePlateType = parseInt(this.externalRegForm.get('inputPlateType').value);
        this.getVehicleDetails();
        this.isValidInput = true;
      } else {
        this.savePlateType = this.externalRegForm.get('inputPlateType').value;
        this.getVehicleDetails();
      }
    });
    // check if cash is enabled
    this.sharedDataService.stationSetting$.subscribe(res => {
      const checkCashMethod = res.find(item => item.key === "EnableCashMethod" && item.value === "True");
      if (checkCashMethod != undefined) {
        this.enableCashMethodSetting = checkCashMethod;
      }
    });
    // check if email has been already added
    this.externalRegForm.get('email').valueChanges.subscribe(value => {
      if (this.externalRegForm.get('email').valid) {
        this.sendEmail = true;
      }
    });
  }
  onFileUploaded(fname) {
    this.fileName = fname;
  }
  barCodeScanner() {
    const barCodeTxt = this.externalRegForm.get('barCode').value;
    if (barCodeTxt) {
      this.savePlateNo = parseInt(barCodeTxt.substring(2));
      this.savePlateType = parseInt(barCodeTxt.substring(0, 2));
      this.externalRegForm.get('inputPlateType').setValue(this.savePlateType);
      //this.getVehicleDetails();
    }
  }

  getLocationArea() {
    this.vehicleService.getAreaLocations(this.externalRegForm.get('selectedArea').value).subscribe(data => {
      this.locationList = data.items;
    });
    this.externalRegForm.get('selectedAreaName').setValue(this.areaList.find(area => area.value == this.externalRegForm.get('selectedArea').value).labelEname);
  }
  onInputBlur() {
    this.isInputReadOnly['phone'] = true;
    this.isInputReadOnly['email'] = true;
    this.isInputReadOnly['pid'] = true;
  }
  onSelectLocation() {
    this.externalRegForm.get('selectedLocationName').setValue(this.locationList.find(loc => loc.value == this.externalRegForm.get('selectedLocation').value).labelEname);
    const location = new src_app_core_models_location__WEBPACK_IMPORTED_MODULE_3__.Locations(this.externalRegForm.get('selectedLocation').value, this.externalRegForm.get('selectedLocationName').value, this.externalRegForm.get('selectedArea').value);
    this.saveSelectedLocation.push(location);
  }
  mapToPlateName(pltType) {
    return this.externalRegForm.get('plateTypes').value.find(plt => plt.lkCodeValue == pltType).lkValueEname;
  }
  mapToArea(areaId) {
    return this.areaList.find(area => area.value == areaId).labelEname;
  }
  mapToLocation(locId, areaId) {
    const location = this.locationList.find(loc => loc.value == locId);
    return location.labelEname;
  }
  getModelTypes(event) {
    this.vehicleService.getModelsByManufacturerId(this.externalRegForm.get('selectedManufacturer').value).subscribe(data => {
      this.externalRegForm.get('modelTypes').setValue(data.items);
    });
  }
  // Integrate with API GetVehicleDetails to return data from MOI/Vehicles table database
  getVehicleDetails() {
    this.externalRegForm.get("showMoiError").setValue(false);
    this.errorMessage = '';
    if (this.externalRegForm.get('inputPlateType').value && this.externalRegForm.get('inputPlateType').value || this.savePlateNo && this.savePlateType) {
      const vehDetails = {
        plateNo: this.savePlateNo,
        plateType: this.savePlateType,
        stationId: this.stationId
      };
      // check if the vehicle is already added
      const plateNumberExists = this.vehicles.some(vehicle => vehicle.vdetails.plateNo == vehDetails.plateNo);
      if (this.vehicles.length > 0 && plateNumberExists) {
        this.duplicateError = true;
      } else {
        this.duplicateError = false;
        if (vehDetails.plateNo) {
          this.vehicleService.getVehicleDetails(vehDetails).subscribe(response => {
            if (response.items) {
              this.externalRegForm.get('vdetails').setValue(response.items);
              if (response.items.weight > 0) {
                this.isWeightZero = false;
              } else {
                this.isWeightZero = true;
              }
              this.externalRegForm.get('barCode').setValue('');
              this.isWoqod = this.externalRegForm.get('vdetails').value.isWaqodVehicle;
              if (this.externalRegForm.get('vdetails').value.isExternal || this.externalRegForm.get('vdetails').value.categoryId == 0) {
                if (this.vehicles.length == 0 || this.vehicles.length > 0 && this.isWoqodAdded === this.isWoqod) {
                  this.isExt = true;
                  this.externalRegForm.get('vdetails').value.isReinspection ? this.isReinspectionExt = true : this.isReinspectionExt = false;
                  this.externalRegForm.get('noOfReinspections').setValue(this.externalRegForm.get('vdetails').value.noOfReinspections);
                  this.externalRegForm.get('inputVinNo').setValidators(null);
                  this.externalRegForm.get('inputManfYear').setValidators(null);
                  this.externalRegForm.get('inputCylinders').setValidators(null);
                  this.externalRegForm.get('inputNbSeats').setValidators(null);
                  this.externalRegForm.updateValueAndValidity();
                  const color = this.externalRegForm.get('colorList').value.find(color => color.lkCodeValue == this.externalRegForm.get('vdetails').value.colorId);
                  this.externalRegForm.get('colorValue').setValue(color.lkValueEname);
                  this.externalRegForm.get('pidValue').setValue(this.externalRegForm.get('ownerTypes').value.find(pid => pid.lkCodeValue == this.externalRegForm.get('vdetails').value.ownerPidType).lkValueEname);
                  this.savePid = this.externalRegForm.get('vdetails').value.ownerPidType;
                  // if category is null enable manual selection for vehicle category
                  if (this.externalRegForm.get('vdetails').value.categoryId) {
                    this.externalRegForm.get('vcategory').setValue(this.externalRegForm.get('vehicleCategories').value.find(category => category.categoryId == this.externalRegForm.get('vdetails').value.categoryId).descriptionEn);
                    this.enableCategorySelection = false;
                  } else {
                    this.enableCategorySelection = true;
                    // if the clerk will manually select the vehicle category it should be required field
                    this.externalRegForm.get('selectedVehicleCategory').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_29__.Validators.required);
                    // Trigger re-validation
                    this.externalRegForm.get('selectedVehicleCategory').updateValueAndValidity();
                  }
                  this.externalRegForm.get('isStaffRate').setValue(this.externalRegForm.get('vdetails').value.isStaffVehicle);
                  this.externalRegForm.get('isStaffRateValue').setValue(this.externalRegForm.get('vdetails').value.isStaffVehicle);
                  if (this.externalRegForm.get('vdetails').value.isStaffVehicle) {
                    this.sysAdminService.getUserRoles({
                      userId: this.userId
                    }).subscribe(response => {
                      for (let r of response.items) {
                        if (r.roleId == 2) {
                          this.disableStaffRate = false;
                        }
                      }
                    });
                  }
                  this.externalRegForm.get('nonEditable').setValue(true);
                  this.vinNo = this.externalRegForm.get('vdetails').value.vinNo;
                  const isoDate = new Date(this.externalRegForm.get('vdetails').value.licenseExpiryDate);
                  const dateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_30__.DatePipe('en-US').transform(isoDate, 'dd-MM-yyyy');
                  this.externalRegForm.get('formatExpDate').setValue(dateFormat);
                  this.externalRegForm.get('showMoiError').setValue(false);
                  if (!this.externalRegForm.get('checkAllContact').value) {
                    this.externalRegForm.get('phone').setValue(this.externalRegForm.get('vdetails').value.contactPersonPhone);
                    this.externalRegForm.get('email').setValue(this.externalRegForm.get('vdetails').value.contactPersonEmail);
                    this.externalRegForm.get('pid').setValue(this.externalRegForm.get('vdetails').value.contactPersonPID);
                  }
                  this.externalRegForm.get('subclr').setValue(this.externalRegForm.get('colorList').value.find(color => color.lkCodeValue == this.externalRegForm.get('vdetails').value.subColorId).lkValueEname);
                } else {
                  this.woqodErrorMsg = this.isWoqodAdded ? "Kindly, add Woqod Vehicles" : "Cannot add Woqod Vehicle";
                  this.externalRegForm.get('vdetails').setValue({});
                  this.isValidInput = false;
                }
              } else {
                this.extError = "* Not an External Vehicle";
                this.isExt = false;
                this.externalRegForm.get('vdetails').setValue({});
              }
            }
          }, error => {});
        } else {
          this.enableCategorySelection = false;
        }
      }
    }
    this.externalRegForm.get('vdetails').setValue({});
    this.externalRegForm.get('vcategory').setValue('');
    this.externalRegForm.get('selectedVehicleCategory').setValue('');
    this.externalRegForm.get('pidValue').setValue('');
    this.externalRegForm.get('colorValue').setValue('');
    this.externalRegForm.get('subclr').setValue('');
    this.externalRegForm.get('isStaffRate').setValue(false);
    this.externalRegForm.get('inputPid').setValidators(null);
    this.enableCategorySelection = false;
    this.vehicleCategError = false;
  }
  onSelectCategory() {
    const selectedVehicle = this.externalRegForm.get('selectedVehicleCategory').value;
    if (selectedVehicle == 1 || selectedVehicle == 11 || selectedVehicle == 12) {
      this.vehicleCategError = false;
    } else {
      this.vehicleCategError = true;
    }
  }
  get invalidFormControls() {
    return Object.keys(this.externalRegForm.controls).filter(controlName => this.externalRegForm.controls[controlName].invalid);
  }
  selectFile() {
    this.render.selectRootElement(this.fileInput.nativeElement).click();
  }
  handleFile(event) {
    const inputElement = event.target;
    const selectedFile = inputElement.files[0];
    if (selectedFile) {
      const fileData = new FormData();
      fileData.append('file', selectedFile);
      this.fileService.handleFileService(fileData);
    }
  }
  onSelectPayment() {
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.CreditCustomer) {
      this.externalRegForm.get('showCredit').setValue(true);
      this.vehicleService.getCreditCustomer(this.externalRegForm.get('selectedCust').value).subscribe(data => {
        this.creditCustomerList = data.items;
      });
      this.isPaymentValid = this.externalRegForm.get('selectedCust').value ? true : false;
    } else {
      this.externalRegForm.get('showCredit').setValue(false);
      this.isPaymentValid = true;
    }
    this.paymentName = this.externalRegForm.get('paymentTypes').value.find(payId => payId.lkCodeValue == this.externalRegForm.get('selectedPayment').value).lkValueEname;
  }
  submitPayment() {
    const date = new Date();
    this.currentDateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_30__.DatePipe('en-US').transform(date, 'dd MMM yyyy');
    this.currentTimeFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_30__.DatePipe('en-US').transform(date, 'h:mm a');
    if (this.isWoqodAdded) {
      this.externalRegForm.get('selectedPayment').setValue(4);
    }
    let payment = {
      paymentMethodId: this.externalRegForm.get('selectedPayment').value,
      serviceRequestFeesDto: [{
        feesAmount: this.externalRegForm.get('totalCost').value,
        requestId: this.requestId,
        serviceTypeId: 1,
        customerId: this.externalRegForm.get('selectedCust').value == undefined ? null : parseInt(this.externalRegForm.get('selectedCust').value),
        subDiscount: 0
      }]
    };
    this.isPaymentStarted = true;
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.Card) {
      this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_31__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_32__.catchError)(error => {
        if (error.name === 'TimeoutError') {
          this.isNotReachable = true;
          this.displayPaymentDetails = 'block';
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_33__.throwError)(error);
      })).subscribe(data => {
        const paymentResult = data;
        const isCaptured = paymentResult.items.isCaptured;
        const isCanceled = paymentResult.items.isCanceled;
        const isDeviceNotReachable = paymentResult.items.isDeviceNotReachable;
        const messageCode = paymentResult.messageCode;
        const errorMessage = paymentResult.errorMessage;
        if (data.items) {
          if (!paymentResult.items.isCaptured && !paymentResult.items.isDeviceNotReachable) {
            this.isSuccess = true;
            let customerReportDto = {
              requestId: this.requestId,
              isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
              moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
              reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.CustomerReport
            };
            let inspectorReportDto = {
              requestId: this.requestId,
              isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
              moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
              reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.InspectorReport
            };
            let reports = [customerReportDto, inspectorReportDto];
            this.ssrsPrintServ.printReports(reports);
            setTimeout(() => {
              this.isPaymentStarted = false;
              this.cancelExt();
            }, 3000);
          } else {
            if (paymentResult.items.isCaptured) {
              this.isSuccess = true;
            }
            if (paymentResult.items.isCanceled) {
              this.isPayCanceled = true;
            }
            if (paymentResult.items.isDeviceNotReachable) {
              this.isNotReachable = true;
            }
          }
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        console.error(error);
        this.displayPaymentDetails = 'block';
      });
    }
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.Cash) {
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          let customerReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.CustomerReport
          };
          let inspectorReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.InspectorReport
          };
          let reports = [customerReportDto, inspectorReportDto];
          this.ssrsPrintServ.printReports(reports);
          this.isSuccess = true;
          this.isNotReachable = false;
          this.isPayCanceled = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.cancelExt();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isPayCanceled = false;
          this.isSuccess = false;
        }
      }, error => {
        this.isSuccess = false;
      });
    }
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.CreditCustomer) {
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          this.amountTh = '';
          let customerReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.CustomerReport
          };
          let inspectorReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.InspectorReport
          };
          let reports = [customerReportDto, inspectorReportDto];
          this.ssrsPrintServ.printReports(reports);
          this.isSuccess = true;
          this.isPayCanceled = false;
          this.isNotReachable = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.cancelExt();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isSuccess = false;
          this.isPayCanceled = false;
        }
      }, error => {
        this.isSuccess = false;
      });
    }
    if (!this.externalRegForm.get('showScreen').value && this.isWoqodAdded) {
      const modalElement = document.getElementById('PrintReceipt');
      setTimeout(() => {
        if (modalElement) {
          modalElement.classList.remove('show');
          modalElement.style.display = 'none';
          document.body.classList.remove('modal-open');
          const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
          if (modalBackdrop) {
            modalBackdrop.remove();
          }
          document.body.style.overflow = 'auto';
        }
        this.cancelExt();
      }, 2000);
    }
  }
  sendPayment() {}
  downloadPayment() {
    this.ssrsPrintServ.downloadCustomerReport(this.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.save, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external);
  }
  addVehicle() {
    this.isWoqodAdded = this.isWoqod;
    let saveLocId;
    let saveAreaId;
    this.contactPhone = this.externalRegForm.get("phone").value;
    this.contactEmail = this.externalRegForm.get("email").value;
    this.contactPid = this.externalRegForm.get("pid").value;
    if (this.externalRegForm.get('checkAllContact').value) {
      this.onInputBlur();
    }
    if (this.externalRegForm.get('checkAllLocation').value) {
      this.isInputReadOnly['loc'] = true;
      const location = new src_app_core_models_location__WEBPACK_IMPORTED_MODULE_3__.Locations(this.externalRegForm.get('selectedLocation').value, this.externalRegForm.get('selectedLocationName').value, this.externalRegForm.get('selectedArea').value);
      this.saveSelectedLocation.push(location);
      saveLocId = this.externalRegForm.get('selectedLocation').value;
      saveAreaId = this.externalRegForm.get('selectedArea').value;
    }
    const currentDate = new Date();
    const categoryIdVeh = this.enableCategorySelection ? this.externalRegForm.get('selectedVehicleCategory').value : this.externalRegForm.get('vdetails').value.categoryId;
    if (this.externalRegForm.get('nonEditable')) {
      const selectedVehicleCategoryText = this.externalRegForm.get('vehicleCategories').value.find(category => category.categoryId == categoryIdVeh).descriptionEn;
      const vehCateg = this.enableCategorySelection ? selectedVehicleCategoryText : this.externalRegForm.get('vcategory').value;
      this.feesDetails.push({
        vinNo: this.externalRegForm.get('vdetails').value.vinNo,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.Inspection,
        serviceId: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__.InspectionServiceTypes.ExternalInspection,
        vehicleCategoryId: categoryIdVeh,
        isStaffRate: this.externalRegForm.get('isStaffRate').value ? true : false
      });
      this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_34__.map)(data => data.items)).subscribe(items => {
        for (let fee of items) {
          if (fee.serviceTypeId == 1) {
            this.externalRegForm.get("fees").setValue(fee.feesAmount);
            this.feesArray.push(fee.feesAmount);
            this.externalRegForm.get("feesDiscount").setValue(fee.feesDiscount);
          }
        }
        this.feesDetails = [];
        const cost = this.externalRegForm.get('fees').value || 0;
        this.externalRegForm.get("amount").setValue(cost);
        const totalAmount = this.externalRegForm.get("totalCost").value + cost;
        this.amountTh = this.thousandSeparator.addThousandSeparator(totalAmount.toString());
        this.externalRegForm.get("totalCost").setValue(totalAmount);
        const area = this.externalRegForm.get('selectedArea').value ? this.externalRegForm.get('selectedArea').value : saveAreaId;
        const loc = this.externalRegForm.get('selectedLocation').value ? this.externalRegForm.get('selectedLocation').value : saveLocId;
        const addVehicle = new src_app_core_models_add_vehicle_details__WEBPACK_IMPORTED_MODULE_1__.AddVehicleDetails(this.externalRegForm.get('vdetails').value, this.externalRegForm.get('phone').value, area, loc, vehCateg, cost);
        if (this.isWeightZero) {
          addVehicle.vdetails.weight = this.externalRegForm.get('inputWeight').value;
        }
        this.vehicles.push(addVehicle);
        this.resetInfo();
      });
      this.externalRegForm.get('showScreen').setValue(false);
    }
  }
  addVehicleDB() {
    var _this = this;
    return (0,_Users_os_Desktop_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.externalRegForm.get('nonEditable')) {
        _this.inserted = true;
        _this.externalRegForm.get('showScreen').setValue(false);
        const currentDate = new Date();
        let counter = 0;
        const mainServiceRequest = {
          stationId: _this.stationId,
          serviceType: 1,
          serviceID: 5,
          contactType: _this.savePid,
          contactPersonName: '',
          contactPersonEmail: _this.externalRegForm.get('email').value,
          contactPersonPhone: _this.externalRegForm.get('phone').value.toString(),
          status: 1,
          registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.BackOffice,
          boothId: 1,
          posId: 1,
          remarks: '',
          requestRefId: _this.requestId,
          createdBy: _this.userId,
          vinNo: _this.vinNo,
          plateType: _this.vehicles[0].vdetails.plateType,
          plateNo: parseInt(_this.vehicles[0].vdetails.plateNo)
        };
        _this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_5__.ServiceRequest(mainServiceRequest);
        // Insert the service request for main vehicle
        const mainServiceRequestObservable = (0,rxjs__WEBPACK_IMPORTED_MODULE_35__.of)(_this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_36__.switchMap)(mainRequest => {
          // Insert the service request for main vehicle
          if (counter == 0) {
            return _this.vehicleService.insertServiceRequest(mainRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_34__.map)(data => {
              _this.requestId = data.items;
              // upload attachments
              const fileInfoArray = _this.fileService.getFileData();
              for (const fileInfo of fileInfoArray) {
                if (fileInfo) {
                  const formData = new FormData();
                  formData.append('requestId', _this.requestId.toString());
                  formData.append('sectionId', '');
                  formData.append('defectId', '');
                  formData.append('serviceTypeId', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.Inspection.toString());
                  formData.append('serviceId', src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__.InspectionServiceTypes.ExternalInspection.toString());
                  formData.append('mimeType', fileInfo.mimeType);
                  formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.SupportDocuments.toString());
                  formData.append('createdBy', _this.userId.toString());
                  formData.append('fileData', fileInfo.fileData, fileInfo.filename);
                  _this.globalServ.uploadAttachement(formData).subscribe(response => {}, error => {});
                }
              }
              return _this.requestId; // Pass requestId to the next observable
            }));
          } else return (0,rxjs__WEBPACK_IMPORTED_MODULE_35__.of)(null);
        }), (0,rxjs__WEBPACK_IMPORTED_MODULE_37__.publishReplay)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_38__.refCount)());
        const observables = _this.vehicles.map(eq => {
          return mainServiceRequestObservable.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_36__.switchMap)(requestId => {
            counter++;
            let requestIdVehicles = 0;
            if (requestId != null) {
              const externalRegServiceRequestData = {
                stationId: _this.stationId,
                serviceType: 1,
                serviceID: 5,
                contactType: _this.savePid,
                contactPersonName: '',
                contactPersonEmail: _this.externalRegForm.get('email').value,
                contactPersonPhone: _this.externalRegForm.get('phone').value.toString(),
                status: 1,
                registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.BackOffice,
                boothId: 1,
                posId: 1,
                remarks: '',
                requestRefId: _this.requestId,
                createdBy: _this.userId,
                vinNo: eq.vdetails.vinNo,
                plateType: eq.vdetails.plateType,
                plateNo: parseInt(eq.vdetails.plateNo)
              };
              _this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_5__.ServiceRequest(externalRegServiceRequestData);
            }
            // Insert the service request for each vehicle
            const insertServiceRequestObservable = _this.vehicleService.insertServiceRequest(_this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_34__.map)(data => data.items));
            return insertServiceRequestObservable.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_39__.concatMap)(items => {
              requestIdVehicles = items;
              const vehicleDetails = {
                requestId: requestIdVehicles,
                plateNo: parseInt(eq.vdetails.plateNo),
                plateType: eq.vdetails.plateType,
                vinNo: eq.vdetails.vinNo,
                colorId: eq.vdetails.colorId,
                subColorId: eq.vdetails.subColorId,
                categoryId: eq.vdetails.categoryId,
                vehicleModelId: eq.vdetails.vehicleModelId,
                manufacturerId: eq.vdetails.manufacturerId,
                manufacturerYear: eq.vdetails.manufacturerYear,
                moiRegistrationDate: eq.vdetails.moiRegistrationDate,
                cylinders: eq.vdetails.cylinders,
                weight: eq.vdetails.weight,
                payloadWeight: eq.vdetails.payloadWeight,
                shapeCode: eq.vdetails.shapeCode,
                descriptionEn: '',
                descriptionAr: '',
                noOfSeat: eq.vdetails.noOfSeat,
                licenseExpiryDate: eq.vdetails.licenseExpiryDate,
                ownerType: _this.savePid,
                contactPersonPid: _this.contactPid,
                contactPersonEmail: _this.contactEmail,
                contactPersonPhone: _this.contactPhone.toString(),
                ownerId: '0',
                ownerPid: eq.vdetails.ownerPID,
                ownerPidType: _this.savePid,
                ownerName: eq.vdetails.ownerName,
                departmentId: 0,
                createdBy: _this.userId
              };
              _this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_4__.RegisterVehicle(vehicleDetails);
              const registerVehicleObservable = _this.vehicleService.registerVehicle(_this.registerVehicle);
              const externalEquipmentDetails = {
                requestId: requestIdVehicles,
                plateNo: parseInt(eq.vdetails.plateNo),
                plateType: eq.vdetails.plateType,
                vinNo: eq.vdetails.vinNo,
                categoryId: eq.vdetails.categoryId,
                areaId: parseInt(eq.area),
                locationId: parseInt(eq.location),
                amount: eq.cost,
                contactPersonName: 'name',
                contactPersonEmail: _this.contactEmail,
                contactPersonPhone: eq.phone.toString(),
                remarks: '',
                contactPID: _this.contactPid,
                createdBy: _this.userId
              };
              _this.extEquipment = new src_app_core_models_insert_vehicle_equipment__WEBPACK_IMPORTED_MODULE_2__.InsertExternalEquipment(externalEquipmentDetails);
              _this.equipments.push(_this.extEquipment);
              // Combine both observables for the current vehicle
              return registerVehicleObservable;
            }));
          }));
        });
        //observables.unshift(mainServiceRequestObservable);
        // Use forkJoin to execute all observables in parallel
        (0,rxjs__WEBPACK_IMPORTED_MODULE_40__.forkJoin)(observables).subscribe(responses => {
          _this.vehicleService.insertExternalEquipment(_this.equipments).subscribe(data => {
            _this.vehicleService.getExternalEquipmentVehiclesDetails(_this.requestId).subscribe(response => {
              _this.externalRegForm.get('totalCost').setValue(response.items.totalAmount);
              _this.listVehicle.push(...response.items.externalEquipmentVehicles);
              _this.isTotalZero = _this.externalRegForm.get('totalCost').value == 0 ? true : false;
              _this.dbInserted = true;
            }, error => {
              _this.isTotalZero = true;
            });
          });
        }, error => {
          // Handle errors
        });
      } else {
        const currentDate = new Date();
        // for manual entry to be updated or removed
        const vehicleDetailsModel = new src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_6__.VehicleDetails(_this.externalRegForm.get('inputPlateNo').value, _this.externalRegForm.get('inputPlateType').value, _this.externalRegForm.get('inputVinNo').value, _this.externalRegForm.get('selectedColor').value, _this.externalRegForm.get('selectedSubColor').value, _this.externalRegForm.get('selectedVehicleCategory').value, _this.externalRegForm.get('selectedModel').value, _this.externalRegForm.get('selectedManufacturer').value, _this.externalRegForm.get('inputManfYear').value, currentDate, _this.externalRegForm.get('inputCylinders').value, _this.externalRegForm.get('inputWeight').value, _this.externalRegForm.get('inputPayloadWeight').value, '', _this.externalRegForm.get('inputNbSeats').value, _this.externalRegForm.get('inputPid').value, _this.externalRegForm.get('inputOwnerName').value, _this.externalRegForm.get('expDate').value, 0, currentDate, 0, currentDate, '', '', null, null, null, null);
        const addVehicle = new src_app_core_models_add_vehicle_details__WEBPACK_IMPORTED_MODULE_1__.AddVehicleDetails(vehicleDetailsModel, _this.externalRegForm.get('phone').value, _this.externalRegForm.get('selectedArea').value, _this.externalRegForm.get('selectedLocation').value, _this.externalRegForm.get('vcategory').value, 0);
        _this.vehicles.push(addVehicle);
      }
      _this.externalRegForm.get('nonEditable').setValue(false);
      //reset input values
      //this.resetInfo();
      _this.globalServ.getStationPaymentMethods(1).subscribe(response => {
        _this.externalRegForm.get('paymentTypes').setValue(response.items);
      });
    })();
  }
  deleteVehicle(index) {
    this.vehicles.splice(index, 1);
    this.equipments.splice(index, 1);
    this.feesArray.splice(index, 1);
    this.feesDetails.splice(index, 1);
    this.externalRegForm.get('totalCost').setValue(0);
    for (let v of this.vehicles) {
      this.feesDetails.push({
        vinNo: v.vdetails.vinNo,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.Inspection,
        serviceId: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__.InspectionServiceTypes.ExternalInspection,
        vehicleCategoryId: v.vdetails.categoryId,
        isStaffRate: this.externalRegForm.get('isStaffRate').value ? true : false
      });
      this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_34__.map)(data => data.items)).subscribe(items => {
        for (let fee of items) {
          if (fee.serviceTypeId == 1) {
            this.externalRegForm.get("fees").setValue(fee.feesAmount);
            this.feesArray.push(fee.feesAmount);
            this.externalRegForm.get("feesDiscount").setValue(fee.feesDiscount);
          }
        }
        const cost = this.externalRegForm.get('fees').value || 0;
        this.externalRegForm.get("amount").setValue(cost);
        const totalAmount = this.externalRegForm.get("totalCost").value + cost;
        this.amountTh = this.thousandSeparator.addThousandSeparator(totalAmount.toString());
        this.externalRegForm.get("totalCost").setValue(totalAmount);
      });
    }
    if (this.inserted) {
      this.vehicleService.deleteExternalEquipmentVehicle(this.listVehicle[index].requestId, this.listVehicle[index].vinNo).subscribe(response => {
        this.vehicleService.getExternalEquipmentVehiclesDetails(this.requestId).subscribe(response => {
          this.externalRegForm.get('totalCost').setValue(response.items.totalAmount);
        });
      }, error => {
        this.isTotalZero = true;
      });
      this.listVehicle.splice(index, 1);
    }
    if (this.vehicles.length == 0) {
      this.externalRegForm.get('canPay').setValue(false);
      this.inserted = false;
      this.isTotalZero = true;
      this.viewBtn = false;
      this.externalRegForm.get('showScreen').setValue(true);
      this.focusScanner();
    }
  }
  continueInsertPay() {
    this.addVehicleDB().then(() => {
      setTimeout(() => {
        this.submitPayment();
      }, 5000);
    });
  }
  viewAddedVehicles() {
    this.externalRegForm.get('showScreen').setValue(false);
    this.viewBtn = false;
  }
  focusScanner() {
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#bcode');
      if (myInput) {
        myInput.focus();
      }
    }, 100);
  }
  backToScreen() {
    this.externalRegForm.get('showScreen').setValue(true);
    if (this.vehicles.length > 0) {
      this.viewBtn = true;
    }
    this.focusScanner();
    this.vehicleCategError = false;
    this.resetInfo();
  }
  cancelExt() {
    window.location.reload();
    this.displayPaymentDetails = 'none';
    this.isPaymentStarted = true;
    this.isPaymentStarted = false;
  }
  cancelExtFaild() {
    this.isPaymentStarted = false;
  }
  closePayPop() {
    this.externalRegForm.get('selectedCust').setValue('');
  }
  resetInfo() {
    this.externalRegForm.get('inputPlateNo').setValue(' ');
    this.externalRegForm.get('inputPlateType').setValue(' ');
    this.externalRegForm.get('vdetails').setValue({});
    this.externalRegForm.get('inputVinNo').setValue('');
    this.externalRegForm.get('selectedColor').setValue('');
    this.externalRegForm.get('selectedSubColor').setValue('');
    this.externalRegForm.get('selectedVehicleCategory').setValue('');
    this.externalRegForm.get('selectedModel').setValue('');
    this.externalRegForm.get('selectedManufacturer').setValue('');
    this.externalRegForm.get('inputManfYear').setValue(null);
    this.externalRegForm.get('inputCylinders').setValue(null);
    this.externalRegForm.get('inputWeight').setValue(null);
    //this.externalRegForm.get('inputPayloadWeight').setValue(null);
    this.externalRegForm.get('inputNbSeats').setValue(null);
    this.externalRegForm.get('inputPid').setValue(null);
    this.isValidInput = false;
    this.displayPaymentDetails = 'none';
    this.isReinspectionExt = false;
    this.externalRegForm.get('noOfReinspections').setValue('');
    if (!this.externalRegForm.get('checkAllContact').value) {
      this.externalRegForm.get('phone').setValue('');
      this.externalRegForm.get('email').setValue('');
      this.externalRegForm.get('pid').setValue('');
    }
    if (!this.externalRegForm.get('checkAllLocation').value) {
      this.externalRegForm.get('selectedArea').setValue('');
      this.externalRegForm.get('selectedLocation').setValue(' ');
    }
  }
  static #_ = this.ɵfac = function ExternalRegistrationComponent_Factory(t) {
    return new (t || ExternalRegistrationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_29__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_28__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_14__.FileService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_15__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_16__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_17__.PurchaseService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_41__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_18__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_19__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_20__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_21__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_22__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_23__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_28__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_24__.ThousandSeparatorService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_25__.SystemAdminService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdefineComponent"]({
    type: ExternalRegistrationComponent,
    selectors: [["app-external-registration"]],
    viewQuery: function ExternalRegistrationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵloadQuery"]()) && (ctx.fileInput = _t.first);
      }
    },
    hostBindings: function ExternalRegistrationComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("keydown", function ExternalRegistrationComponent_keydown_HostBindingHandler($event) {
          return ctx.onKeydown($event);
        });
      }
    },
    decls: 64,
    vars: 24,
    consts: [[3, "formGroup"], [1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["class", "accordion-header", "id", "headingOne", 4, "ngIf"], ["class", "accordion-header", "id", "headingTwo", 4, "ngIf"], ["class", "accordion-collapse collapse show", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample0", 4, "ngIf"], ["id", "act-search2", "class", "accordion-collapse collapse show", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 4, "ngIf"], ["class", "row", 4, "ngIf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "class", "btn btn-dark-gray", 3, "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", 3, "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 3, "disabled", 4, "ngIf"], ["data-bs-backdrop", "static", "id", "confirmationModal", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered", "modal-sm"], [1, "modal-content"], [1, "modal-header", "ps-info"], ["id", "exampleModalLabel", 1, "modal-title"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "modal-body", "text-center"], [1, "modal-footer", "justify-content-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "click"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 3, "click", 4, "ngIf"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["class", "modal-dialog modal-dialog-centered", 4, "ngIf"], [3, "isPaymentStarted", "email", "isSuccess", "isPayCanceled", "isNotReachable", "requestRefId", "currentDateFormat", "currentTimeFormat", "totalAmountTh", "paymentName", "onCancelEvent", "onCancelFailedEvent", "onDownloadPaymentEvent"], ["data-bs-backdrop", "static", "id", "PrintReceipt", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content", "modal-content-rec"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "pt-lab"], ["data-bs-backdrop", "static", "id", "fileUploadModal", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [3, "fileUploaded"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "headingTwo", 1, "accordion-header"], ["id", "vehicleSummary"], ["aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample0", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col"], ["scopr", "col"], [4, "ngFor", "ngForOf"], ["colspan", "7"], ["colspan", "2"], [4, "ngIf"], ["id", "btndel", 1, "btn", "btn-link", 3, "click"], [1, "bi", "bi-trash3-fill"], ["id", "act-search2", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["src", "./assets/img/scan.svg", "width", "30px", "height", "30px"], [1, "col-md-6", "col-md-4"], ["type", "text", "formControlName", "barCode", "id", "bcode", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["class", "col-md-6 col-md-4", "class", "error-message", 4, "ngIf"], ["class", "col-md-6 col-md-4", "class", "info-msg", 4, "ngIf"], ["for", "myInput"], ["type", "number", "id", "myInput", "name", "plateNo", "formControlName", "inputPlateNo", "oninput", "(event.key === 'ArrowUp' || event.key === 'ArrowDown')? event.target.defaultValue : event.target.value;", 1, "form-control", 3, "ngModel", "ngModelChange"], ["class", "error-message", 4, "ngIf"], ["formControlName", "inputPlateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "form-control", "formControlName", "selectedVehicleCategory", 3, "ngModelChange", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "vcategory", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedOwnerType", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "pidValue", 3, "readonly", 4, "ngIf"], ["type", "text", "class", "form-control", "readonly", "", 3, "value", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPid", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputOwnerName", 4, "ngIf"], ["type", "date", "class", "form-control", "formControlName", "expDate", 4, "ngIf"], ["type", "text", "class", "form-control", 3, "value", "readonly", 4, "ngIf"], [1, "accordion-body", "border-top"], ["type", "text", "class", "form-control", "formControlName", "inputVinNo", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedManufacturer", 3, "change", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedModel", 4, "ngIf"], ["class", "form-control", "formControlName", "inputManfYear", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputCylinders", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputWeight", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPayloadweight", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedColor", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "colorValue", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedSubColor", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputNbSeats", 4, "ngIf"], [1, "col-lg-6", "sr-vc"], ["class", "reinspection", 4, "ngIf"], ["class", "woqod", 4, "ngIf"], ["class", "staff-rate", 3, "pointer-events", 4, "ngIf"], ["type", "file", 2, "display", "none", 3, "change"], ["fileInput", ""], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal", 1, "btn", "btn-vci"], [1, "bi", "bi-paperclip"], ["id", "fn", 4, "ngIf"], [1, "error-message"], [1, "info-msg"], [3, "value"], ["formControlName", "selectedVehicleCategory", 1, "form-control", 3, "ngModelChange"], ["type", "text", "formControlName", "vcategory", 1, "form-control", 3, "readonly"], ["formControlName", "selectedOwnerType", 1, "form-control"], ["type", "text", "formControlName", "pidValue", 1, "form-control", 3, "readonly"], ["type", "text", "readonly", "", 1, "form-control", 3, "value"], ["type", "number", "formControlName", "inputPid", 1, "form-control"], ["type", "text", "formControlName", "inputOwnerName", 1, "form-control"], ["type", "date", "formControlName", "expDate", 1, "form-control"], ["type", "text", 1, "form-control", 3, "value", "readonly"], ["type", "text", "formControlName", "inputVinNo", 1, "form-control"], ["formControlName", "selectedManufacturer", 1, "form-control", 3, "change"], ["formControlName", "selectedModel", 1, "form-control"], ["formControlName", "inputManfYear", 1, "form-control"], ["type", "text", "formControlName", "inputCylinders", 1, "form-control"], ["type", "number", "formControlName", "inputWeight", 1, "form-control"], ["type", "number", "formControlName", "inputPayloadweight", 1, "form-control", 3, "readonly"], ["formControlName", "selectedColor", 1, "form-control"], ["type", "text", "formControlName", "colorValue", 1, "form-control", 3, "readonly"], ["formControlName", "selectedSubColor", 1, "form-control"], ["type", "number", "formControlName", "inputNbSeats", 1, "form-control"], [1, "reinspection"], [1, "warn", "warning"], [1, "woqod"], [1, "warn", "warning-green"], [1, "staff-rate"], [1, "switch"], ["type", "checkbox", "formControlName", "isStaffRate", 3, "checked"], [1, "slider", "round"], ["id", "fn"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", "formControlName", "phone", 1, "form-control", 3, "readonly"], ["type", "text", "formControlName", "pid", 1, "form-control", 3, "readonly"], ["type", "text", "formControlName", "email", 1, "form-control", 3, "readonly"], ["id", "accordion3", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["aria-colspan", "accordion-collapse collapse show", "aria-label", "headingThree", "data-bs-parent", "#accordion3", 1, "act-search4"], ["class", "form-control", "formControlName", "selectedArea", 3, "change", 4, "ngIf"], ["class", "form-control", "readonly", "", 3, "value", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedLocation", 3, "readonly", "change", 4, "ngIf"], [1, "form-check"], ["type", "checkbox", "id", "checkVehicles1", "formControlName", "checkAllContact", 1, "form-check-input"], ["for", "checkVehicles1", 1, "form-check-label"], ["type", "checkbox", "id", "checkVehicles2", "formControlName", "checkAllLocation", 1, "form-check-input"], ["for", "checkVehicles2", 1, "form-check-label"], ["formControlName", "selectedArea", 1, "form-control", 3, "change"], ["readonly", "", 1, "form-control", 3, "value"], ["formControlName", "selectedLocation", 1, "form-control", 3, "change"], ["type", "button", 1, "btn", "btn-dark-gray", 3, "click"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-orange", 3, "disabled"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 1, "btn", "btn-orange", 3, "click"], [1, "modal-title"], [1, "payment-info"], [1, "payment-type"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop2", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "btn-radio"], ["type", "radio", "formControlName", "selectedPayment", 3, "id", "value", "ngModelChange"], [3, "for"], [1, "col-md-6", "col-lg-6"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "formControlName", "selectedCust", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "clearSearchOnAdd", "minTermLength", "change"], [1, "dropdown-container"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"]],
    template: function ExternalRegistrationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](0, "body")(1, "form", 0)(2, "section", 1)(3, "div", 2)(4, "div", 3)(5, "div", 2)(6, "div", 3)(7, "div", 2)(8, "div", 4)(9, "div", 5)(10, "div", 6)(11, "div", 7)(12, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](13, ExternalRegistrationComponent_h2_13_Template, 3, 0, "h2", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](14, ExternalRegistrationComponent_div_14_Template, 3, 0, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](15, ExternalRegistrationComponent_div_15_Template, 31, 2, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_16_Template, 123, 53, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](17, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](18, ExternalRegistrationComponent_div_18_Template, 28, 7, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](19, ExternalRegistrationComponent_div_19_Template, 31, 4, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](20, "div", 2)(21, "div", 14)(22, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_Template_button_click_22_listener() {
          return ctx.cancelExt();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](23, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](24, ExternalRegistrationComponent_button_24_Template, 2, 0, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](25, ExternalRegistrationComponent_button_25_Template, 2, 1, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](26, ExternalRegistrationComponent_button_26_Template, 2, 0, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](27, ExternalRegistrationComponent_button_27_Template, 2, 1, "button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](28, "div", 20)(29, "div", 21)(30, "div", 22)(31, "div", 23)(32, "h5", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](33, "Save Vehicle(s)");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](34, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](35, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](36, " Are you sure no more vehicles to be added ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](37, "br")(38, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](39, "div", 27)(40, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](41, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](42, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_Template_button_click_42_listener() {
          return ctx.addVehicleDB();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](43, " Yes, Proceed ");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](44, ExternalRegistrationComponent_button_44_Template, 2, 0, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](45, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](46, ExternalRegistrationComponent_div_46_Template, 8, 0, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtemplate"](47, ExternalRegistrationComponent_div_47_Template, 37, 5, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](48, "payment-transaction-status-modal", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("onCancelEvent", function ExternalRegistrationComponent_Template_payment_transaction_status_modal_onCancelEvent_48_listener() {
          return ctx.cancelExt();
        })("onCancelFailedEvent", function ExternalRegistrationComponent_Template_payment_transaction_status_modal_onCancelFailedEvent_48_listener() {
          return ctx.cancelExtFaild();
        })("onDownloadPaymentEvent", function ExternalRegistrationComponent_Template_payment_transaction_status_modal_onDownloadPaymentEvent_48_listener() {
          return ctx.downloadPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](49, "div", 34)(50, "div", 35)(51, "div", 36)(52, "div", 37)(53, "h1", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelement"](54, "img", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](55, " Receipt ");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](56, "button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("click", function ExternalRegistrationComponent_Template_button_click_56_listener() {
          return ctx.cancelExt();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](57, "div", 41)(58, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵtext"](59, " Printing Receipt... ");
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementStart"](60, "div", 43)(61, "div", 35)(62, "div", 22)(63, "app-file-uploads", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵlistener"]("fileUploaded", function ExternalRegistrationComponent_Template_app_file_uploads_fileUploaded_63_listener($event) {
          return ctx.onFileUploaded($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("formGroup", ctx.externalRegForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value && !ctx.inserted);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.viewBtn && ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value && !ctx.isWoqodAdded && ctx.externalRegForm.get("totalCost").value != 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value && (ctx.isWoqodAdded || ctx.externalRegForm.get("totalCost").value == 0));
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", ctx.printReceiptDirectly);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("ngIf", !ctx.printReceiptDirectly);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵproperty"]("isPaymentStarted", ctx.isPaymentStarted)("email", ctx.externalRegForm.get("email").value)("isSuccess", ctx.isSuccess)("isPayCanceled", ctx.isPayCanceled)("isNotReachable", ctx.isNotReachable)("requestRefId", ctx.requestId)("currentDateFormat", ctx.currentDateFormat)("currentTimeFormat", ctx.currentTimeFormat)("totalAmountTh", ctx.amountTh)("paymentName", ctx.paymentName);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_30__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_29__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_29__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_29__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_29__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_29__.FormControlName, _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_26__.FileUploadsComponent, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_27__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_42__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_42__.NgOptionComponent],
    styles: [".container[_ngcontent-%COMP%] {\n    text-align: center;\n}\n\nth[_ngcontent-%COMP%] {\n    color: white;\n    background-color: #F89828;\n}\n\n\n.custom-table[_ngcontent-%COMP%] {\n    text-align: center;\n    color: black;\n    background-color: #ffdcb3;\n    border: 1px solid white;\n    border-collapse: collapse;\n    margin: 20px 0;\n}\n\n.error-message[_ngcontent-%COMP%] {\n    color: red;\n    font-style: italic;\n}\n\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\n    appearance: none;\n    margin: 0;\n}\n\n#btndel[_ngcontent-%COMP%] {\n    padding: 5px;\n    border-radius: 40%;\n    border: none;\n    width: 30px;\n    height: 31px;\n    color: orange;\n    float: left;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    margin: 1px;\n    font-weight: 500;\n    font-size: 25px;\n}\n\n#btndel.hover[_ngcontent-%COMP%] {\n    color: #fff;\n    background-color: orange;\n}\n\n.btn-orange[_ngcontent-%COMP%]:disabled {\n    background-color: #ef9c3d;\n    color: #ffff;\n}\n\n#confirmationModal[_ngcontent-%COMP%] {\n    text-align: center;\n    margin: auto;\n}\n\n.modal-footer[_ngcontent-%COMP%] {\n    text-align: center;\n}\n\n#vehicleSummary[_ngcontent-%COMP%] {\n    font-weight: bold;\n    margin-left: 20px;\n    margin-top: 5px;\n}\n\n.warn[_ngcontent-%COMP%], .warn[_ngcontent-%COMP%]::before, .warn[_ngcontent-%COMP%]::after {\n    position: relative;\n    padding: 0;\n    margin: 0;\n}\n\n.warn[_ngcontent-%COMP%] {\n    font-size: 20px;\n    color: transparent;\n}\n\n.warn.warning-green[_ngcontent-%COMP%] {\n    display: inline-block;\n\n    top: 0.225em;\n\n    width: 1.15em;\n    height: 1.15em;\n\n    overflow: hidden;\n    border: none;\n    background-color: transparent;\n    border-radius: 0.625em;\n}\n\n.warn.warning-green[_ngcontent-%COMP%]::before {\n    content: \"\";\n    display: block;\n    top: -0.08em;\n    left: 0.0em;\n    position: absolute;\n    border: transparent 0.6em solid;\n    border-bottom-color: #448b23;\n    border-bottom-width: 1em;\n    border-top-width: 0;\n    box-shadow: #448b23 0 1px 1px;\n}\n\n.warn.warning-green[_ngcontent-%COMP%]::after {\n    display: block;\n    position: absolute;\n    top: 0.3em;\n    left: 0;\n    width: 100%;\n    padding: 0 1px;\n    text-align: center;\n    font-family: \"Garamond\";\n    content: \"!\";\n    font-size: 0.65em;\n    font-weight: bold;\n    color: white;\n}\n\n.woqod[_ngcontent-%COMP%] {\n    background-color: white;\n    box-shadow: #448b23 0 0.5px 0.5px;\n}\n\n#fn[_ngcontent-%COMP%] {\n    font-size: 13px;\n    font-style: italic;\n}\n\n.warn.warning[_ngcontent-%COMP%] {\n    display: inline-block;\n\n    top: 0.225em;\n\n    width: 1.15em;\n    height: 1.15em;\n\n    overflow: hidden;\n    border: none;\n    background-color: transparent;\n    border-radius: 0.625em;\n}\n\n.warn.warning[_ngcontent-%COMP%]::before {\n    content: \"\";\n    display: block;\n    top: -0.08em;\n    left: 0.0em;\n    position: absolute;\n    border: transparent 0.6em solid;\n    border-bottom-color: rgb(249, 41, 41);\n    border-bottom-width: 1em;\n    border-top-width: 0;\n    box-shadow: #943131 0 1px 1px;\n}\n\n.warn.warning[_ngcontent-%COMP%]::after {\n    display: block;\n    position: absolute;\n    top: 0.3em;\n    left: 0;\n    width: 100%;\n    padding: 0 1px;\n    text-align: center;\n    font-family: \"Garamond\";\n    content: \"!\";\n    font-size: 0.65em;\n    font-weight: bold;\n    color: white;\n}\n\n.reinspection[_ngcontent-%COMP%] {\n    background-color: white;\n    box-shadow: #943131 0 0.5px 0.5px;\n}\n\n.modal[_ngcontent-%COMP%]   .modal-content-rec[_ngcontent-%COMP%] {\n    width: 300px;\n    margin-left: 200px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvZXh0ZXJuYWwtcmVnaXN0cmF0aW9uL2V4dGVybmFsLXJlZ2lzdHJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksWUFBWTtJQUNaLHlCQUF5QjtBQUM3Qjs7O0FBR0E7SUFDSSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxVQUFVO0lBQ1Ysa0JBQWtCO0FBQ3RCOztBQUVBOztJQUdJLGdCQUFnQjtJQUNoQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixXQUFXO0lBQ1gsWUFBWTtJQUNaLGFBQWE7SUFDYixXQUFXO0lBQ1gsYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksV0FBVztJQUNYLHdCQUF3QjtBQUM1Qjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGVBQWU7QUFDbkI7O0FBRUE7OztJQUdJLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsU0FBUztBQUNiOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHFCQUFxQjs7SUFFckIsWUFBWTs7SUFFWixhQUFhO0lBQ2IsY0FBYzs7SUFFZCxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsY0FBYztJQUNkLFlBQVk7SUFDWixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLCtCQUErQjtJQUMvQiw0QkFBNEI7SUFDNUIsd0JBQXdCO0lBQ3hCLG1CQUFtQjtJQUNuQiw2QkFBNkI7QUFDakM7O0FBRUE7SUFDSSxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixPQUFPO0lBQ1AsV0FBVztJQUNYLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsaUNBQWlDO0FBQ3JDOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHFCQUFxQjs7SUFFckIsWUFBWTs7SUFFWixhQUFhO0lBQ2IsY0FBYzs7SUFFZCxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsY0FBYztJQUNkLFlBQVk7SUFDWixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLCtCQUErQjtJQUMvQixxQ0FBcUM7SUFDckMsd0JBQXdCO0lBQ3hCLG1CQUFtQjtJQUNuQiw2QkFBNkI7QUFDakM7O0FBRUE7SUFDSSxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixPQUFPO0lBQ1AsV0FBVztJQUNYLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsaUNBQWlDO0FBQ3JDOztBQUVBO0lBQ0ksWUFBWTtJQUNaLGtCQUFrQjtBQUN0QiIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxudGgge1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xufVxuXG5cbi5jdXN0b20tdGFibGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZGNiMztcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIG1hcmdpbjogMjBweCAwO1xufVxuXG4uZXJyb3ItbWVzc2FnZSB7XG4gICAgY29sb3I6IHJlZDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG59XG5cbmlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b24sXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uIHtcbiAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XG4gICAgYXBwZWFyYW5jZTogbm9uZTtcbiAgICBtYXJnaW46IDA7XG59XG5cbiNidG5kZWwge1xuICAgIHBhZGRpbmc6IDVweDtcbiAgICBib3JkZXItcmFkaXVzOiA0MCU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIHdpZHRoOiAzMHB4O1xuICAgIGhlaWdodDogMzFweDtcbiAgICBjb2xvcjogb3JhbmdlO1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBtYXJnaW46IDFweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc2l6ZTogMjVweDtcbn1cblxuI2J0bmRlbC5ob3ZlciB7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogb3JhbmdlO1xufVxuXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcbiAgICBjb2xvcjogI2ZmZmY7XG59XG5cbiNjb25maXJtYXRpb25Nb2RhbCB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbjogYXV0bztcbn1cblxuLm1vZGFsLWZvb3RlciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4jdmVoaWNsZVN1bW1hcnkge1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgIG1hcmdpbi10b3A6IDVweDtcbn1cblxuLndhcm4sXG4ud2Fybjo6YmVmb3JlLFxuLndhcm46OmFmdGVyIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW46IDA7XG59XG5cbi53YXJuIHtcbiAgICBmb250LXNpemU6IDIwcHg7XG4gICAgY29sb3I6IHRyYW5zcGFyZW50O1xufVxuXG4ud2Fybi53YXJuaW5nLWdyZWVuIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cbiAgICB0b3A6IDAuMjI1ZW07XG5cbiAgICB3aWR0aDogMS4xNWVtO1xuICAgIGhlaWdodDogMS4xNWVtO1xuXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgYm9yZGVyLXJhZGl1czogMC42MjVlbTtcbn1cblxuLndhcm4ud2FybmluZy1ncmVlbjo6YmVmb3JlIHtcbiAgICBjb250ZW50OiBcIlwiO1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHRvcDogLTAuMDhlbTtcbiAgICBsZWZ0OiAwLjBlbTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm9yZGVyOiB0cmFuc3BhcmVudCAwLjZlbSBzb2xpZDtcbiAgICBib3JkZXItYm90dG9tLWNvbG9yOiAjNDQ4YjIzO1xuICAgIGJvcmRlci1ib3R0b20td2lkdGg6IDFlbTtcbiAgICBib3JkZXItdG9wLXdpZHRoOiAwO1xuICAgIGJveC1zaGFkb3c6ICM0NDhiMjMgMCAxcHggMXB4O1xufVxuXG4ud2Fybi53YXJuaW5nLWdyZWVuOjphZnRlciB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMC4zZW07XG4gICAgbGVmdDogMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBwYWRkaW5nOiAwIDFweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1mYW1pbHk6IFwiR2FyYW1vbmRcIjtcbiAgICBjb250ZW50OiBcIiFcIjtcbiAgICBmb250LXNpemU6IDAuNjVlbTtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBjb2xvcjogd2hpdGU7XG59XG5cbi53b3FvZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgYm94LXNoYWRvdzogIzQ0OGIyMyAwIDAuNXB4IDAuNXB4O1xufVxuXG4jZm4ge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG59XG5cbi53YXJuLndhcm5pbmcge1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcblxuICAgIHRvcDogMC4yMjVlbTtcblxuICAgIHdpZHRoOiAxLjE1ZW07XG4gICAgaGVpZ2h0OiAxLjE1ZW07XG5cbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgICBib3JkZXItcmFkaXVzOiAwLjYyNWVtO1xufVxuXG4ud2Fybi53YXJuaW5nOjpiZWZvcmUge1xuICAgIGNvbnRlbnQ6IFwiXCI7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgdG9wOiAtMC4wOGVtO1xuICAgIGxlZnQ6IDAuMGVtO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3JkZXI6IHRyYW5zcGFyZW50IDAuNmVtIHNvbGlkO1xuICAgIGJvcmRlci1ib3R0b20tY29sb3I6IHJnYigyNDksIDQxLCA0MSk7XG4gICAgYm9yZGVyLWJvdHRvbS13aWR0aDogMWVtO1xuICAgIGJvcmRlci10b3Atd2lkdGg6IDA7XG4gICAgYm94LXNoYWRvdzogIzk0MzEzMSAwIDFweCAxcHg7XG59XG5cbi53YXJuLndhcm5pbmc6OmFmdGVyIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwLjNlbTtcbiAgICBsZWZ0OiAwO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmc6IDAgMXB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LWZhbWlseTogXCJHYXJhbW9uZFwiO1xuICAgIGNvbnRlbnQ6IFwiIVwiO1xuICAgIGZvbnQtc2l6ZTogMC42NWVtO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnJlaW5zcGVjdGlvbiB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgYm94LXNoYWRvdzogIzk0MzEzMSAwIDAuNXB4IDAuNXB4O1xufVxuXG4ubW9kYWwgLm1vZGFsLWNvbnRlbnQtcmVjIHtcbiAgICB3aWR0aDogMzAwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDIwMHB4O1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 4722:
/*!***************************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/inspection-results-reports/InspectionResultsReportsComponent.ts ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionResultsReportsComponent": () => (/* binding */ InspectionResultsReportsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);

















function InspectionResultsReportsComponent_option_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const service_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", service_r6.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](service_r6.serviceName);
  }
}
function InspectionResultsReportsComponent_option_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", pt_r7.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](pt_r7.lkValueEname);
  }
}
function InspectionResultsReportsComponent_tr_89_button_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_tr_89_button_18_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r14);
      const item_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r12.submitReportPayment(item_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, "Payment");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function InspectionResultsReportsComponent_tr_89_button_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_tr_89_button_19_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r17);
      const item_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r15.downloadInspectionReport(item_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Print ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function InspectionResultsReportsComponent_tr_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](17, "td", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](18, InspectionResultsReportsComponent_tr_89_button_18_Template, 2, 0, "button", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](19, InspectionResultsReportsComponent_tr_89_button_19_Template, 2, 0, "button", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.fahesReceiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.plateTypeName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.reportFee, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.ownerName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.prevReqsForThisReport, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", item_r8.isPaymentRequired == 1 ? "Paid" : "Free", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.isPaymentRequired == 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", item_r8.isPaymentRequired == 0);
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function InspectionResultsReportsComponent_li_95_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "li", 75)(1, "a", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_li_95_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r20);
      const page_r18 = restoredCtx.$implicit;
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r19.changePage(page_r18));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const page_r18 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](2, _c0, ctx_r3.currentPage === page_r18));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](page_r18);
  }
}
function InspectionResultsReportsComponent_div_109_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 77)(1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function InspectionResultsReportsComponent_div_109_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r23);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r22.onSelectPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "label", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const pt_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("id", "pt" + pt_r21.lkCodeValue)("value", pt_r21.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("for", "pt" + pt_r21.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", pt_r21.lkValueEname, " ");
  }
}
function InspectionResultsReportsComponent_div_111_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ng-option", 86)(1, "div", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r25 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", c_r25.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", c_r25.customerName, " ");
  }
}
function InspectionResultsReportsComponent_div_111_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 80)(1, "div", 81)(2, "label", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "ng-select", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("change", function InspectionResultsReportsComponent_div_111_Template_ng_select_change_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r27);
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r26.isPaymentValid = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](5, 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](6, "ng-option", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](7, InspectionResultsReportsComponent_div_111_ng_option_7_Template, 3, 2, "ng-option", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r5.creditCustomerList);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
class InspectionResultsReportsComponent {
  constructor(InspectionService, paymentService, sharedLookup, lookupServ, vehicleService, fb, ssrsPrintService) {
    this.InspectionService = InspectionService;
    this.paymentService = paymentService;
    this.sharedLookup = sharedLookup;
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.fb = fb;
    this.ssrsPrintService = ssrsPrintService;
    this.inspectionReports = [];
    this.currentPage = 1;
    this.pageSize = 10;
    this.plateTypes = [];
    this.subServices = [];
    this.isPaymentValid = true;
    this.creditCustomerList = [];
    this.paymentName = 'Card';
    this.isSuccess = false;
    this.isPayCanceled = false;
    this.isNotReachable = false;
    this.isPaymentStarted = false;
    this.manualReg = this.fb.group({
      selectedPayment: [],
      selectedServiceType: [],
      selectedCust: [],
      showCredit: [false],
      paymentTypes: [[]],
      serviceTypeList: [[]]
    });
  }
  ngOnInit() {
    this.loadReportDetails();
    this.createInspectionReportsSearchForm();
    this.bindSearchFormChange();
    this.loadPlateTypes();
    this.sharedLookup.serviceTypeList$.subscribe(data => {
      this.manualReg.get('serviceTypeList').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.paymentMethods).subscribe(data => {
      this.manualReg.get('paymentTypes').setValue(data.items);
      const firstPaymentType = data.items.find(item => item.lkCodeValue === src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_1__.PaymentMethods.Card).lkCodeValue;
      this.manualReg.get('selectedPayment').setValue(firstPaymentType);
    });
  }
  onSelectPayment() {
    console.log('selectedPayment', this.manualReg.get('selectedPayment').value);
    console.log('manualReg', this.manualReg.value);
    if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_1__.PaymentMethods.CreditCustomer) {
      this.manualReg.get('showCredit').setValue(true);
      this.vehicleService.getCreditCustomer(this.manualReg.get('selectedCust').value).subscribe(data => {
        this.creditCustomerList = data.items;
      });
      this.isPaymentValid = this.manualReg.get('selectedCust').value ? true : false;
    } else {
      this.manualReg.get('showCredit').setValue(false);
      this.isPaymentValid = true;
    }
    this.paymentName = this.manualReg.get('paymentTypes').value.find(payId => payId.lkCodeValue == this.manualReg.get('selectedPayment').value).lkValueEname;
  }
  cancelFailed() {
    this.isNotReachable = false;
    this.isPayCanceled = false;
    this.isSuccess = false;
    this.cardStatus = '';
    this.isPaymentStarted = false;
  }
  loadSubServices(serviceType) {
    this.InspectionService.getSubServices({
      serviceType: serviceType
    }).subscribe(data => {
      this.subServices = data.items;
    });
  }
  loadPlateTypes() {
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.plateTypes = data;
    });
  }
  bindSearchFormChange() {
    this.inspectionReportsSearchForm.controls.serviceType.valueChanges.subscribe(res => {
      this.loadSubServices(res);
    });
    this.inspectionReportsSearchForm.valueChanges.subscribe(formValue => {
      let value = this.inspectionReportsSearchForm.value;
      value.serviceType = value.serviceType == -1 ? null : value.serviceType;
      value.plateType = value.plateType == -1 ? null : value.plateType;
      value.serviceId = value.serviceId == -1 ? null : value.serviceId;
      this.InspectionService.getInspectedVehicleReportDetails(value).subscribe(data => {
        console.log("bind", data);
        this.inspectionReports = data.items;
      });
    });
  }
  createInspectionReportsSearchForm() {
    this.inspectionReportsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormGroup({
      plateNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(null),
      plateType: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(-1),
      vinNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(null),
      receiptNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(null),
      serviceType: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(-1),
      serviceId: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(-1),
      fromDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(null),
      toDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControl(null)
    });
  }
  submitReportPayment(reportPayment) {
    console.log("RP", reportPayment);
    const date = new Date();
    this.currentDateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_12__.DatePipe('en-US').transform(date, 'dd MMM yyyy');
    this.currentTimeFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_12__.DatePipe('en-US').transform(date, 'h:mm a');
    this.reportPayment = reportPayment;
  }
  submitPayment() {
    this.isPaymentStarted = true;
    this.payment = {
      paymentMethodId: this.manualReg.get('selectedPayment').value,
      serviceRequestFeesDto: [{
        feesAmount: this.reportPayment.reportFee,
        requestId: this.reportPayment.requestId,
        serviceTypeId: this.reportPayment.serviceId,
        customerId: this.manualReg.get('selectedCust').value == undefined ? null : parseInt(this.manualReg.get('selectedCust').value),
        subDiscount: 0
      }]
    };
    if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_1__.PaymentMethods.Card) {
      this.paymentService.submitInspectionReportPayment(this.payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.catchError)(error => {
        if (error.name === 'TimeoutError') {
          this.isNotReachable = true;
          this.displayPaymentDetails = 'block';
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.throwError)(error);
      })).subscribe(data => {
        console.log("res", data);
        let paymentResult = data;
        if (data.items) {
          if (!paymentResult.items.isCanceled && !paymentResult.items.isDeviceNotReachable) {
            this.isSuccess = true;
            this.downloadInspectionReport(this.reportPayment);
            this.loadReportDetails();
          } else {
            if (paymentResult.items.isCanceled) {
              "pay cancel";
              this.isPayCanceled = true;
            }
            if (paymentResult.items.isDeviceNotReachable) {
              this.isNotReachable = true;
            }
          }
        } else {
          if (paymentResult.items.isCanceled) {
            this.isPayCanceled = true;
          }
          if (paymentResult.items.isDeviceNotReachable) {
            this.isNotReachable = true;
          }
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        this.isPaymentStarted = false;
        console.error(error);
      });
    }
    if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_1__.PaymentMethods.Cash) {
      this.paymentService.submitInspectionReportPayment(this.payment).subscribe(data => {
        console.log("res", data);
        if (data.items) {
          this.isSuccess = true;
          this.isNotReachable = false;
          this.isPayCanceled = false;
          this.downloadInspectionReport(this.reportPayment);
          this.loadReportDetails();
        } else {
          this.isNotReachable = true;
          this.isPayCanceled = false;
          this.isSuccess = false;
        }
      }, error => {
        this.isSuccess = false;
      });
    }
    if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_1__.PaymentMethods.CreditCustomer) {
      this.paymentService.submitInspectionReportPayment(this.payment).subscribe(data => {
        console.log("res", data);
        if (data.items) {
          this.isSuccess = true;
          this.isPayCanceled = false;
          this.isNotReachable = false;
          this.downloadInspectionReport(this.reportPayment);
          this.loadReportDetails();
        } else {
          this.isNotReachable = true;
          this.isSuccess = false;
          this.isPayCanceled = false;
        }
      }, error => {
        this.isSuccess = false;
      });
    }
  }
  logSelectedReport(reportPayment) {
    var body = {
      fahesReceiptNo: reportPayment.fahesReceiptNo,
      requestId: reportPayment.requestId,
      reportFee: reportPayment.reportFee,
      reportFeesType: reportPayment.reportFeesType
    };
    this.InspectionService.insertInspectionResultsReportLog(body).subscribe(data => {});
  }
  loadReportDetails() {
    this.InspectionService.getInspectedVehicleReportDetails({}).subscribe(data => {
      this.inspectionReports = data.items;
    });
  }
  totalPages() {
    let total = 0;
    total = Math.ceil(this.inspectionReports?.length / this.pageSize);
    return Array.from({
      length: total
    }, (_, i) => i + 1);
  }
  changePage(page) {
    if (page >= 1 && page <= this.totalPages().length) this.currentPage = page;
  }
  get paginatedData() {
    if (this.pageSize === -1) return this.inspectionReports; // Return all data when pageSize is -1
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = Math.min(startIndex + this.pageSize, this.inspectionReports?.length);
    return this.inspectionReports?.slice(startIndex, endIndex);
  }
  downloadInspectionReport(report) {
    console.log("downloadInspectionReport");
    this.logSelectedReport(report);
    let ssrs = {
      moduleName: "Inspection Results",
      reportName: "InspectionByID",
      parameters: {
        RequestId: report.requestId.toString()
      }
    };
    console.log('ssrs', ssrs);
    this.InspectionService.getInspectedVehicleReportDetails(this.inspectionReportsSearchForm.value).subscribe(data => {
      this.inspectionReports = data.items;
    });
    this.ssrsPrintService.downloadReport(ssrs, report.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_0__.PrintEnum.printSave);
  }
  resetSearchForm() {
    this.inspectionReportsSearchForm.reset();
  }
  static #_ = this.ɵfac = function InspectionResultsReportsComponent_Factory(t) {
    return new (t || InspectionResultsReportsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_3__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_4__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_5__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_6__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_7__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_8__.SsrsPrintService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
    type: InspectionResultsReportsComponent,
    selectors: [["app-inspection-results-reports"]],
    decls: 154,
    vars: 27,
    consts: [[1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], ["id", "headingTwo", 1, "accordion-header"], [1, "accordion-body"], [1, "container", "mt-4"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-3"], [1, "col-md-3", "mb-3"], ["for", "fromDate"], ["type", "datetime-local", "id", "fromDate", "formControlName", "fromDate", 1, "form-control"], ["for", "toDate"], ["type", "datetime-local", "id", "toDate", "formControlName", "toDate", 1, "form-control"], ["for", "receiptNo"], ["type", "text", "id", "receiptNo", "formControlName", "receiptNo", 1, "form-control"], ["for", "serviceType"], ["id", "serviceType", "formControlName", "serviceType", 1, "form-control"], ["value", "-1", "selected", "", "disabled", ""], ["value", "1"], ["value", "2"], ["value", "3"], ["for", "serviceId"], ["id", "serviceId", "formControlName", "serviceId", 1, "form-control", 3, "disabled"], [3, "value", 4, "ngFor", "ngForOf"], ["for", "plateNo"], ["type", "number", "id", "plateNo", "formControlName", "plateNo", 1, "form-control"], ["for", "plateType"], ["id", "plateType", "formControlName", "plateType", 1, "form-control"], ["for", "vinNo"], ["type", "text", "id", "vinNo", "formControlName", "vinNo", 1, "form-control"], [1, "col-md-12", "text-end"], ["type", "reset", 1, "btn", "btn-outline-gray", 3, "click"], [1, "bi", "bi-arrow-clockwise", 2, "color", "orange"], [1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "exampleModalLabel", 1, "modal-title"], [1, "modal-body"], [1, "payment-info"], [1, "payment-type"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop2", 1, "btn", "btn-orange", 3, "disabled", "click"], [3, "isPaymentStarted", "isSuccess", "isPayCanceled", "isNotReachable", "totalAmountTh", "currentDateFormat", "requestRefId", "currentTimeFormat", "paymentName"], ["data-bs-backdrop", "static", "id", "PrintReceipt", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "pt-lab"], [3, "value"], ["id", "print"], ["type", "submit", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 3, "click", 4, "ngIf"], ["class", "btn btn-outline-orange small-text", 3, "click", 4, "ngIf"], ["type", "submit", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "click"], [1, "btn", "btn-outline-orange", "small-text", 3, "click"], [1, "page-item", 3, "ngClass"], ["id", "pagesId", 1, "page-link", 3, "click"], [1, "btn-radio"], ["type", "radio", "formControlName", "selectedPayment", 3, "id", "value", "ngModelChange"], [3, "for"], [1, "col-md-6", "col-lg-6"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "formControlName", "selectedCust", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "clearSearchOnAdd", "minTermLength", "change"], [1, "dropdown-container"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"]],
    template: function InspectionResultsReportsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 0)(3, "div", 2)(4, "div", 3)(5, "div", 4)(6, "div", 5)(7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](8, "br")(9, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](11, "Inspection Reports");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "div", 7)(13, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](14, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](15, "form", 9)(16, "div", 10)(17, "div", 11)(18, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](19, "From Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](20, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](21, "div", 11)(22, "label", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](23, "To Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](24, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](25, "div", 11)(26, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](27, "Receipt No");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](28, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](29, "div", 11)(30, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](31, "Service Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](32, "select", 19)(33, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](34, "Select Service Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](35, "option", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](36, "Inspection Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](37, "option", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](38, "Vin Stamping");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](39, "option", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](40, "Tanker Certificate");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](41, "div", 11)(42, "label", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](43, "Selected Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](44, "select", 25)(45, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](46, "Select Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](47, InspectionResultsReportsComponent_option_47_Template, 2, 2, "option", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](48, "div", 11)(49, "label", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](50, "Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](51, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](52, "div", 11)(53, "label", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](54, "Plate Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](55, "select", 30)(56, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](57, "Select Plate Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](58, InspectionResultsReportsComponent_option_58_Template, 2, 2, "option", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](59, "div", 11)(60, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](61, "Vin No");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](62, "input", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](63, "div", 33)(64, "button", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_Template_button_click_64_listener() {
          return ctx.resetSearchForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](65, " reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](66, "i", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](67, "table", 36)(68, "thead")(69, "tr", 37)(70, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](71, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](72, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](73, " Service Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](74, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](75, " Plate No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](76, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](77, " Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](78, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](79, " Report Fee ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](80, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](81, " Owner Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](82, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](83, " No. Of Prev Times ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](84, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](85, " Cost");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](86, "th", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](87, " Action ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](88, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](89, InspectionResultsReportsComponent_tr_89_Template, 20, 10, "tr", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](90, "div", 40)(91, "ul", 41)(92, "li", 42)(93, "a", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_Template_a_click_93_listener() {
          return ctx.changePage(ctx.currentPage - 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](94, "i", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](95, InspectionResultsReportsComponent_li_95_Template, 3, 4, "li", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](96, "li", 42)(97, "a", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_Template_a_click_97_listener() {
          return ctx.changePage(ctx.currentPage + 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](98, "i", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](99, "div", 47)(100, "div", 48)(101, "div", 49)(102, "div", 50)(103, "h1", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](104, "Payment Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](105, "form", 9)(106, "div", 52)(107, "div", 53)(108, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](109, InspectionResultsReportsComponent_div_109_Template, 4, 4, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](110, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](111, InspectionResultsReportsComponent_div_111_Template, 8, 4, "div", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](112, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](113, "div", 57)(114, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](115, "Summary Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](116, "div", 0)(117, "div", 58)(118, "table", 59)(119, "thead")(120, "tr")(121, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](122, "Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](123, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](124, "Fees");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](125, "tbody")(126, "tr")(127, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](128, " Inspection Report ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](129, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](130);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](131, "tfoot")(132, "tr")(133, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](134, "Total");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](135, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](136);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](137, "div", 60)(138, "button", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](139, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](140, "button", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_Template_button_click_140_listener() {
          return ctx.submitPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](141, "Submit");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](142, "payment-transaction-status-modal", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](143, "div", 64)(144, "div", 48)(145, "div", 49)(146, "div", 50)(147, "h1", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](148, "img", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](149, " Receipt ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](150, "button", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](151, "div", 52)(152, "label", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](153, " Printing Receipt... ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.inspectionReportsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", (ctx.inspectionReportsSearchForm.controls.serviceType == null ? null : ctx.inspectionReportsSearchForm.controls.serviceType.value) == -1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.subServices);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.paginatedData);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](23, _c1, ctx.currentPage === 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.totalPages());
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](25, _c1, ctx.currentPage === ctx.totalPages().length));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.manualReg);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.manualReg.get("paymentTypes").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.manualReg.get("showCredit").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx.reportPayment == null ? null : ctx.reportPayment.reportFee, " QAR ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx.reportPayment == null ? null : ctx.reportPayment.reportFee, " QAR ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.isPaymentValid);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("isPaymentStarted", ctx.isPaymentStarted)("isSuccess", ctx.isSuccess)("isPayCanceled", ctx.isPayCanceled)("isNotReachable", ctx.isNotReachable)("totalAmountTh", ctx.reportPayment == null ? null : ctx.reportPayment.reportFee)("currentDateFormat", ctx.currentDateFormat)("requestRefId", ctx.reportPayment == null ? null : ctx.reportPayment.requestId)("currentTimeFormat", ctx.currentTimeFormat)("paymentName", ctx.paymentName);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormControlName, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_9__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_16__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_16__.NgOptionComponent],
    styles: ["th[_ngcontent-%COMP%] {\n    color: white;\n    background-color: #F89828;\n}\n\n\n.custom-table[_ngcontent-%COMP%] {\n    text-align: center;\n    color: black;\n    background-color: #ffdcb3;\n    border: 1px solid white;\n    border-collapse: collapse;\n    margin: 20px 0;\n}\n\ntable[_ngcontent-%COMP%] {\n    text-align: center;\n}\n\nimg[_ngcontent-%COMP%] {\n    width: 20px;\n    height: 20px;\n}\n\n#print[_ngcontent-%COMP%] {\n    font-size: small;\n}\n\n.small-text[_ngcontent-%COMP%] {\n    font-size: small;\n}\n\n\n.pagination-container[_ngcontent-%COMP%] {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    margin-top: 20px;\n}\n\n.pagination[_ngcontent-%COMP%] {\n    list-style-type: none;\n    display: flex;\n    margin: 0;\n    padding: 0;\n}\n\n.page-item[_ngcontent-%COMP%] {\n    margin: 0 2px;\n}\n\n.page-link[_ngcontent-%COMP%] {\n    cursor: pointer;\n    padding: 5px 5px;\n    text-decoration: none;\n}\n\n#pagesId[_ngcontent-%COMP%] {\n    background-color: #F89828;\n    color: white;\n}\n\nli.page-item.active[_ngcontent-%COMP%]   #pagesId[_ngcontent-%COMP%] {\n    background-color: white;\n    color: #F89828;\n    font-weight: bold;\n    border-color: #F89828;\n}\n\n.bi[_ngcontent-%COMP%] {\n    color: #F89828;\n}\n\n.no-request[_ngcontent-%COMP%] {\n    margin-top: 50px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvaW5zcGVjdGlvbi1yZXN1bHRzLXJlcG9ydHMvaW5zcGVjdGlvbi1yZXN1bHRzLXJlcG9ydHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFlBQVk7SUFDWix5QkFBeUI7QUFDN0I7OztBQUdBO0lBQ0ksa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsdUJBQXVCO0lBQ3ZCLHlCQUF5QjtJQUN6QixjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksV0FBVztJQUNYLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7OztBQUdBO0lBQ0ksYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0kscUJBQXFCO0lBQ3JCLGFBQWE7SUFDYixTQUFTO0lBQ1QsVUFBVTtBQUNkOztBQUVBO0lBQ0ksYUFBYTtBQUNqQjs7QUFFQTtJQUNJLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIscUJBQXFCO0FBQ3pCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsY0FBYztJQUNkLGlCQUFpQjtJQUNqQixxQkFBcUI7QUFDekI7O0FBRUE7SUFDSSxjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksZ0JBQWdCO0FBQ3BCIiwic291cmNlc0NvbnRlbnQiOlsidGgge1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xufVxuXG5cbi5jdXN0b20tdGFibGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZGNiMztcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIG1hcmdpbjogMjBweCAwO1xufVxuXG50YWJsZSB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pbWcge1xuICAgIHdpZHRoOiAyMHB4O1xuICAgIGhlaWdodDogMjBweDtcbn1cblxuI3ByaW50IHtcbiAgICBmb250LXNpemU6IHNtYWxsO1xufVxuXG4uc21hbGwtdGV4dCB7XG4gICAgZm9udC1zaXplOiBzbWFsbDtcbn1cblxuXG4ucGFnaW5hdGlvbi1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuXG4ucGFnaW5hdGlvbiB7XG4gICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luOiAwO1xuICAgIHBhZGRpbmc6IDA7XG59XG5cbi5wYWdlLWl0ZW0ge1xuICAgIG1hcmdpbjogMCAycHg7XG59XG5cbi5wYWdlLWxpbmsge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBwYWRkaW5nOiA1cHggNXB4O1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cblxuI3BhZ2VzSWQge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG5saS5wYWdlLWl0ZW0uYWN0aXZlICNwYWdlc0lkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgICBjb2xvcjogI0Y4OTgyODtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBib3JkZXItY29sb3I6ICNGODk4Mjg7XG59XG5cbi5iaSB7XG4gICAgY29sb3I6ICNGODk4Mjg7XG59XG5cbi5uby1yZXF1ZXN0IHtcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xufVxuXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 67961:
/*!****************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/landing/landing.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingComponent": () => (/* binding */ LandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);







const _c0 = ["barCode"];
function LandingComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
function LandingComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Please, click Enter to proceed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
class LandingComponent {
  constructor(formBuilder, router, sharedDataService, sideNav, el) {
    this.formBuilder = formBuilder;
    this.router = router;
    this.sharedDataService = sharedDataService;
    this.sideNav = sideNav;
    this.el = el;
    this.submitted = false;
    this.isBarCodeScanned = false;
    this.landingForm = formBuilder.group({
      displayBarCode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern(/^.{3,8}$/)]]
    });
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(2, 6);
  }
  getIstimaraCode() {
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#barCode');
      if (myInput) {
        myInput.focus();
      }
    }, 200);
  }
  onBarcodeInput(event) {
    const barcodeValue = event.target.value;
    this.landingForm.get('displayBarCode').setValue(barcodeValue);
    this.isBarCodeScanned = true;
    this.readBarCode();
  }
  readBarCode() {
    if (this.landingForm.valid) {
      this.sharedDataService.setTextEx(this.landingForm.get('displayBarCode').value);
      this.router.navigate(['backoffice/exempted']);
      const modalElement = document.getElementById('istimaraCode');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    }
  }
  ngOnDestroy() {
    this.landingForm.get('displayBarCode').setValue('');
  }
  static #_ = this.ɵfac = function LandingComponent_Factory(t) {
    return new (t || LandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: LandingComponent,
    selectors: [["app-landing"]],
    viewQuery: function LandingComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.barCode = _t.first);
      }
    },
    decls: 36,
    vars: 3,
    consts: [["lang", "en"], ["charset", "utf-8"], ["content", "width=device-width, initial-scale=1.0", "name", "viewport"], ["href", "./assets/img/favicon.png", "rel", "icon"], [3, "formGroup"], [1, "main-container-wrap"], [1, "rvd"], [1, "rvd-links"], ["href", "#", "data-bs-toggle", "modal", "data-bs-target", "#istimaraCode", 3, "click"], ["src", "./assets/img/scan.svg"], ["routerLink", "../exempted", 1, "btn", "btn-link"], ["src", "./assets/img/keyboard.svg"], ["id", "istimaraCode", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["src", "./assets/img/scan.svg", "width", "50px"], [1, "modal-body"], ["type", "text", "id", "barCode", "formControlName", "displayBarCode", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["barCode", ""], ["class", "error-message", 4, "ngIf"], ["class", "info-msg", 4, "ngIf"], [1, "error-message"], [1, "info-msg"]],
    template: function LandingComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "html", 0)(1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "meta", 1)(3, "meta", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "title");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5, "FAHES ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "link", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "body")(8, "form", 4)(9, "div", 5)(10, "div", 6)(11, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12, " Read Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14, " Choose the preferred option ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "div", 7)(16, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function LandingComponent_Template_a_click_16_listener() {
          return ctx.getIstimaraCode();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](17, "img", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19, "Scan Istimara");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](21, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](23, "Manual Entry");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "div", 12)(25, "div", 13)(26, "div", 14)(27, "div", 15)(28, "h1", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](29, "img", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](30, " Istimara Bar Code ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](31, "div", 18)(32, "input", 19, 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("keyup.enter", function LandingComponent_Template_input_keyup_enter_32_listener($event) {
          return ctx.onBarcodeInput($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](34, LandingComponent_div_34_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](35, LandingComponent_div_35_Template, 2, 0, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.landingForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.landingForm.get("displayBarCode").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.landingForm.valid);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterLink, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 25414:
/*!*********************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/mobile-booking/mobile-booking/mobile-booking.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileBookingComponent": () => (/* binding */ MobileBookingComponent)
/* harmony export */ });
/* harmony import */ var _Users_os_Desktop_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var _classes_payment_details__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../classes/payment-details */ 48672);
/* harmony import */ var src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/modules/shared/custom-validators/date.validator */ 97633);
/* harmony import */ var src_app_core_utilities_enums_inspection_service_type_classification_rnum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utilities/enums/inspection-service-type-classification.rnum */ 46949);
/* harmony import */ var src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utilities/enums/inspectionServiceTypes */ 43327);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_registration_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/registration.service */ 59212);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _shared_thousand_separator_directive__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../shared/thousand-separator.directive */ 59903);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);




























function MobileBookingComponent_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "option", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ownerPidType_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("value", ownerPidType_r22.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ownerPidType_r22.lkValueEname, " ");
  }
}
function MobileBookingComponent_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_25_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
function MobileBookingComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_25_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r2.mobileBookingForm.get("pidNo").value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, " * Enter a valid Owner PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_58_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
const _c0 = function () {
  return ["serviceRequest", "contactPersonPhone"];
};
function MobileBookingComponent_div_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_58_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r6.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](1, _c0)).value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_59_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Enter a valid mobile number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_64_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
const _c1 = function () {
  return ["serviceRequest", "secondaryPhoneNo"];
};
function MobileBookingComponent_div_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_64_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r8.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](1, _c1)).value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Enter a valid mobile number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_70_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, " *PID not valid ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_75_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Please enter valid email address ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_80_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_85_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_90_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_91_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Preferred date can't be less than today date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_92_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Invalid Date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_116_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "input", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](2, "label", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const service_r26 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("id", "service" + service_r26.serviceId)("value", service_r26.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("for", "service" + service_r26.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](service_r26.descriptionEn);
  }
}
function MobileBookingComponent_ng_container_132_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](1, "div", 68)(2, "input", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_ng_container_132_Template_input_ngModelChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r29);
      const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r28.onSelectPayment($event));
    })("ngModelChange", function MobileBookingComponent_ng_container_132_Template_input_ngModelChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r29);
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r30.paymentType.paymentTypeId = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const paymentMethod_r27 = ctx.$implicit;
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("id", paymentMethod_r27.lkCodeValue)("ngModel", ctx_r18.paymentType.paymentTypeId)("value", paymentMethod_r27.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵattribute"]("for", paymentMethod_r27.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](paymentMethod_r27.lkValueEname);
  }
}
function MobileBookingComponent_div_134_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "ng-option", 77)(1, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r32 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("value", c_r32.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", c_r32.customerName, " ");
  }
}
function MobileBookingComponent_div_134_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 34)(1, "div", 72)(2, "label", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](4, "ng-select", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_div_134_Template_ng_select_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r34);
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r33.selectedCustomer = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](5, 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](6, "ng-option", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](7, MobileBookingComponent_div_134_ng_option_7_Template, 3, 2, "ng-option", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngModel", ctx_r19.selectedCustomer)("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx_r19.creditCustomerList);
  }
}
function MobileBookingComponent_div_136_tr_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "tr")(1, "td", 83)(2, "div", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" * Fees should be ", ctx_r35.downpaymentConfigTh, " or more ");
  }
}
function MobileBookingComponent_div_136_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 79)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, "Summary Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 1)(4, "div", 80)(5, "table", 81)(6, "thead")(7, "tr")(8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](9, "Service");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](11, "Fees (QAR) ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](12, "tbody")(13, "tr")(14, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](16, "td")(17, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_div_136_Template_input_ngModelChange_17_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r37);
      const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r36.downpaymentThousand = $event);
    })("ngModelChange", function MobileBookingComponent_div_136_Template_input_ngModelChange_17_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r37);
      const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r38.validateSubmitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](18, MobileBookingComponent_div_136_tr_18_Template, 4, 1, "tr", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](19, "tfoot")(20, "tr")(21, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](22, "Total");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](23, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()();
  }
  if (rf & 2) {
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ctx_r20.getSelectedInpsectionServiceType(), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngModel", ctx_r20.downpaymentThousand);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r20.payError);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ctx_r20.downpaymentThousand, " QAR ");
  }
}
function MobileBookingComponent_ng_container_142_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](1, "payment-transaction-status-modal", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("onCancelEvent", function MobileBookingComponent_ng_container_142_Template_payment_transaction_status_modal_onCancelEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r40);
      const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r39.closePaymentDetailsModal());
    })("onCancelFailedEvent", function MobileBookingComponent_ng_container_142_Template_payment_transaction_status_modal_onCancelFailedEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r40);
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r41.closePaymentDetailsModal());
    })("onDownloadPaymentEvent", function MobileBookingComponent_ng_container_142_Template_payment_transaction_status_modal_onDownloadPaymentEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r40);
      const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r42.downloadReport());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipe"](2, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipe"](3, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("isPaymentStarted", ctx_r21.isPaymentStarted)("email", "test")("isSuccess", ctx_r21.isSuccess)("isPayCanceled", ctx_r21.isPayCanceled)("isNotReachable", ctx_r21.isNotReachable)("requestRefId", ctx_r21.requestId)("currentDateFormat", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipeBind2"](2, 10, ctx_r21.getCurrentDate(), "dd MMM yyyy"))("currentTimeFormat", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipeBind2"](3, 13, ctx_r21.getCurrentDate(), "HH:mm a"))("totalAmountTh", ctx_r21.totalFeesTh)("paymentName", ctx_r21.getPaymentMethodName(ctx_r21.paymentType.paymentTypeId));
  }
}
const _c2 = function () {
  return ["serviceRequest", "contactPersonName"];
};
const _c3 = function () {
  return ["serviceRequest", "pid"];
};
const _c4 = function () {
  return ["serviceRequest", "contactPersonEmail"];
};
const _c5 = function () {
  return ["serviceRequest", "location"];
};
const _c6 = function () {
  return ["serviceRequest", "noOfVehicle"];
};
const _c7 = function () {
  return ["serviceRequest", "inspectionDate"];
};
const _c8 = function (a0) {
  return {
    "display": a0
  };
};
class MobileBookingComponent {
  constructor(lookupService, registerService, fb, router, paymentService, vehicleService, sideNav, ssrsPrintServ, globalServ, sharedDataService, thousandService) {
    this.lookupService = lookupService;
    this.registerService = registerService;
    this.fb = fb;
    this.router = router;
    this.paymentService = paymentService;
    this.vehicleService = vehicleService;
    this.sideNav = sideNav;
    this.ssrsPrintServ = ssrsPrintServ;
    this.globalServ = globalServ;
    this.sharedDataService = sharedDataService;
    this.thousandService = thousandService;
    this.display = 'none';
    this.displayPaymentDetails = 'none';
    this.isCollectPayment = false;
    this.downpaymentAmount = 0;
    this.feesDiscount = 0;
    this.requestId = 0;
    this.isCreditSelected = false;
    this.payError = false;
    this.isPaymentStarted = false;
    this.paymentType = new _classes_payment_details__WEBPACK_IMPORTED_MODULE_3__.PaymentDetails();
    this.initForm();
    this.fillLookupControls();
  }
  initForm() {
    this.sideNav.setActiveEnt(2, 3);
    this.mobileBookingForm = this.fb.group({
      ownerName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      pidNo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required]],
      ownerType: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required]],
      address: [''],
      serviceRequest: this.fb.group({
        // contactType: ['', Validators.required],
        contactPersonName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
        contactPersonPhone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^[34567]\d{7}$/)]],
        contactPersonEmail: [''],
        pid: [''],
        location: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required]],
        noOfVehicle: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.min(0)]],
        inspectionDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_4__.DateValidator.NotLessThanToday, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_4__.DateValidator.ValidateFourDigitYear]],
        serviceType: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
        secondaryPhoneNo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^[34567]\d{7}$/)]]
      })
    });
    /*this.sharedDataService.stationId$.subscribe((res) => {
      this.stationId = res;
    });
    */
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.mobileBookingForm.get('pidNo').valueChanges.subscribe(value => {
      // Check validity and log "test" if it's valid
      if (this.mobileBookingForm.get('pidNo').value && this.mobileBookingForm.get('pidNo').valid) {
        this.vehicleService.getOwnerNameByPid(this.mobileBookingForm.get('pidNo').value.toString()).subscribe(response => {
          this.mobileBookingForm.get('ownerName').setValue(response.items);
        });
      }
    });
    this.vehicleService.getDownPaymentAmount().subscribe(response => {
      this.downpaymentConfig = response.items;
      this.downpaymentThousand = this.thousandService.addThousandSeparator(this.downpaymentConfig.toString());
      this.downpaymentConfigTh = this.thousandService.addThousandSeparator(this.downpaymentConfig.toString());
    });
  }
  onKeydown(event) {
    if (event.target instanceof HTMLInputElement && event.target.type === 'number') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
      }
    }
  }
  //#region Lookups  : 
  getOwnerPidTypes() {
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.mobileBookingOwnerPidType).subscribe(response => {
      this.ownerPidTypes = response.items;
    });
  }
  getServiceTypes() {
    this.registerService.getInspectionServiceTypes(src_app_core_utilities_enums_inspection_service_type_classification_rnum__WEBPACK_IMPORTED_MODULE_5__.ServiceTypeClassifications.External).subscribe(response => {
      this.serviceTypes = response.items.filter(x => x.serviceId != src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_6__.InspectionServiceTypes.ExternalInspection);
    });
  }
  getPaymentMethods() {
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.paymentMethods).subscribe(response => {
      this.paymentMethods = response.items;
    });
  }
  getContactTypes() {
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.contactType).subscribe(response => {
      this.contactTypes = response.items;
    });
  }
  formatPidInput(event) {
    let value = event.target.value;
    // Remove non-digit characters
    value = value.replace(/\D/g, '');
    if (this.mobileBookingForm.get("ownerType").value == 1) {
      let formattedValue = '';
      for (let i = 0; i < value.length; i++) {
        if (i === 2 || i === 6) {
          formattedValue += '-';
        }
        formattedValue += value[i];
      }
      event.target.value = formattedValue;
    }
  }
  validateOwnerPid() {
    // if the owner type is company
    if (this.mobileBookingForm.get("ownerType").value == 1) {
      this.mobileBookingForm.get('pidNo').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^\d{2}-\d{4}-\d{2}$/));
      this.mobileBookingForm.get('pidNo').updateValueAndValidity();
    } else {
      this.mobileBookingForm.get('pidNo').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^.{11}$/));
      this.mobileBookingForm.get('pidNo').updateValueAndValidity();
    }
  }
  fillLookupControls() {
    this.getOwnerPidTypes();
    this.getServiceTypes();
    this.getPaymentMethods();
    this.getContactTypes();
  }
  //#endregion
  getSelectedInpsectionServiceType() {
    if (this.serviceTypes) {
      let serviceType = this.serviceTypes.find(x => x.serviceId == this.mobileBookingForm.get(['serviceRequest', 'serviceType']).value);
      return serviceType == undefined ? "" : serviceType.descriptionEn;
    }
  }
  //Payments :
  collectPayment() {
    this.isCollectPayment = true;
    this.downpaymentAmount = Number(this.downpaymentThousand.replace(/,/g, ''));
    this.display = 'block';
  }
  submitForm() {
    var _this = this;
    return (0,_Users_os_Desktop_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.globalServ.getStationPaymentMethods(_this.stationId).subscribe(response => {
        _this.paymentMethods = response.items;
      });
      if (_this.requestId == 0) {
        // Handle form submission for mobile booking
      } else {
        _this.collectPayment();
      }
    })();
  }
  onDownpaymentChange(event) {
    this.downpaymentAmount = event.target.value;
  }
  cancel() {
    this.router.navigate(['/registration/landing']);
  }
  submitPayment() {
    var _this2 = this;
    return (0,_Users_os_Desktop_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.mobileBookingForm.valid) {
        let mobileBookingWorkFlowRequest;
        let mobileBookingRequest = _this2.mobileBookingForm.value;
        let serviceRequest = _this2.mobileBookingForm.get('serviceRequest').value;
        delete mobileBookingRequest.serviceRequest;
        //Parse value to int as the reactive form bind it as string 
        mobileBookingRequest.ownerType = parseInt(mobileBookingRequest.ownerType);
        const pidNumber = Number(mobileBookingRequest.pidNo.toString().replace(/-/g, ''));
        mobileBookingRequest.pidNo = pidNumber;
        mobileBookingRequest.address = mobileBookingRequest.address != null ? mobileBookingRequest.address : "";
        const downpaymentInt = Number(_this2.downpaymentAmount.toString().replace(/,/g, ''));
        mobileBookingRequest.downpaymentAmount = _this2.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer ? 0 : downpaymentInt;
        mobileBookingRequest.noOfVehicle = _this2.mobileBookingForm.get(['serviceRequest', 'noOfVehicle']).value;
        mobileBookingRequest.location = _this2.mobileBookingForm.get(['serviceRequest', 'location']).value;
        mobileBookingRequest.inspectionDate = _this2.mobileBookingForm.get(['serviceRequest', 'inspectionDate']).value;
        mobileBookingRequest.secondaryPhoneNo = _this2.mobileBookingForm.get(['serviceRequest', 'secondaryPhoneNo']).value;
        serviceRequest.registrationSource = src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupValueCodes.BackOffice;
        serviceRequest.serviceId = src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupValueCodes.Inspection;
        serviceRequest.stationId = parseInt(localStorage.getItem('stationId'));
        yield _this2.registerService.createServiceRequest(serviceRequest).subscribe(response => {
          mobileBookingRequest.requestId = response.items;
          _this2.requestId = response.items;
          _this2.registerService.submitMobileBooking(mobileBookingRequest).subscribe(response => {
            _this2.isRequestSubmitted = true;
            _this2.collectPayment();
            _this2.submitPaymentMobile();
            _this2.display = 'none';
          });
        });
      }
    })();
  }
  submitPaymentMobile() {
    const downpaymentInt = Number(this.downpaymentAmount.toString().replace(/,/g, ''));
    this.downpaymentAmount = downpaymentInt;
    let payment = {
      paymentMethodId: this.paymentType.paymentTypeId,
      serviceRequestFeesDto: [{
        feesAmount: this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer ? 0 : this.downpaymentAmount,
        requestId: this.requestId,
        serviceTypeId: this.mobileBookingForm.get(['serviceRequest', 'serviceType']).value,
        customerId: this.selectedCustomer == undefined ? null : this.selectedCustomer,
        subDiscount: this.feesDiscount
      }]
    };
    this.totalFeesTh = this.downpaymentThousand;
    this.isPaymentStarted = true;
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.Card) {
      this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_23__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_24__.catchError)(error => {
        if (error.name === 'TimeoutError') {
          this.isNotReachable = true;
          this.displayPaymentDetails = 'block';
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.throwError)(error);
      })).subscribe(data => {
        // Handle the successful response
        const paymentResult = data;
        const messageCode = paymentResult.messageCode;
        const errorMessage = paymentResult.errorMessage;
        if (paymentResult.items.isCaptured) {
          this.isSuccess = true;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.closePaymentDetailsModal();
          }, 3000);
        }
        if (paymentResult.items.isCanceled) {
          this.isPayCanceled = true;
        }
        if (paymentResult.items.isDeviceNotReachable) {
          this.isNotReachable = true;
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        console.error(error);
      });
    }
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.Cash) {
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          this.isSuccess = true;
          this.isNotReachable = false;
          this.isPayCanceled = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.closePaymentDetailsModal();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isPayCanceled = false;
          this.isSuccess = false;
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        this.isSuccess = false;
        this.displayPaymentDetails = 'block';
      });
    }
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer) {
      this.totalFeesTh = '';
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          this.isSuccess = true;
          this.isPayCanceled = false;
          this.isNotReachable = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.closePaymentDetailsModal();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isSuccess = false;
          this.isPayCanceled = false;
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        this.isSuccess = false;
        this.displayPaymentDetails = 'block';
      });
    }
    this.cancelPayment();
  }
  onSelectPayment(paymentMethodTypeId) {
    if (paymentMethodTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer) {
      this.isCreditSelected = true;
      this.vehicleService.getCreditCustomer(this.selectedCustomer).subscribe(data => {
        this.creditCustomerList = data.items;
      });
    } else {
      this.isCreditSelected = false;
    }
    // this.paymentName = this.manualReg.get('paymentTypes').value.find((payId => payId.lkCodeValue == this.manualReg.get('selectedPayment').value)).lkValueEname;
  }

  closePaymentDetailsModal() {
    this.isPaymentStarted = false;
    this.displayPaymentDetails = 'none';
    this.mobileBookingForm.reset();
    this.paymentType = new _classes_payment_details__WEBPACK_IMPORTED_MODULE_3__.PaymentDetails();
    this.isRequestSubmitted = false;
    this.isSuccess = false;
    this.isPayCanceled = false;
    this.isNotReachable = false;
    this.requestId = 0;
    this.isCreditSelected = false;
    this.selectedCustomer = undefined;
  }
  downloadReport() {
    this.ssrsPrintServ.downloadCustomerReport(this.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_8__.PrintEnum.save, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_9__.ModuleSourceEnum.mobile);
  }
  getCurrentDate() {
    return new Date();
  }
  getPaymentMethodName(paymentMethodId) {
    return this.paymentMethods.find(x => x.lkCodeValue == paymentMethodId).lkValueEname;
  }
  cancelPayment() {
    this.selectedCustomer = undefined;
    this.downpaymentAmount = this.downpaymentConfig;
    this.downpaymentThousand = this.thousandService.addThousandSeparator(this.downpaymentConfig.toString());
    const modalElement = document.getElementById('paymentDetailsModal');
  }
  validateSubmitPayment() {
    this.downpaymentThousand = this.thousandService.addThousandSeparator(this.downpaymentThousand);
    this.downpaymentAmount = Number(this.downpaymentThousand.replace(/,/g, ''));
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer && this.selectedCustomer == undefined) return false;
    if (this.downpaymentAmount < this.downpaymentConfig) {
      this.payError = true;
      return false;
    } else {
      this.payError = false;
      return true;
    }
  }
  static #_ = this.ɵfac = function MobileBookingComponent_Factory(t) {
    return new (t || MobileBookingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_10__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_registration_service__WEBPACK_IMPORTED_MODULE_11__.RegistrationService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_26__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_12__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_13__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_14__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_15__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_16__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_17__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_18__.ThousandSeparatorService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdefineComponent"]({
    type: MobileBookingComponent,
    selectors: [["app-mobile-booking"]],
    hostBindings: function MobileBookingComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("keydown", function MobileBookingComponent_keydown_HostBindingHandler($event) {
          return ctx.onKeydown($event);
        });
      }
    },
    decls: 143,
    vars: 56,
    consts: [[3, "formGroup"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "companyPersonDetails", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["id", "companyPersonDetailsHeading", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-companyPersonDetails", 1, "accordion-button"], ["id", "act-companyPersonDetails", "aria-labelledby", "companyPersonDetailsHeading", "data-bs-parent", "#companyPersonDetails", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-4", "col-lg-4"], ["name", "ownerType", "formControlName", "ownerType", 1, "form-control", 3, "ngModelChange"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "validation-filed", 4, "ngIf"], ["type", "text", "name", "pidNo", "formControlName", "pidNo", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9-]/g, '');", "required", "", 1, "form-control", 3, "input"], ["for", "ownerName"], ["type", "text", "id", "ownerName", "name", "ownerName", "formControlName", "ownerName", "required", "", 1, "form-control"], ["type", "text", "formControlName", "address", 1, "form-control"], ["formGroupName", "serviceRequest"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "col-md-4", "col-lg-3"], ["type", "text", "name", "contactPersonName", "formControlName", "contactPersonName", "required", "", 1, "form-control"], ["type", "text", "name", "contactPersonPhone", "formControlName", "contactPersonPhone", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", "required", "", 1, "form-control"], ["type", "text", "name", "secondaryPhoneNo", "formControlName", "secondaryPhoneNo", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", 1, "form-control"], ["type", "text", "name", "pid", "formControlName", "pid", 1, "form-control"], ["type", "text", "name", "contactPersonEmail", "formControlName", "contactPersonEmail", 1, "form-control"], ["type", "text", "name", "location", "formControlName", "location", 1, "form-control"], [1, "col-md-6", "col-lg-6"], ["id", "NumberOfVehicles", "name", "NumberOfVehicles", "type", "number", "min", "0", "maxlength", "11", "formControlName", "noOfVehicle", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "required", "", 1, "form-control"], ["type", "date", "name", "inspectionDate", "formControlName", "inspectionDate", 1, "form-control"], ["id", "accordionExample3", 1, "accordion", "section-accordian"], ["id", "headingThree", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingThree", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [1, "col-md-6", "col-lg-3"], [1, "outline-radio"], ["type", "radio", "id", "rb1", "checked", ""], ["for", "rb1"], ["src", "./assets/img/st-img-1.svg"], [1, "st-label"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "disabled", "click"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "paymentModel", "aria-hidden", "true", 1, "modal", "fade", "locPop", 3, "ngStyle"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "paymentModel", 1, "modal-title"], [1, "modal-body"], [1, "payment-info"], [1, "payment-type"], [4, "ngFor", "ngForOf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], ["class", "summery-details", 4, "ngIf"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#paymentDetailsModal", 1, "btn", "btn-orange", 3, "disabled", "click"], [4, "ngIf"], [3, "value"], [1, "validation-filed"], [1, "btn-radio"], ["type", "radio", "name", "serviceType", "formControlName", "serviceType", 3, "id", "value"], [3, "for"], ["type", "radio", 3, "id", "ngModel", "value", "ngModelChange"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "ngModel", "clearSearchOnAdd", "minTermLength", "ngModelChange"], [1, "dropdown-container"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], ["appThousandSeparator", "", "type", "text", 1, "form-control", 3, "ngModel", "ngModelChange"], ["colspan", "2", 2, "text-align", "center"], [1, "validation-filed", 2, "font-style", "italic"], [3, "isPaymentStarted", "email", "isSuccess", "isPayCanceled", "isNotReachable", "requestRefId", "currentDateFormat", "currentTimeFormat", "totalAmountTh", "paymentName", "onCancelEvent", "onCancelFailedEvent", "onDownloadPaymentEvent"]],
    template: function MobileBookingComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "form", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 3)(5, "div", 4)(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "h2", 8)(10, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](11, " Company/Person Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](12, "div", 10)(13, "div", 11)(14, "div", 12)(15, "div", 13)(16, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](17, "Owner PID Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](18, "select", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_Template_select_ngModelChange_18_listener() {
          return ctx.validateOwnerPid();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](19, MobileBookingComponent_option_19_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](20, MobileBookingComponent_div_20_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](21, "div", 13)(22, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](23, "Owner PID *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](24, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("input", function MobileBookingComponent_Template_input_input_24_listener($event) {
          return ctx.formatPidInput($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](25, MobileBookingComponent_div_25_Template, 2, 1, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](26, MobileBookingComponent_div_26_Template, 3, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](27, "div", 13)(28, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](29, "Owner Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](30, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](31, MobileBookingComponent_div_31_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](32, "div", 13)(33, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](34, "Address");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](35, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](36, "div", 21)(37, "div", 1)(38, "div", 3)(39, "div", 22)(40, "div", 5)(41, "div", 23)(42, "div", 7)(43, "h2", 24)(44, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](45, " Contact Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](46, "div", 26)(47, "div", 11)(48, "div", 12)(49, "div", 27)(50, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](51, "Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](52, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](53, MobileBookingComponent_div_53_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](54, "div", 27)(55, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](56, "Phone No *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](57, "input", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](58, MobileBookingComponent_div_58_Template, 2, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](59, MobileBookingComponent_div_59_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](60, "div", 27)(61, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](62, "Secondary Phone No *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](63, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](64, MobileBookingComponent_div_64_Template, 2, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](65, MobileBookingComponent_div_65_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](66, "div", 27)(67, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](68, "PID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](69, "input", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](70, MobileBookingComponent_div_70_Template, 3, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](71, "div", 27)(72, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](73, "Email ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](74, "input", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](75, MobileBookingComponent_div_75_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](76, "div", 27)(77, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](78, "Inspection Location *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](79, "input", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](80, MobileBookingComponent_div_80_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](81, "div", 34)(82, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](83, "Approximate Number of vehicles to be Inspected*");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](84, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](85, MobileBookingComponent_div_85_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](86, "div", 27)(87, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](88, "Preferred Date *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](89, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](90, MobileBookingComponent_div_90_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](91, MobileBookingComponent_div_91_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](92, MobileBookingComponent_div_92_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](93, "div", 1)(94, "div", 3)(95, "div", 22)(96, "div", 5)(97, "div", 37)(98, "div", 7)(99, "h2", 38)(100, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](101, " Service Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](102, "div", 40)(103, "div", 11)(104, "div", 12)(105, "div", 41)(106, "div", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](107, "input", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](108, "label", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](109, "img", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](110, "Inspection");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](111, "div", 1)(112, "div", 3)(113, "label", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](114, "Inspection Service Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](115, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](116, MobileBookingComponent_div_116_Template, 4, 4, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](117, "div", 1)(118, "div", 48)(119, "button", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_119_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](120, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](121, "button", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_121_listener() {
          return ctx.submitForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](122, "Payment");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](123, "div", 51)(124, "div", 52)(125, "div", 53)(126, "div", 54)(127, "h1", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](128, "Payment Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](129, "div", 56)(130, "div", 57)(131, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](132, MobileBookingComponent_ng_container_132_Template, 5, 5, "ng-container", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](133, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](134, MobileBookingComponent_div_134_Template, 8, 5, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](135, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](136, MobileBookingComponent_div_136_Template, 25, 4, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](137, "div", 62)(138, "button", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_138_listener() {
          return ctx.cancelPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](139, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](140, "button", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_140_listener() {
          return ctx.submitPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](141, "Submit");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](142, MobileBookingComponent_ng_container_142_Template, 4, 16, "ng-container", 65);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("formGroup", ctx.mobileBookingForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.ownerPidTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get("ownerType").dirty || ctx.mobileBookingForm.get("ownerType").touched) && ctx.mobileBookingForm.get("ownerType").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get("pidNo").touched && ctx.mobileBookingForm.get("pidNo").hasError("required"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get("pidNo").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get("ownerName").dirty || ctx.mobileBookingForm.get("ownerName").touched) && ctx.mobileBookingForm.get("ownerName").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](26, _c2)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](27, _c2)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](28, _c2)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](29, _c0)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](30, _c0)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](31, _c0)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](32, _c0)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](33, _c1)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](34, _c1)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](35, _c1)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](36, _c1)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](37, _c3)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](38, _c4)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](39, _c5)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](40, _c5)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](41, _c5)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](42, _c6)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](43, _c6)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](44, _c6)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](45, _c7)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](46, _c7)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](47, _c7)).errors != null && (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](48, _c7)).errors == null ? null : ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](49, _c7)).errors.required));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](50, _c7)).errors != null && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](51, _c7)).errors.LessThanToday);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](52, _c7)).hasError("InvalidDate") && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](53, _c7)).touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.serviceTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", !ctx.mobileBookingForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](54, _c8, ctx.display));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.paymentMethods);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isCreditSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.isCreditSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", !ctx.validateSubmitPayment());
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isPaymentStarted);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_27__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_27__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_27__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_22__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_22__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_22__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.MaxLengthValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormControlName, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormGroupName, _shared_thousand_separator_directive__WEBPACK_IMPORTED_MODULE_19__.ThousandSeparatorDirective, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_20__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_28__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_28__.NgOptionComponent, _angular_common__WEBPACK_IMPORTED_MODULE_27__.DatePipe],
    styles: ["input[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\n    appearance: none;\n    margin: 0;\n}\n\n.btn-orange[_ngcontent-%COMP%]:disabled {\n    background-color: #ef9c3d;\n    color: #ffff;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvbW9iaWxlLWJvb2tpbmcvbW9iaWxlLWJvb2tpbmcvbW9iaWxlLWJvb2tpbmcuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7SUFHSSxnQkFBZ0I7SUFDaEIsU0FBUztBQUNiOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLFxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XG4gICAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuICAgIGFwcGVhcmFuY2U6IG5vbmU7XG4gICAgbWFyZ2luOiAwO1xufVxuXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcbiAgICBjb2xvcjogI2ZmZmY7XG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 25753:
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/receipt-backoffice/receipt-backoffice.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReceiptBackofficeComponent": () => (/* binding */ ReceiptBackofficeComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/modules/shared/custom-validators/date.validator */ 97633);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 94666);












function ReceiptBackofficeComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1, " * Enter a valid date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function ReceiptBackofficeComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1, " * From Date cannot be later than the To Date. Please select valid dates. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function ReceiptBackofficeComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1, " * From Time must be earlier than the To Time. Please select valid time ranges. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function ReceiptBackofficeComponent_option_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", pt_r8.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", pt_r8.lkValueEname, " ");
  }
}
function ReceiptBackofficeComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 31)(1, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, " Exempted Receipts ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
}
function ReceiptBackofficeComponent_div_55_tr_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "td", 47)(14, "button", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_55_tr_20_Template_button_click_14_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r14);
      const i_r12 = restoredCtx.index;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r13.printCustomerReport(i_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](15, "img", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](16, " Customer Receipt ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](17, "td", 47)(18, "button", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_55_tr_20_Template_button_click_18_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r14);
      const i_r12 = restoredCtx.index;
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r15.printInspectorReport(i_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](19, "img", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](20, " Inspector Receipt ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const r_r11 = ctx.$implicit;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r11.receiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r11.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx_r9.mapToPlateName(r_r11.plateType), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r11.vinNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r11.ownerName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r11.serviceName, " ");
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function ReceiptBackofficeComponent_div_55_li_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "li", 50)(1, "a", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_55_li_26_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r18);
      const i_r16 = restoredCtx.$implicit;
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      ctx_r17.currentPage = i_r16 + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r17.getPagedReceipts(ctx_r17.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const i_r16 = ctx.$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](2, _c0, ctx_r10.currentPage === i_r16 + 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](i_r16 + 1);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
function ReceiptBackofficeComponent_div_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 32)(1, "div", 33)(2, "table", 34)(3, "thead")(4, "tr", 35)(5, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](6, " Receipt No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8, " Plate Number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "th", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](10, " License Plate Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](12, " Vin No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](14, " Owner Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](15, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](16, " Service Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](17, "th", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](18, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](19, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](20, ReceiptBackofficeComponent_div_55_tr_20_Template, 21, 6, "tr", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](21, "div", 40)(22, "ul", 41)(23, "li", 42)(24, "a", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_55_Template_a_click_24_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r20);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      ctx_r19.currentPage = ctx_r19.currentPage - 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r19.getPagedReceipts(ctx_r19.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](25, "i", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](26, ReceiptBackofficeComponent_div_55_li_26_Template, 3, 4, "li", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](27, "li", 42)(28, "a", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_55_Template_a_click_28_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r20);
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      ctx_r21.currentPage = ctx_r21.currentPage + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r21.getPagedReceipts(ctx_r21.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](29, "i", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx_r5.exemptedReceipts);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](4, _c1, ctx_r5.currentPage == 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx_r5.pagesArray(ctx_r5.totalPages));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](6, _c1, ctx_r5.currentPage * ctx_r5.itemsPerPage >= ctx_r5.totalReceipts));
  }
}
function ReceiptBackofficeComponent_div_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 31)(1, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, " External Registration Receipts ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
}
function ReceiptBackofficeComponent_div_57_tr_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "td", 47)(8, "button", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_57_tr_14_Template_button_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r27);
      const i_r25 = restoredCtx.index;
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r26.printCustomerReport(i_r25));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](9, "img", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](10, " Customer Receipt ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "td", 47)(12, "button", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_57_tr_14_Template_button_click_12_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r27);
      const i_r25 = restoredCtx.index;
      const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r28.printInspectorReport(i_r25));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](13, "img", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](14, " Inspector Receipt ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const r_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r24.receiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r24.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r24.totalAmount, " ");
  }
}
function ReceiptBackofficeComponent_div_57_li_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "li", 50)(1, "a", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_57_li_20_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r31);
      const i_r29 = restoredCtx.$implicit;
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      ctx_r30.currentPage = i_r29 + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r30.getPagedReceipts(ctx_r30.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const i_r29 = ctx.$implicit;
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](2, _c0, ctx_r23.currentPage === i_r29 + 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](i_r29 + 1);
  }
}
function ReceiptBackofficeComponent_div_57_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 32)(1, "div", 33)(2, "table", 34)(3, "thead")(4, "tr", 35)(5, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](6, " Receipt No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8, " Service Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "th", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](10, " Total Amount ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "th", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](12, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](14, ReceiptBackofficeComponent_div_57_tr_14_Template, 15, 3, "tr", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](15, "div", 40)(16, "ul", 41)(17, "li", 42)(18, "a", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_57_Template_a_click_18_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r33);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      ctx_r32.currentPage = ctx_r32.currentPage - 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r32.getPagedReceipts(ctx_r32.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](19, "i", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](20, ReceiptBackofficeComponent_div_57_li_20_Template, 3, 4, "li", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](21, "li", 42)(22, "a", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_div_57_Template_a_click_22_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r33);
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      ctx_r34.currentPage = ctx_r34.currentPage + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r34.getPagedReceipts(ctx_r34.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](23, "i", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx_r7.externalReceipts);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](4, _c1, ctx_r7.currentPage == 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx_r7.pagesArray(ctx_r7.totalPages));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](6, _c1, ctx_r7.currentPage * ctx_r7.itemsPerPage >= ctx_r7.totalReceipts));
  }
}
class ReceiptBackofficeComponent {
  constructor(fb, vehicleService, sideNav, ssrsService, sharedLookup, sharedData) {
    this.fb = fb;
    this.vehicleService = vehicleService;
    this.sideNav = sideNav;
    this.ssrsService = ssrsService;
    this.sharedLookup = sharedLookup;
    this.sharedData = sharedData;
    this.currentPage = 1;
    this.itemsPerPage = 10;
    this.initializeForm();
    this.setupFormValidators();
  }
  initializeForm() {
    const dateFrom = new Date();
    // set the time from to 6 am
    dateFrom.setHours(6, 0, 0, 0);
    const timeTo = new Date(dateFrom.getTime());
    // set time to to 6 pm
    timeTo.setHours(18, 0, 0, 0);
    this.receiptForm = this.fb.group({
      inputDateFrom: [dateFrom.toISOString().slice(0, 10), [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_2__.DateValidator.CheckMonthDate]],
      inputTimeFrom: [dateFrom.toTimeString().slice(0, 5), _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      inputDateTo: [dateFrom.toISOString().slice(0, 10), [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_2__.DateValidator.CheckMonthDate]],
      inputTimeTo: [timeTo.toTimeString().slice(0, 5), _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      plateNo: [''],
      plateType: [''],
      ownerPID: [''],
      vinNo: [''],
      receiptNo: ['']
    });
  }
  ngOnInit() {
    this.moduleId = 2;
    this.sideNav.setActiveEnt(this.moduleId, 77);
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.getAllReceipts();
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.plateTypes = data;
    });
    this.receiptForm.get('inputDateFrom').valueChanges.subscribe(() => {
      this.receiptForm.get('inputDateTo').updateValueAndValidity();
    });
    this.receiptForm.get("inputTimeFrom").valueChanges.subscribe(() => {
      this.receiptForm.get("inputTimeTo").updateValueAndValidity();
    });
  }
  setupFormValidators() {
    this.receiptForm.get('inputDateTo').setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, this.validateDateTo.bind(this)]);
    this.receiptForm.get('inputDateTo').updateValueAndValidity();
    this.receiptForm.get('inputTimeTo').setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, this.validateTimeTo.bind(this)]);
    this.receiptForm.get('inputTimeTo').updateValueAndValidity();
  }
  validateDateTo(control) {
    const inputDateFrom = new Date(this.receiptForm.get('inputDateFrom').value);
    const inputDateTo = new Date(this.receiptForm.get('inputDateTo').value);
    return inputDateTo >= inputDateFrom ? null : {
      invalidDateRange: true
    };
  }
  validateTimeTo() {
    const timeTo = this.receiptForm.get('inputTimeTo').value;
    const timeFrom = this.receiptForm.get('inputTimeFrom').value;
    if (this.receiptForm.get('inputDateTo').value == this.receiptForm.get('inputDateFrom').value) {
      return timeTo > timeFrom ? null : {
        invalidTimeRange: true
      };
    } else {
      return null;
    }
  }
  mapToPlateName(pltType) {
    return this.plateTypes.find(plt => plt.lkCodeValue == pltType).lkValueEname;
  }
  getAllReceipts() {
    const dateDetails = {
      stationId: this.stationId,
      plateNo: this.receiptForm.get('plateNo').value ? this.receiptForm.get('plateNo').value : null,
      plateType: this.receiptForm.get('plateType').value ? this.receiptForm.get('plateType').value : null,
      vinNo: this.receiptForm.get('vinNo').value ? this.receiptForm.get('vinNo').value : null,
      ownerPID: this.receiptForm.get('ownerPID').value ? this.receiptForm.get('ownerPID').value : null,
      receiptNo: this.receiptForm.get('receiptNo').value ? this.receiptForm.get('receiptNo').value : null,
      fromDate: this.receiptForm.get("inputDateFrom").value + 'T' + this.receiptForm.get('inputTimeFrom').value,
      toDate: this.receiptForm.get("inputDateTo").value + 'T' + this.receiptForm.get('inputTimeTo').value,
      pageIndex: 1,
      pageSize: this.itemsPerPage,
      serviceType: this.moduleId
    };
    this.getReceiptDetails(dateDetails, false);
  }
  getReceiptDetails(details, isNextPage) {
    this.vehicleService.getReceiptDetails(details).subscribe(response => {
      this.receiptDetails = response.items.receipts;
      // Filter external receipts
      this.externalReceipts = this.receiptDetails.filter(receipt => receipt.inspectionServiceId === 5);
      // Filter exempted receipts 
      this.exemptedReceipts = this.receiptDetails.filter(receipt => receipt.inspectionServiceId === 1);
      if (!isNextPage) {
        this.totalReceipts = this.receiptDetails.length;
        if (this.totalReceipts > this.itemsPerPage) {
          this.getPagedReceipts(1);
        }
      }
    });
  }
  clearFilters() {
    this.initializeForm();
    this.getAllReceipts();
  }
  getPagedReceipts(page) {
    const dateDetails = {
      stationId: this.stationId,
      fromDate: this.receiptForm.get("inputDateFrom").value + 'T' + this.receiptForm.get('inputTimeFrom').value,
      toDate: this.receiptForm.get("inputDateTo").value + 'T' + this.receiptForm.get('inputTimeTo').value,
      pageIndex: page,
      pageSize: this.itemsPerPage,
      serviceType: this.moduleId
    };
    this.getReceiptDetails(dateDetails, true);
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.receiptDetails.slice(startIndex, endIndex);
  }
  get totalPages() {
    if (this.totalReceipts > this.itemsPerPage) {
      return Math.ceil(this.totalReceipts / this.itemsPerPage);
    } else {
      return 1;
    }
  }
  pagesArray(totalPages) {
    return Array.from({
      length: totalPages
    }, (_, index) => index);
  }
  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
  nextPage() {
    const totalPages = Math.ceil(this.receiptDetails.length / this.itemsPerPage);
    if (this.currentPage < totalPages) {
      this.currentPage++;
    }
  }
  printCustomerReport(index) {
    this.ssrsService.downloadCustomerReport(this.receiptDetails[index].requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_1__.PrintEnum.printSave, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_0__.ModuleSourceEnum.registration);
  }
  printInspectorReport(index) {
    this.ssrsService.downloadInspetorReport(this.receiptDetails[index].requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_1__.PrintEnum.printSave, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_0__.ModuleSourceEnum.registration);
  }
  static #_ = this.ɵfac = function ReceiptBackofficeComponent_Factory(t) {
    return new (t || ReceiptBackofficeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_5__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_6__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: ReceiptBackofficeComponent,
    selectors: [["app-receipt-backoffice"]],
    decls: 58,
    vars: 10,
    consts: [[3, "formGroup"], [1, "row", "form-field"], [1, "col-md-2"], ["type", "date", "id", "fromDate", "formControlName", "inputDateFrom", "required", "", 1, "form-control"], ["type", "time", "id", "fromTime", "formControlName", "inputTimeFrom", 1, "form-control"], ["type", "date", "id", "toDate", "formControlName", "inputDateTo", "required", "", 1, "form-control"], ["type", "time", "id", "toTime", "formControlName", "inputTimeTo", 1, "form-control"], ["class", "row error-message", 4, "ngIf"], ["class", "error-message", 4, "ngIf"], [1, "row", "form-fields"], [1, "col-md-3"], ["type", "text", "formControlName", "plateNo", 1, "form-control"], ["formControlName", "plateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "text", "formControlName", "ownerPID", 1, "form-control"], ["type", "text", "formControlName", "vinNo", 1, "form-control"], ["type", "text", "formControlName", "receiptNo", 1, "form-control"], ["id", "endBt", 1, "col-md-4", "end-btns"], [1, "btn", "btn-orange", 3, "disabled", "click"], [1, "btn", "btn-outline-gray", 3, "click"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], ["class", "accordion-header", "id", "headingTwo", 4, "ngIf"], ["class", "accordion-body", 4, "ngIf"], [1, "row", "error-message"], [1, "error-message"], [3, "value"], ["id", "headingTwo", 1, "accordion-header"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col"], ["scopr", "col"], ["scope", "col", "colspan", "2"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], ["id", "print"], [1, "btn", "btn-outline-gray", "small-text", 3, "click"], ["src", "./assets/img/printer.svg"], [1, "page-item", 3, "ngClass"], ["id", "pagesId", 1, "page-link", 3, "click"]],
    template: function ReceiptBackofficeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "html")(1, "body")(2, "form", 0)(3, "div", 1)(4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](5, " Date-Time From: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](6, "input", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](8, "label")(9, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](10, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](11, " Date-Time To: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](12, "input", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](14, "label")(15, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](16, ReceiptBackofficeComponent_div_16_Template, 2, 0, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](17, ReceiptBackofficeComponent_div_17_Template, 2, 0, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](18, ReceiptBackofficeComponent_div_18_Template, 2, 0, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](19, "div", 9)(20, "div", 10)(21, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](22, "Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](23, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](24, "div", 10)(25, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](26, " Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](27, "select", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](28, ReceiptBackofficeComponent_option_28_Template, 2, 2, "option", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](29, "div", 10)(30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](31, " Owner PID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](32, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](33, "div", 9)(34, "div", 10)(35, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](36, " VIN No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](37, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](38, "div", 10)(39, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](40, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](41, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](42, "div", 17)(43, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_Template_button_click_43_listener() {
          return ctx.getAllReceipts();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](44, " View Receipts ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](45, "button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_Template_button_click_45_listener() {
          return ctx.clearFilters();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](46, " Clear Filters ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](47, "div", 20)(48, "div", 21)(49, "div", 20)(50, "div", 22)(51, "div", 23)(52, "div", 24)(53, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](54, ReceiptBackofficeComponent_div_54_Template, 3, 0, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](55, ReceiptBackofficeComponent_div_55_Template, 30, 8, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](56, ReceiptBackofficeComponent_div_56_Template, 3, 0, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](57, ReceiptBackofficeComponent_div_57_Template, 24, 8, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.receiptForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.receiptForm.get("inputDateTo").invalid && ctx.receiptForm.get("inputDateTo").hasError("dateMonthError"));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.receiptForm.get("inputDateTo").hasError("invalidDateRange"));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.receiptForm.get("inputTimeTo").hasError("invalidTimeRange"));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("disabled", ctx.receiptForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.exemptedReceipts.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.exemptedReceipts.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.externalReceipts.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.externalReceipts.length > 0);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName],
    styles: ["th[_ngcontent-%COMP%] {\n    color: white;\n    background-color: #F89828;\n}\n\n\n.custom-table[_ngcontent-%COMP%] {\n    text-align: center;\n    color: black;\n    background-color: #ffdcb3;\n    border: 1px solid white;\n    border-collapse: collapse;\n    margin: 20px 0;\n}\n\ntable[_ngcontent-%COMP%] {\n    text-align: center;\n}\n\nimg[_ngcontent-%COMP%] {\n    width: 20px;\n    height: 20px;\n}\n\n#print[_ngcontent-%COMP%] {\n    font-size: small;\n}\n\n.small-text[_ngcontent-%COMP%] {\n    font-size: small;\n}\n\n.pagination-container[_ngcontent-%COMP%] {\n    text-align: center;\n    margin-left: 450px;\n}\n\n.page-item[_ngcontent-%COMP%] {\n    margin: 0 2px;\n}\n\n.page-link[_ngcontent-%COMP%] {\n    cursor: pointer;\n    padding: 5px 5px;\n    text-decoration: none;\n}\n\n#pagesId[_ngcontent-%COMP%] {\n    background-color: white;\n    color: #F89828;\n}\n\nli.page-item.active[_ngcontent-%COMP%]   #pagesId[_ngcontent-%COMP%] {\n    background-color: #F89828;\n    color: white;\n    font-weight: bold;\n    border-color: #F89828;\n}\n\n.bi[_ngcontent-%COMP%] {\n    color: #F89828;\n}\n\n.error-message[_ngcontent-%COMP%] {\n    text-align: center;\n    margin-right: 100px;\n}\n\n#filterPl[_ngcontent-%COMP%] {\n    margin-left: 30px;\n}\n\n#endBt[_ngcontent-%COMP%] {\n    margin-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvcmVjZWlwdC1iYWNrb2ZmaWNlL3JlY2VpcHQtYmFja29mZmljZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksWUFBWTtJQUNaLHlCQUF5QjtBQUM3Qjs7O0FBR0E7SUFDSSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixxQkFBcUI7QUFDekI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsY0FBYztBQUNsQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksaUJBQWlCO0FBQ3JCOztBQUVBO0lBQ0ksZ0JBQWdCO0FBQ3BCIiwic291cmNlc0NvbnRlbnQiOlsidGgge1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xufVxuXG5cbi5jdXN0b20tdGFibGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZGNiMztcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICAgIG1hcmdpbjogMjBweCAwO1xufVxuXG50YWJsZSB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5pbWcge1xuICAgIHdpZHRoOiAyMHB4O1xuICAgIGhlaWdodDogMjBweDtcbn1cblxuI3ByaW50IHtcbiAgICBmb250LXNpemU6IHNtYWxsO1xufVxuXG4uc21hbGwtdGV4dCB7XG4gICAgZm9udC1zaXplOiBzbWFsbDtcbn1cblxuLnBhZ2luYXRpb24tY29udGFpbmVyIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luLWxlZnQ6IDQ1MHB4O1xufVxuXG4ucGFnZS1pdGVtIHtcbiAgICBtYXJnaW46IDAgMnB4O1xufVxuXG4ucGFnZS1saW5rIHtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgcGFkZGluZzogNXB4IDVweDtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbiNwYWdlc0lkIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgICBjb2xvcjogI0Y4OTgyODtcbn1cblxubGkucGFnZS1pdGVtLmFjdGl2ZSAjcGFnZXNJZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Y4OTgyODtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgYm9yZGVyLWNvbG9yOiAjRjg5ODI4O1xufVxuXG4uYmkge1xuICAgIGNvbG9yOiAjRjg5ODI4O1xufVxuXG4uZXJyb3ItbWVzc2FnZSB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIG1hcmdpbi1yaWdodDogMTAwcHg7XG59XG5cbiNmaWx0ZXJQbCB7XG4gICAgbWFyZ2luLWxlZnQ6IDMwcHg7XG59XG5cbiNlbmRCdCB7XG4gICAgbWFyZ2luLXRvcDogMjBweDtcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 56757:
/*!****************************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/observable/fromSubscribable.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fromSubscribable": () => (/* binding */ fromSubscribable)
/* harmony export */ });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Observable */ 90833);

function fromSubscribable(subscribable) {
  return new _Observable__WEBPACK_IMPORTED_MODULE_0__.Observable(subscriber => subscribable.subscribe(subscriber));
}

/***/ }),

/***/ 62101:
/*!******************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/connect.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "connect": () => (/* binding */ connect)
/* harmony export */ });
/* harmony import */ var _Subject__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Subject */ 80228);
/* harmony import */ var _observable_from__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../observable/from */ 59346);
/* harmony import */ var _util_lift__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/lift */ 41944);
/* harmony import */ var _observable_fromSubscribable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../observable/fromSubscribable */ 56757);




const DEFAULT_CONFIG = {
  connector: () => new _Subject__WEBPACK_IMPORTED_MODULE_0__.Subject()
};
function connect(selector, config = DEFAULT_CONFIG) {
  const {
    connector
  } = config;
  return (0,_util_lift__WEBPACK_IMPORTED_MODULE_1__.operate)((source, subscriber) => {
    const subject = connector();
    (0,_observable_from__WEBPACK_IMPORTED_MODULE_2__.from)(selector((0,_observable_fromSubscribable__WEBPACK_IMPORTED_MODULE_3__.fromSubscribable)(subject))).subscribe(subscriber);
    subscriber.add(source.subscribe(subject));
  });
}

/***/ }),

/***/ 98532:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/multicast.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "multicast": () => (/* binding */ multicast)
/* harmony export */ });
/* harmony import */ var _observable_ConnectableObservable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../observable/ConnectableObservable */ 23932);
/* harmony import */ var _util_isFunction__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/isFunction */ 92971);
/* harmony import */ var _connect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./connect */ 62101);



function multicast(subjectOrSubjectFactory, selector) {
  const subjectFactory = (0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(subjectOrSubjectFactory) ? subjectOrSubjectFactory : () => subjectOrSubjectFactory;
  if ((0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(selector)) {
    return (0,_connect__WEBPACK_IMPORTED_MODULE_1__.connect)(selector, {
      connector: subjectFactory
    });
  }
  return source => new _observable_ConnectableObservable__WEBPACK_IMPORTED_MODULE_2__.ConnectableObservable(source, subjectFactory);
}

/***/ }),

/***/ 68917:
/*!************************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/publishReplay.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "publishReplay": () => (/* binding */ publishReplay)
/* harmony export */ });
/* harmony import */ var _ReplaySubject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../ReplaySubject */ 26067);
/* harmony import */ var _multicast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./multicast */ 98532);
/* harmony import */ var _util_isFunction__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/isFunction */ 92971);



function publishReplay(bufferSize, windowTime, selectorOrScheduler, timestampProvider) {
  if (selectorOrScheduler && !(0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(selectorOrScheduler)) {
    timestampProvider = selectorOrScheduler;
  }
  const selector = (0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(selectorOrScheduler) ? selectorOrScheduler : undefined;
  return source => (0,_multicast__WEBPACK_IMPORTED_MODULE_1__.multicast)(new _ReplaySubject__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(bufferSize, windowTime, timestampProvider), selector)(source);
}

/***/ })

}]);
//# sourceMappingURL=635.376ed1d1cb54429e.js.map