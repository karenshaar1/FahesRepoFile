"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[757],{

/***/ 6640:
/*!*******************************************************!*\
  !*** ./src/app/core/services/dashboard.ts.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardTsService": () => (/* binding */ DashboardTsService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class DashboardTsService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'GlobalConfig/v1';
  }
  getDashdboardEntitiesByUserRoles(userId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetDashdboardEntitiesByUserRoles?userId=${userId}`, '');
  }
  static #_ = this.ɵfac = function DashboardTsService_Factory(t) {
    return new (t || DashboardTsService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: DashboardTsService,
    factory: DashboardTsService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 6957:
/*!**********************************************************!*\
  !*** ./src/app/modules/dashboard/dashboard.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardComponent": () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var src_app_core_services_dashboard_ts_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/dashboard.ts.service */ 6640);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);





class DashboardComponent {
  constructor(sanitizer, dashboardServ, sideNav, sharedData) {
    this.sanitizer = sanitizer;
    this.dashboardServ = dashboardServ;
    this.sideNav = sideNav;
    this.sharedData = sharedData;
    this.accessToken = "AwAAABowMi8xMC8yMDI0IDE0OjMwOjU4ICswMDowMKwIMC5BWFFBWkJZMWhPLUh0RUM0dzVaMHZWWWo2Z1lBQUFBQUFQRVB6Z0FBQUFBQUFBQjBBSVUuQWdBQkFBRUFBQUFtb0ZmR3RZeHZSck5yaVFkUEtJWi1BZ0RzX3dVQTlQOEVCeXRJcmFEZmFsZXF0dmxXMEVnd2ZLZVlOVngydUgtbGc1ekc5MTRrMVlrU1BlYkxKcy1UdjB1ZmtuaWlCYmVnRVM1UVExS01FUXU0cV92ZUZSeVMtY2xJRDUyTTR6bFE3NFlwS3JjbnE2cE9vZ05uaWNXYmVjVVJKZTNVWmxHd250LVZVQ0dORjd5SHpZUnY0VUNSWTdndFBRa3lFU2FKRVYzRUpOU1RkWXl4YnN1Z3dxM0taOUZOY1JMeHR0ZzNTdVJIdnJNWERLdnJUaWJXeERYOF9FbzJhSWJkQXk1XzJMREJ3MkdSWFNWOE1sS1d3dXNkTFFPWG85ZXBlQjFiU2RlWDFBVDBuU2ZpZ0o3Y0MzTWFPN05DUkNlZ2FzZjlDNm9RUFJyYUJNM3REZmw0NmtKb0xiR3ozeVo2SjNSTmxEb1lSUzlUZ05FanVwd3AyYlVsTk9SLXpBWTducGloVmR4WFdnc2pQeXFLNVVsbTB6cEw4blEtNm5IdFBDajdsZjhDU2FpZkI5RHE5ZVZoQ0NOc1ZrTkJveHRFc3hPN0VVTEdQdUhYYXgxMm81eW1FTmlEdGhEREJXdDBPM2pFbWhZcjZfMERVMHBrZWZUUHdmTTVfLTVXZ2JMa25xRkJIMVBNNVhCenJoVGpJQ2dlcFJKQmpFLU1XNUlLN2lVb2xUa1Fsb1ZnUzA1dGIzcEJ4cUZWeDFwU0lCNTBFQ1pkREUwdFd1ZVRpS0hkX05QajcwM2ZzSGUxVHZSNUY2SDlWbHBKeE1fYWxFVWtCcm1Bd1FjdFl0Z293X2dsQU5OdGR4dHY2WVNBcGQwd2gtbnpKd2RBLWxqZXBDcF9OczJNS0pITy1NOTlpeVJuU0o5dmxpMDBPLVB2VTVyaXJYVTJhbmQ1eGIxTHBzU0dXWEtZOWlLMVcwclNBTWxtYlY2RmRwNkcwTWJpWUotOVQySm1qbjJjaWgxUGxfbjlBaHBlUnNadXVmRjE3b0lHTGJmLWY4S21pY0tTNjROVDdYdEJxTW5fbmRwUFg4V2xObGhHUHNEd0xmUVZNRzBvQzh6bUh0NWtqYWoxOVVLR1BlQzc0LXdiVU95X1BEc3lCNnVIcHZCOUlNQ3YzTTYySkh0V2p1MjJxbHpJYXY4YWMteXJaQlhsZzZ4NGZBRVJPenhYQXZJNE5yQS12cDBTV2FpTjNfc21ZY0MzQ2VnbkdIYXlNM0RZWjRxVWtpV19VNktCWmlqa2Q4a19oelNzVHRSa2ZHa19FRWUzY253VngweWhPRlVwc0xmeFh3AA%3D%3D";
    this.safeDashboardUrl = '';
  }
  ngOnInit() {
    //this.accessToken = localStorage.getItem("token");
    this.sharedData.dashboardId$.subscribe(dashboard => {
      this.dashboardId = dashboard;
      this.dashboardChanges();
      this.sideNav.setActiveEnt(8, this.dashboardId);
    });
  }
  dashboardChanges() {
    this.dashboardServ.getDashdboardEntitiesByUserRoles(3).subscribe(response => {
      response.items.forEach(dashboard => {
        if (dashboard.entityId == this.dashboardId) {
          this.reportPath = dashboard.reportPath;
          this.safeDashboardUrl = this.getEmbedUrl();
        }
      });
    });
  }
  getEmbedUrl() {
    return this.sanitizer.bypassSecurityTrustResourceUrl(`${this.reportPath}&accessToken=${this.accessToken}`);
  }
  static #_ = this.ɵfac = function DashboardComponent_Factory(t) {
    return new (t || DashboardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.DomSanitizer), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_dashboard_ts_service__WEBPACK_IMPORTED_MODULE_0__.DashboardTsService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: DashboardComponent,
    selectors: [["app-dashboard"]],
    decls: 5,
    vars: 1,
    consts: [["width", "1140", "height", "800.25", "frameborder", "0", "allowFullScreen", "true", 3, "src"]],
    template: function DashboardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "html");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "body")(3, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "iframe", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx.safeDashboardUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeResourceUrl"]);
      }
    },
    styles: ["body[_ngcontent-%COMP%] {\n    margin: 0;\n}\n\niframe[_ngcontent-%COMP%] {\n    border: 0;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9kYXNoYm9hcmQvZGFzaGJvYXJkLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxTQUFTO0FBQ2I7O0FBRUE7SUFDSSxTQUFTO0FBQ2IiLCJzb3VyY2VzQ29udGVudCI6WyJib2R5IHtcbiAgICBtYXJnaW46IDA7XG59XG5cbmlmcmFtZSB7XG4gICAgYm9yZGVyOiAwO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 88757:
/*!*******************************************************!*\
  !*** ./src/app/modules/dashboard/dashboard.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardModule": () => (/* binding */ DashboardModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component */ 6957);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var powerbi_client_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! powerbi-client-angular */ 45645);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);








const routes = [{
  path: '',
  component: _dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent
}];
class DashboardModule {
  static #_ = this.ɵfac = function DashboardModule_Factory(t) {
    return new (t || DashboardModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
    type: DashboardModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, powerbi_client_angular__WEBPACK_IMPORTED_MODULE_6__.PowerBIEmbedModule, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](DashboardModule, {
    declarations: [_dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, powerbi_client_angular__WEBPACK_IMPORTED_MODULE_6__.PowerBIEmbedModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=757.1f771342d58fcac2.js.map